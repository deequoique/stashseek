import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useState } from "react";
import { HashRouter, Navigate, Outlet, Route, Routes, useLocation, } from "react-router";
import { getSession, logout, setUnauthorizedHandler, streamConversationMessage } from "../api/client";
import { AccountLinkPage } from "../account/AccountLinkPage";
import { BrowserCompanionPage } from "../account/BrowserCompanionPage";
import { LoginPage } from "../auth/LoginPage";
import { ChatPage } from "../chat/ChatPage";
import { LibraryPage } from "../library/LibraryPage";
import { ShowcasePage } from "../showcase/ShowcasePage";
import { VideoDetailPage } from "../videos/VideoDetailPage";
import { AppShell } from "./AppShell";
import { BrandLogo } from "./BrandLogo";
import { useRouteNavigate } from "./RouteTransition";
const BROWSER_COMPANION_PATH = "/account/browser-companion";
const PAIRING_SEARCH_RE = /^\?pairing=[a-f0-9]{32}$/;
export function browserCompanionReturnTo(pathname, search = "") {
    if (pathname !== BROWSER_COMPANION_PATH)
        return undefined;
    if (!search)
        return BROWSER_COMPANION_PATH;
    return PAIRING_SEARCH_RE.test(search) ? `${BROWSER_COMPANION_PATH}${search}` : BROWSER_COMPANION_PATH;
}
export function loginReturnTo(state) {
    if (typeof state !== "object" || state === null || !("returnTo" in state))
        return "/library";
    const returnTo = state.returnTo;
    if (typeof returnTo !== "string")
        return "/library";
    const queryIndex = returnTo.indexOf("?");
    const pathname = queryIndex === -1 ? returnTo : returnTo.slice(0, queryIndex);
    const search = queryIndex === -1 ? "" : returnTo.slice(queryIndex);
    return browserCompanionReturnTo(pathname, search) ?? "/library";
}
export async function logoutAndClear(client, serverLogout, navigate, rotateClient = () => undefined) {
    await serverLogout();
    endPrivateSession(client, navigate, rotateClient);
}
export function endPrivateSession(client, navigate, rotateClient, options = {}) {
    client.clear();
    rotateClient();
    if (options.accountLinkSuccess) {
        navigate("/login", { replace: true, state: { accountLinkSuccess: true } });
        return;
    }
    if (options.returnTo) {
        navigate("/login", { replace: true, state: { returnTo: options.returnTo } });
        return;
    }
    navigate("/login", { replace: true });
}
export function createPrivateQueryClient() {
    return new QueryClient({
        defaultOptions: {
            queries: {
                retry: (count, error) => !(error instanceof Error && "status" in error && error.status === 401) && count < 1,
                refetchOnWindowFocus: false,
                staleTime: 15_000,
            },
            mutations: { retry: false },
        },
    });
}
export function createSessionQueryClient(session) {
    const client = createPrivateQueryClient();
    client.setQueryData(["session"], session);
    return client;
}
function ProtectedLayout({ rotateClient }) {
    const client = useQueryClient();
    const navigate = useRouteNavigate();
    const location = useLocation();
    const session = useQuery({
        queryKey: ["session"],
        queryFn: getSession,
        retry: false,
        staleTime: 30_000,
    });
    const logoutMutation = useMutation({
        mutationFn: () => logoutAndClear(client, logout, navigate, rotateClient),
    });
    if (session.isPending) {
        return _jsx("main", { className: "route-loading", "aria-label": "\u6B63\u5728\u9A8C\u8BC1\u767B\u5F55", "aria-busy": "true", children: _jsx(BrandLogo, { className: "wordmark__sigil" }) });
    }
    if (session.isError) {
        const returnTo = browserCompanionReturnTo(location.pathname, location.search);
        return _jsx(Navigate, { to: "/login", replace: true, state: returnTo ? { returnTo } : undefined });
    }
    return (_jsx(AppShell, { loginChannel: session.data.login_channel, logoutPending: logoutMutation.isPending, logoutError: logoutMutation.isError ? "服务器尚未确认退出，请检查网络后重试。" : undefined, onLogout: () => logoutMutation.mutate(), children: _jsx(Outlet, {}) }));
}
function AccountLinkRoute({ rotateClient }) {
    const client = useQueryClient();
    const navigate = useRouteNavigate();
    const onLinked = useCallback(() => {
        endPrivateSession(client, navigate, rotateClient, { accountLinkSuccess: true });
    }, [client, navigate, rotateClient]);
    return _jsx(AccountLinkPage, { onLinked: onLinked });
}
function LoginRoute({ activateSession }) {
    const navigate = useRouteNavigate();
    const location = useLocation();
    const returnTo = loginReturnTo(location.state);
    return (_jsx(LoginPage, { onAuthenticated: (session) => {
            activateSession(session);
            navigate(returnTo, { replace: true });
        } }));
}
function UnauthorizedBoundary({ rotateClient }) {
    const client = useQueryClient();
    const navigate = useRouteNavigate();
    const location = useLocation();
    useEffect(() => {
        setUnauthorizedHandler(() => {
            endPrivateSession(client, navigate, rotateClient, {
                returnTo: browserCompanionReturnTo(location.pathname, location.search),
            });
        });
        return () => setUnauthorizedHandler(null);
    }, [client, location.pathname, location.search, navigate, rotateClient]);
    return (_jsxs(Routes, { children: [_jsx(Route, { path: "/", element: _jsx(ShowcasePage, {}) }), _jsx(Route, { path: "/showcase", element: _jsx(Navigate, { to: "/", replace: true }) }), _jsx(Route, { path: "/login", element: _jsx(LoginRoute, { activateSession: rotateClient }) }), _jsxs(Route, { element: _jsx(ProtectedLayout, { rotateClient: rotateClient }), children: [_jsx(Route, { path: "/library", element: _jsx(LibraryPage, {}) }), _jsx(Route, { path: "/chat", element: _jsx(ChatPage, { sendStream: streamConversationMessage }) }), _jsx(Route, { path: "/videos/:id", element: _jsx(VideoDetailPage, {}) }), _jsx(Route, { path: "/account/link", element: _jsx(AccountLinkRoute, { rotateClient: rotateClient }) }), _jsx(Route, { path: "/account/browser-companion", element: _jsx(BrowserCompanionPage, {}) })] }), _jsx(Route, { path: "*", element: _jsx(Navigate, { to: "/", replace: true }) })] }));
}
export function App() {
    const [client, setClient] = useState(createPrivateQueryClient);
    const rotateClient = useCallback((session) => {
        setClient(session ? createSessionQueryClient(session) : createPrivateQueryClient());
    }, []);
    return (_jsx(QueryClientProvider, { client: client, children: _jsx(HashRouter, { children: _jsx(UnauthorizedBoundary, { rotateClient: rotateClient }) }) }));
}
