import { jsx as _jsx } from "react/jsx-runtime";
import { flushSync } from "react-dom";
import { useCallback } from "react";
import { Link, useNavigate } from "react-router";
let fallbackCleanupTimer;
export function startRouteTransition(update) {
    const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    const startViewTransition = document.startViewTransition;
    if (reduceMotion) {
        update();
        return;
    }
    if (!startViewTransition) {
        window.clearTimeout(fallbackCleanupTimer);
        document.documentElement.classList.remove("route-transition--entering");
        void document.documentElement.offsetWidth;
        document.documentElement.classList.add("route-transition--entering");
        flushSync(update);
        fallbackCleanupTimer = window.setTimeout(() => {
            document.documentElement.classList.remove("route-transition--entering");
        }, 380);
        return;
    }
    const transition = startViewTransition.call(document, () => flushSync(update));
    if (transition) {
        void transition.ready.catch((error) => {
            // Chromium rejects `ready` with AbortError when a transition is
            // superseded by the update it was meant to animate (for example when
            // logout rotates the query client before navigating).  That is an
            // expected skip; preserve every other failure for the browser to report.
            if (!isSkippedTransitionError(error))
                throw error;
        });
    }
}
function isSkippedTransitionError(error) {
    return (typeof error === "object"
        && error !== null
        && "name" in error
        && error.name === "AbortError");
}
export function useRouteNavigate() {
    const navigate = useNavigate();
    return useCallback((to, options) => {
        startRouteTransition(() => navigate(to, options));
    }, [navigate]);
}
export function RouteLink({ onClick, preventScrollReset, relative, reloadDocument, replace, state, target, to, ...props }) {
    const navigate = useNavigate();
    function handleClick(event) {
        onClick?.(event);
        if (event.defaultPrevented
            || reloadDocument
            || event.button !== 0
            || event.metaKey
            || event.ctrlKey
            || event.shiftKey
            || event.altKey
            || (target !== undefined && target !== "_self")) {
            return;
        }
        event.preventDefault();
        startRouteTransition(() => navigate(to, { preventScrollReset, relative, replace, state }));
    }
    return (_jsx(Link, { ...props, onClick: handleClick, preventScrollReset: preventScrollReset, relative: relative, reloadDocument: reloadDocument, replace: replace, state: state, target: target, to: to }));
}
