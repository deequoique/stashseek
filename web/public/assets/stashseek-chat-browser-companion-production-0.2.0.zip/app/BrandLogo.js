import { jsx as _jsx } from "react/jsx-runtime";
import logoUrl from "../assets/stashseek-chat-logo.png";
export function BrandLogo({ className }) {
    return (_jsx("img", { alt: "", "aria-hidden": "true", className: ["brand-logo", className].filter(Boolean).join(" "), decoding: "async", draggable: "false", height: "1254", src: logoUrl, width: "1254" }));
}
