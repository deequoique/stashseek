import { parseWhySaved } from "./collections";
export function collectSearchSuggestions(items, query, limit = 6) {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    if (!normalizedQuery)
        return [];
    const suggestions = [];
    const seen = new Set();
    const add = (kind, rawValue) => {
        const value = rawValue?.trim();
        if (!value || !value.toLocaleLowerCase().includes(normalizedQuery))
            return;
        const key = value.toLocaleLowerCase();
        if (seen.has(key))
            return;
        seen.add(key);
        suggestions.push({ kind, value });
    };
    for (const item of items) {
        const parsedWhySaved = parseWhySaved(item.why_saved);
        add("标题", item.title);
        add("作者", item.author);
        parsedWhySaved.collections.forEach((name) => add("收藏夹", `#${name}`));
        add("保存说明", parsedWhySaved.reason);
        if (suggestions.length >= limit)
            break;
    }
    return suggestions.slice(0, limit);
}
