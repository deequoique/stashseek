import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ApiError, getCapabilities, listLibraryItems, submitVideoBatch, } from "../api/client";
import { AddVideosDialog } from "./AddVideosDialog";
import { collectCollectionNames } from "./collections";
import { LibraryEmptyState, LibraryErrorState, LibraryLoadingState } from "./LibraryStates";
import { estimateWorkItemProgress, isLibraryWorkItem, shouldPollLibrary } from "./lifecycle";
import { collectSearchSuggestions } from "./searchSuggestions";
import { VideoCard } from "./VideoCard";
import { RouteLink } from "../app/RouteTransition";
function libraryErrorDescription(error) {
    if (!(error instanceof ApiError))
        return "网络连接没有完成，请确认服务可用后重新加载。";
    if (error.status === 403)
        return "当前账户无法访问这份资料库，请重新登录或联系管理员确认权限。";
    if (error.status === 429)
        return "请求过于频繁，请稍等片刻后重新加载。";
    if (error.status >= 500)
        return "资料库服务暂时没有响应，已有内容不会丢失，请稍后重试。";
    return "资料库请求没有完成，请重新加载。";
}
export function LibraryPage({ fetchItems = listLibraryItems, loadCapabilities = getCapabilities, submitBatch = submitVideoBatch, }) {
    const queryClient = useQueryClient();
    const searchFormRef = useRef(null);
    const [dialogOpen, setDialogOpen] = useState(false);
    const [searchDraft, setSearchDraft] = useState("");
    const [search, setSearch] = useState("");
    const [suggestionsOpen, setSuggestionsOpen] = useState(false);
    const [selectedCollection, setSelectedCollection] = useState(null);
    const [knownCollections, setKnownCollections] = useState([]);
    const [lifecycle, setLifecycle] = useState("");
    const [sort, setSort] = useState("saved_desc");
    const [page, setPage] = useState(1);
    const query = {
        search,
        collection: selectedCollection ?? undefined,
        lifecycle,
        include_archived: lifecycle === "archived",
        sort,
        page,
        page_size: 20,
    };
    const library = useQuery({
        queryKey: ["library", query],
        queryFn: () => fetchItems(query),
        retry: 1,
        refetchInterval: (state) => shouldPollLibrary(state.state.data?.items ?? []) ? 4_000 : false,
    });
    const capabilities = useQuery({
        queryKey: ["capabilities"],
        queryFn: loadCapabilities,
        retry: false,
        staleTime: 5 * 60_000,
    });
    const saveDisabled = capabilities.data?.save_enabled !== true;
    const saveNoticeId = capabilities.isError || capabilities.data?.save_enabled === false
        ? "library-save-notice"
        : undefined;
    const saveButtonLabel = capabilities.isPending
        ? "正在确认添加功能"
        : capabilities.isError
            ? "无法确认添加功能"
            : saveDisabled
                ? "暂时无法添加视频"
                : "添加视频";
    useEffect(() => {
        if (!library.data)
            return;
        const discovered = collectCollectionNames(library.data.items.map((item) => item.why_saved));
        setKnownCollections((current) => {
            const next = collectCollectionNames([
                ...current.map((name) => `#${name}`),
                ...discovered.map((name) => `#${name}`),
            ]);
            return next.length === current.length && next.every((name, index) => name === current[index])
                ? current
                : next;
        });
    }, [library.data]);
    useEffect(() => {
        if (!suggestionsOpen)
            return;
        const closeOnOutsidePointer = (event) => {
            if (event.target instanceof Node && !searchFormRef.current?.contains(event.target)) {
                setSuggestionsOpen(false);
            }
        };
        document.addEventListener("pointerdown", closeOnOutsidePointer);
        return () => document.removeEventListener("pointerdown", closeOnOutsidePointer);
    }, [suggestionsOpen]);
    const collectionOptions = collectCollectionNames([
        ...knownCollections.map((name) => `#${name}`),
        selectedCollection ? `#${selectedCollection}` : null,
    ]);
    const totalPages = library.data ? Math.max(1, Math.ceil(library.data.total / library.data.page_size)) : 1;
    const readableItems = library.data?.items.filter((item) => !isLibraryWorkItem(item)) ?? [];
    const workItems = library.data?.items.filter(isLibraryWorkItem) ?? [];
    const activeWorkItems = workItems.filter(({ lifecycle: state }) => state === "queued" || state === "processing");
    const workProgress = estimateWorkItemProgress(workItems);
    const searchSuggestions = collectSearchSuggestions(library.data?.items ?? [], searchDraft);
    function submitSearch(value) {
        const nextSearch = value.trim();
        setSelectedCollection(null);
        setSearchDraft(nextSearch);
        setSearch(nextSearch);
        setSuggestionsOpen(false);
        setPage(1);
    }
    function changeFilter(next) {
        setLifecycle(next);
        setPage(1);
    }
    function selectCollection(name) {
        setSelectedCollection(name);
        setSearch("");
        setSearchDraft("");
        setPage(1);
    }
    return (_jsxs(_Fragment, { children: [_jsxs("section", { className: "library-heading", children: [_jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "\u89C6\u9891\u8D44\u6599\u5E93" }), _jsx("h1", { children: "\u6211\u7684\u89C6\u9891\u8D44\u6599\u5E93" }), _jsx("p", { children: "\u6DFB\u52A0\u89C6\u9891\u540E\uFF0C\u7CFB\u7EDF\u4F1A\u81EA\u52A8\u6574\u7406\u89C6\u9891\u4FE1\u606F\u3001\u7AE0\u8282\u548C\u5B57\u5E55\u3002" })] }), _jsxs("div", { className: "library-heading__actions", children: [capabilities.data?.chat === true ? (_jsx(RouteLink, { className: "button button--quiet", to: "/chat", children: "AI \u667A\u80FD\u68C0\u7D22" })) : null, _jsx("button", { className: "button button--primary", disabled: saveDisabled, "aria-describedby": saveNoticeId, onClick: () => setDialogOpen(true), children: saveButtonLabel })] })] }), capabilities.isError ? (_jsxs("aside", { className: "library-notice library-notice--error", id: "library-save-notice", role: "alert", children: [_jsxs("div", { children: [_jsx("strong", { children: "\u6682\u65F6\u65E0\u6CD5\u786E\u8BA4\u89C6\u9891\u6DFB\u52A0\u529F\u80FD" }), _jsx("p", { children: "\u8D44\u6599\u5E93\u4ECD\u53EF\u6D4F\u89C8\u548C\u68C0\u7D22\u3002\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u65B0\u786E\u8BA4\uFF0C\u4E0D\u9700\u8981\u5237\u65B0\u6574\u4E2A\u9875\u9762\u3002" })] }), _jsx("button", { className: "text-button", type: "button", onClick: () => void capabilities.refetch(), children: "\u91CD\u65B0\u68C0\u67E5" })] })) : null, capabilities.data?.save_enabled === false ? (_jsxs("aside", { className: "library-notice", id: "library-save-notice", role: "note", children: [_jsxs("div", { children: [_jsx("strong", { children: "\u5F53\u524D\u90E8\u7F72\u6682\u672A\u5F00\u653E\u670D\u52A1\u5668\u7AEF\u6DFB\u52A0" }), _jsx("p", { children: "\u5DF2\u6709\u89C6\u9891\u4ECD\u53EF\u9605\u8BFB\u548C\u68C0\u7D22\uFF1B\u82E5\u5DF2\u5B89\u88C5\u6D4F\u89C8\u5668\u63D2\u4EF6\uFF0C\u53EF\u4ECE\u6253\u5F00\u7684\u89C6\u9891\u9875\u9762\u4FDD\u5B58\u5B57\u5E55\u3002" })] }), _jsx(RouteLink, { className: "text-button", to: "/account/browser-companion", children: "\u67E5\u770B\u6D4F\u89C8\u5668\u63D2\u4EF6" })] })) : null, _jsxs("section", { className: "library-toolbar", "aria-label": "\u8D44\u6599\u5E93\u7B5B\u9009", children: [_jsxs("form", { ref: searchFormRef, className: "search-box", role: "search", onBlur: (event) => {
                            if (!event.currentTarget.contains(event.relatedTarget))
                                setSuggestionsOpen(false);
                        }, onSubmit: (event) => { event.preventDefault(); submitSearch(searchDraft); }, children: [_jsx("label", { className: "sr-only", htmlFor: "library-search", children: "\u641C\u7D22\u6807\u9898\u3001\u4F5C\u8005\u6216\u4FDD\u5B58\u8BF4\u660E" }), _jsx("input", { id: "library-search", name: "search", type: "search", autoComplete: "off", value: searchDraft, "aria-autocomplete": "list", "aria-controls": searchSuggestions.length > 0 ? "library-search-suggestions" : undefined, "aria-expanded": suggestionsOpen && searchSuggestions.length > 0, onChange: (event) => { setSearchDraft(event.target.value); setSuggestionsOpen(true); }, onClick: () => setSuggestionsOpen(true), onFocus: () => setSuggestionsOpen(true), onKeyDown: (event) => { if (event.key === "Escape")
                                    setSuggestionsOpen(false); }, placeholder: "\u641C\u7D22\u6807\u9898\u3001\u4F5C\u8005\u6216\u4FDD\u5B58\u8BF4\u660E" }), suggestionsOpen && searchSuggestions.length > 0 ? (_jsx("ul", { id: "library-search-suggestions", className: "search-suggestions", "aria-label": "\u641C\u7D22\u5EFA\u8BAE", children: searchSuggestions.map((suggestion) => (_jsx("li", { children: _jsxs("button", { type: "button", title: suggestion.value, "aria-label": `${suggestion.kind} ${suggestion.value}`, onMouseDown: (event) => event.preventDefault(), onClick: () => submitSearch(suggestion.value), children: [_jsx("span", { children: suggestion.kind }), _jsx("strong", { children: suggestion.value })] }) }, `${suggestion.kind}:${suggestion.value.toLocaleLowerCase()}`))) })) : null, _jsx("button", { type: "submit", children: "\u641C\u7D22" })] }), _jsxs("label", { className: "select-field", children: [_jsx("span", { className: "sr-only", children: "\u6309\u5904\u7406\u72B6\u6001\u7B5B\u9009" }), _jsxs("select", { name: "lifecycle", value: lifecycle, onChange: (event) => changeFilter(event.target.value), children: [_jsx("option", { value: "", children: "\u5168\u90E8\u72B6\u6001" }), _jsx("option", { value: "ready", children: "\u53EF\u9605\u8BFB" }), _jsx("option", { value: "queued", children: "\u7B49\u5F85\u6574\u7406" }), _jsx("option", { value: "processing", children: "\u6B63\u5728\u6574\u7406" }), _jsx("option", { value: "needs_action", children: "\u5B57\u5E55\u4E0D\u53EF\u7528" }), _jsx("option", { value: "failed", children: "\u6574\u7406\u5931\u8D25" }), _jsx("option", { value: "archived", children: "\u5DF2\u5F52\u6863" })] })] }), _jsxs("label", { className: "select-field", children: [_jsx("span", { className: "sr-only", children: "\u6392\u5E8F\u65B9\u5F0F" }), _jsxs("select", { name: "sort", value: sort, onChange: (event) => { setSort(event.target.value); setPage(1); }, children: [_jsx("option", { value: "saved_desc", children: "\u6700\u8FD1\u6DFB\u52A0" }), _jsx("option", { value: "saved_asc", children: "\u6700\u65E9\u6DFB\u52A0" }), _jsx("option", { value: "title_asc", children: "\u6309\u6807\u9898" })] })] })] }), collectionOptions.length > 0 ? (_jsxs("nav", { className: "collection-filter", "aria-label": "\u6536\u85CF\u5939\u7B5B\u9009", children: [_jsx("span", { className: "collection-filter__label", children: "\u6536\u85CF\u5939" }), _jsxs("div", { className: "collection-options", children: [_jsx("button", { className: "collection-chip", type: "button", "aria-pressed": selectedCollection === null, onClick: () => selectCollection(null), children: "\u5168\u90E8\u89C6\u9891" }), collectionOptions.map((name) => (_jsx("button", { className: "collection-chip", type: "button", "aria-pressed": selectedCollection?.toLocaleLowerCase("en") === name.toLocaleLowerCase("en"), onClick: () => selectCollection(name), children: name }, name)))] })] })) : null, library.isPending ? _jsx(LibraryLoadingState, {}) : null, library.isError ? _jsx(LibraryErrorState, { description: libraryErrorDescription(library.error), onRetry: () => void library.refetch() }) : null, library.isSuccess && library.data.items.length === 0 ? (_jsx(LibraryEmptyState, { trueFirstEmpty: library.data.is_true_first_empty && !query.search && !lifecycle, onAdd: saveDisabled ? undefined : () => setDialogOpen(true) })) : null, library.isSuccess && library.data.items.length > 0 ? (_jsxs(_Fragment, { children: [_jsxs("div", { className: "library-summary", children: [_jsxs("span", { "aria-label": "\u5F53\u524D\u53EF\u9605\u8BFB\u89C6\u9891\u6570\u91CF", children: [readableItems.length, " \u4E2A\u89C6\u9891"] }), shouldPollLibrary(library.data.items) ? _jsxs("span", { className: "live-note", "aria-live": "polite", children: [_jsx("i", {}), "\u6B63\u5728\u81EA\u52A8\u66F4\u65B0\u72B6\u6001"] }) : null] }), readableItems.length > 0 ? (_jsx("section", { className: "library-ready-zone", "aria-label": "\u53EF\u9605\u8BFB\u89C6\u9891", children: _jsx("div", { className: `video-grid${readableItems.length === 3 ? " video-grid--trio" : ""}`, children: readableItems.map((item) => _jsx(VideoCard, { item: item }, item.public_id)) }) })) : null, workItems.length > 0 ? (_jsxs("section", { className: "library-work-zone", "aria-labelledby": "library-work-zone-title", children: [_jsxs("header", { className: "library-work-zone__header", children: [_jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "\u6574\u7406\u72B6\u6001" }), _jsx("h2", { id: "library-work-zone-title", children: "\u6574\u7406\u961F\u5217" })] }), _jsxs("span", { "aria-label": "\u6574\u7406\u961F\u5217\u89C6\u9891\u6570\u91CF", children: [workItems.length, " \u4E2A\u89C6\u9891"] })] }), _jsx("div", { className: "video-grid", children: workItems.map((item) => _jsx(VideoCard, { item: item }, item.public_id)) }), activeWorkItems.length > 0 ? _jsxs("div", { className: "work-progress", children: [_jsxs("div", { className: "work-progress__label", children: [_jsx("span", { children: "\u5F53\u524D\u6574\u7406\u8FDB\u5EA6" }), _jsxs("strong", { children: ["\u7EA6 ", workProgress, "%"] })] }), _jsx("progress", { "aria-label": "\u5F53\u524D\u6574\u7406\u8FDB\u5EA6", "aria-valuetext": `约 ${workProgress}%`, max: "100", value: workProgress }), _jsx("small", { children: "\u4EC5\u6839\u636E\u6B63\u5728\u5904\u7406\u9879\u76EE\u7684\u5F53\u524D\u9636\u6BB5\u4F30\u7B97" })] }) : null] })) : null, totalPages > 1 ? (_jsxs("nav", { className: "pagination", "aria-label": "\u8D44\u6599\u5E93\u5206\u9875", children: [_jsx("button", { className: "button button--ghost", disabled: page <= 1, onClick: () => setPage((value) => Math.max(1, value - 1)), children: "\u4E0A\u4E00\u9875" }), _jsxs("span", { children: ["\u7B2C ", page, " / ", totalPages, " \u9875"] }), _jsx("button", { className: "button button--ghost", disabled: page >= totalPages, onClick: () => setPage((value) => value + 1), children: "\u4E0B\u4E00\u9875" })] })) : null] })) : null, _jsx(AddVideosDialog, { open: dialogOpen && !saveDisabled, onClose: () => setDialogOpen(false), submitBatch: submitBatch, suggestedCollections: collectionOptions, onSubmitted: () => void queryClient.invalidateQueries({ queryKey: ["library"] }) })] }));
}
