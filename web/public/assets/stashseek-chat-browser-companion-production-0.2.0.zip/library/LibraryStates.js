import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { BrandLogo } from "../app/BrandLogo";
export function LibraryEmptyState({ trueFirstEmpty, onAdd }) {
    if (!trueFirstEmpty) {
        return (_jsxs("section", { className: "state-card state-card--compact", children: [_jsx("p", { className: "eyebrow", children: "\u7B5B\u9009\u7ED3\u679C" }), _jsx("h2", { children: "\u6CA1\u6709\u7B26\u5408\u5F53\u524D\u6761\u4EF6\u7684\u89C6\u9891" }), _jsx("p", { children: "\u8BF7\u66F4\u6362\u5173\u952E\u8BCD\u6216\u7B5B\u9009\u6761\u4EF6\u3002" })] }));
    }
    return (_jsxs("section", { className: "state-card welcome-card", children: [_jsx(BrandLogo, { className: "agent-mark" }), _jsx("p", { className: "eyebrow", children: "\u5F00\u59CB\u4F7F\u7528" }), _jsx("h2", { children: "\u8D44\u6599\u5E93\u8FD8\u662F\u7A7A\u7684" }), _jsx("p", { children: "\u53EF\u4EE5\u6DFB\u52A0 YouTube \u6216 Bilibili \u666E\u901A\u89C6\u9891\u94FE\u63A5\uFF0C\u4E5F\u53EF\u4EE5\u5728\u89C6\u9891\u9875\u9762\u6253\u5F00\u641C\u85CF\u52A9\u624B\u4FA7\u8FB9\u680F\u4E00\u952E\u6536\u85CF\u3002" }), onAdd ? _jsx("button", { className: "button button--primary", onClick: onAdd, children: "\u6DFB\u52A0\u7B2C\u4E00\u4E2A\u89C6\u9891" }) : null] }));
}
export function LibraryLoadingState({ label = "正在加载资料库" } = {}) {
    return (_jsx("div", { className: "skeleton-list", "aria-label": label, "aria-busy": "true", children: [0, 1, 2].map((index) => _jsx("div", { className: "video-skeleton" }, index)) }));
}
export function LibraryErrorState({ onRetry, title = "暂时无法打开资料库", description = "请检查网络后重新加载。", }) {
    return (_jsxs("section", { className: "state-card state-card--compact", role: "alert", children: [_jsx("p", { className: "eyebrow", children: "\u52A0\u8F7D\u5931\u8D25" }), _jsx("h2", { children: title }), _jsx("p", { children: description }), _jsx("button", { className: "button button--quiet", onClick: onRetry, children: "\u91CD\u65B0\u52A0\u8F7D" })] }));
}
