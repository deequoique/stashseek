import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { ApiError, submitVideoBatch } from "../api/client";
import { collectCollectionNames, formatWhySaved, parseWhySaved, validateCollectionName, WHY_SAVED_MAX_LENGTH, } from "./collections";
const resultCopy = {
    queued: "已添加，等待整理",
    already_exists: "资料库中已有此视频",
    unsupported_url: "暂不支持这个链接",
    invalid_url: "链接格式不正确",
    queue_unavailable: "暂时无法开始整理，请稍后重试",
    create_failed: "添加失败，请稍后重试",
    quota_exceeded: "已达到保存上限",
};
function submitErrorCopy(error) {
    if (!(error instanceof ApiError))
        return "无法连接资料库，请检查网络后重试。";
    switch (error.code) {
        case "save_disabled":
            return "当前部署暂未开放服务器端添加，请改用浏览器插件或稍后再试。";
        case "quota_exceeded":
            return "当前资料库已达到保存上限，可以先归档旧视频后再试。";
        case "queue_unavailable":
            return "视频链接已收到，但整理队列暂时不可用，请稍后重新提交。";
        default:
            return error.status >= 500
                ? "资料库服务暂时没有响应，请稍后重试。"
                : "添加没有完成，请检查链接后重试。";
    }
}
export function AddVideosDialog({ open, onClose, suggestedCollections = [], submitBatch = submitVideoBatch, onSubmitted, }) {
    const dialogRef = useRef(null);
    const [urls, setUrls] = useState([]);
    const [urlDraft, setUrlDraft] = useState("");
    const [whySaved, setWhySaved] = useState("");
    const [selectedCollection, setSelectedCollection] = useState(null);
    const [newCollection, setNewCollection] = useState("");
    const [createdCollections, setCreatedCollections] = useState([]);
    const [collectionError, setCollectionError] = useState(null);
    const [error, setError] = useState(null);
    const [result, setResult] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const submissionGenerationRef = useRef(0);
    useEffect(() => {
        const dialog = dialogRef.current;
        if (!dialog)
            return;
        if (open) {
            if (!dialog.open)
                dialog.showModal();
            return;
        }
        if (dialog.open)
            dialog.close();
        submissionGenerationRef.current += 1;
        setUrls([]);
        setUrlDraft("");
        setWhySaved("");
        setSelectedCollection(null);
        setNewCollection("");
        setCreatedCollections([]);
        setCollectionError(null);
        setError(null);
        setResult(null);
        setSubmitting(false);
    }, [open]);
    const collectionOptions = collectCollectionNames([
        ...suggestedCollections.map((name) => `#${name}`),
        ...createdCollections.map((name) => `#${name}`),
    ]);
    function selectCollection(name) {
        setSelectedCollection(name);
        setCollectionError(null);
    }
    function createCollection() {
        const validationError = validateCollectionName(newCollection);
        if (validationError) {
            setCollectionError(validationError);
            return;
        }
        const formatted = formatWhySaved("", newCollection);
        const name = parseWhySaved(formatted.value).collections[0];
        if (!name)
            return;
        setCreatedCollections((current) => collectCollectionNames([
            ...current.map((value) => `#${value}`),
            `#${name}`,
        ]));
        setSelectedCollection(name);
        setNewCollection("");
        setCollectionError(null);
    }
    function addUrlTags(values) {
        const normalized = values.map((value) => value.trim()).filter(Boolean);
        if (normalized.length === 0)
            return;
        setUrls((current) => [...current, ...normalized]);
        setError(null);
    }
    function commitUrlDraft() {
        if (!urlDraft.trim())
            return;
        addUrlTags([urlDraft]);
        setUrlDraft("");
    }
    function removeUrl(index) {
        setUrls((current) => current.filter((_, currentIndex) => currentIndex !== index));
    }
    async function handleSubmit(event) {
        event.preventDefault();
        const submittedUrls = [...urls, urlDraft.trim()].filter(Boolean);
        if (submittedUrls.length === 0) {
            setError("请至少粘贴一个 YouTube 或 Bilibili 链接。");
            return;
        }
        if (submittedUrls.length > 10) {
            setError("一次最多添加 10 个链接。");
            return;
        }
        const formattedWhySaved = formatWhySaved(whySaved, selectedCollection);
        if (formattedWhySaved.error) {
            setError(formattedWhySaved.error);
            return;
        }
        setError(null);
        setUrls(submittedUrls);
        setUrlDraft("");
        setSubmitting(true);
        const submissionGeneration = ++submissionGenerationRef.current;
        try {
            const nextResult = await submitBatch({ urls: submittedUrls, why_saved: formattedWhySaved.value });
            if (submissionGeneration !== submissionGenerationRef.current)
                return;
            setResult(nextResult);
            onSubmitted?.(nextResult);
        }
        catch (submitError) {
            if (submissionGeneration !== submissionGenerationRef.current)
                return;
            setError(submitErrorCopy(submitError));
        }
        finally {
            if (submissionGeneration === submissionGenerationRef.current)
                setSubmitting(false);
        }
    }
    return (_jsx("dialog", { className: "add-dialog", ref: dialogRef, "aria-labelledby": "add-dialog-title", onCancel: (event) => {
            event.preventDefault();
            onClose();
        }, children: _jsxs("form", { className: "add-form", onSubmit: handleSubmit, children: [_jsxs("header", { className: "dialog-header", children: [_jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "\u4E00\u6B21\u6700\u591A\u6DFB\u52A0 10 \u4E2A" }), _jsx("h2", { id: "add-dialog-title", children: "\u6DFB\u52A0\u89C6\u9891\u94FE\u63A5" })] }), _jsx("button", { className: "icon-button", type: "button", "aria-label": "\u5173\u95ED\u6DFB\u52A0\u89C6\u9891\u7A97\u53E3", onClick: onClose, children: "\u00D7" })] }), _jsxs("div", { className: "field url-field", children: [_jsxs("span", { className: "field-label-row", children: [_jsx("label", { htmlFor: "url-draft", children: "YouTube \u6216 Bilibili \u94FE\u63A5\uFF0C\u6BCF\u884C\u4E00\u4E2A" }), _jsxs("small", { className: "url-count", "data-over-limit": urls.length > 10, children: [urls.length, " / 10"] })] }), _jsx("p", { className: "field-help", id: "url-draft-help", children: "\u7C98\u8D34\u94FE\u63A5\u540E\u6309 Enter\uFF1B\u4E5F\u53EF\u4EE5\u4E00\u6B21\u7C98\u8D34\u591A\u884C\u3002" }), _jsxs("p", { className: "field-help", children: ["\u652F\u6301 YouTube \u4E0E Bilibili \u666E\u901A\u89C6\u9891\u94FE\u63A5\u3002\u670D\u52A1\u5668\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u7684\u89C6\u9891\uFF0C\u53EF\u4EE5\u5728\u89C6\u9891\u9875\u9762\u6253\u5F00\u641C\u85CF\u52A9\u624B\u4FA7\u8FB9\u680F\u6536\u85CF\uFF0C\u8BE6\u89C1", _jsx("a", { href: "/account/browser-companion", children: "\u6D4F\u89C8\u5668\u4F34\u4FA3" }), "\u3002"] }), _jsxs("div", { className: "url-token-input", children: [urls.length > 0 ? (_jsx("ol", { className: "url-tag-list", "aria-label": "\u5DF2\u6DFB\u52A0\u7684\u89C6\u9891\u94FE\u63A5", children: urls.map((url, index) => (_jsxs("li", { className: "url-tag", children: [_jsx("span", { title: url, children: url }), _jsx("button", { type: "button", "aria-label": `移除链接 ${index + 1}`, onClick: () => removeUrl(index), children: "\u00D7" })] }, `${url}-${index}`))) })) : null, _jsx("textarea", { id: "url-draft", className: "url-draft-input", name: "urls", "aria-describedby": "url-draft-help", autoComplete: "off", spellCheck: false, rows: 1, value: urlDraft, placeholder: urls.length === 0 ? "粘贴 YouTube 或 Bilibili 链接" : "继续添加链接", onChange: (event) => {
                                        const next = event.target.value;
                                        if (/\r?\n/u.test(next)) {
                                            addUrlTags(next.split(/\r?\n/u));
                                            setUrlDraft("");
                                            return;
                                        }
                                        setUrlDraft(next);
                                    }, onKeyDown: (event) => {
                                        if (event.key !== "Enter")
                                            return;
                                        event.preventDefault();
                                        commitUrlDraft();
                                    } })] })] }), _jsxs("fieldset", { className: "collection-picker", children: [_jsx("legend", { children: "\u4FDD\u5B58\u5230\u6536\u85CF\u5939\uFF08\u53EF\u9009\uFF09" }), _jsx("p", { className: "field-help", children: "\u9009\u62E9\u5DF2\u6709\u6536\u85CF\u5939\uFF0C\u6216\u65B0\u5EFA\u4E00\u4E2A\u6807\u7B7E\u3002\u672A\u9009\u62E9\u65F6\u4FDD\u5B58\u4E3A\u672A\u5F52\u7C7B\u3002" }), _jsxs("div", { className: "collection-options", "aria-label": "\u9009\u62E9\u6536\u85CF\u5939", children: [_jsx("button", { className: "collection-chip", type: "button", "aria-pressed": selectedCollection === null, onClick: () => selectCollection(null), children: "\u672A\u5F52\u7C7B" }), collectionOptions.map((name) => (_jsx("button", { className: "collection-chip", type: "button", "aria-pressed": selectedCollection?.toLocaleLowerCase("en") === name.toLocaleLowerCase("en"), onClick: () => selectCollection(name), children: name }, name)))] }), _jsxs("div", { className: "collection-create", children: [_jsxs("label", { className: "field", children: [_jsx("span", { children: "\u65B0\u6536\u85CF\u5939\u540D\u79F0" }), _jsx("input", { name: "new-collection", autoComplete: "off", value: newCollection, maxLength: 21, placeholder: "\u4F8B\u5982\uFF1A\u4EA7\u54C1\u8C03\u7814", onChange: (event) => setNewCollection(event.target.value) })] }), _jsx("button", { className: "button button--quiet", type: "button", onClick: createCollection, children: "\u521B\u5EFA\u5E76\u9009\u62E9" })] }), collectionError ? _jsx("p", { className: "inline-error", role: "alert", children: collectionError }) : null] }), _jsxs("div", { className: "field", children: [_jsxs("span", { className: "field-label-row", children: [_jsx("label", { htmlFor: "why-saved", children: "\u5907\u6CE8\uFF08\u53EF\u9009\uFF09" }), _jsxs("small", { children: [whySaved.length, " / ", WHY_SAVED_MAX_LENGTH] })] }), _jsx("textarea", { id: "why-saved", className: "why-saved-textarea", name: "why-saved", autoComplete: "off", value: whySaved, rows: 3, maxLength: WHY_SAVED_MAX_LENGTH, placeholder: "\u4F8B\u5982\uFF1A\u7528\u4E8E\u5468\u672B\u7CBE\u8BFB\u6216\u9879\u76EE\u8C03\u7814", onChange: (event) => setWhySaved(event.target.value) })] }), error ? _jsx("p", { className: "inline-error", role: "alert", children: error }) : null, result ? (_jsx("ol", { className: "submission-results", "aria-label": "\u6DFB\u52A0\u7ED3\u679C", "aria-live": "polite", children: result.results.map((item) => (_jsxs("li", { "data-status": item.status, children: [_jsxs("span", { children: ["\u7B2C ", item.input_index + 1, " \u4E2A\u94FE\u63A5"] }), _jsx("strong", { children: resultCopy[item.status] ?? "未能确认处理结果，请稍后查看资料库" })] }, `${item.input_index}-${item.status}`))) })) : null, _jsx("button", { className: "button button--primary button--wide", disabled: submitting, type: "submit", children: submitting ? "正在添加…" : "添加并整理" })] }) }));
}
