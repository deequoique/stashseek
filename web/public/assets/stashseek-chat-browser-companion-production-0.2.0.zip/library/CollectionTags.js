import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
export function CollectionTags({ names, className = "" }) {
    if (names.length === 0)
        return null;
    return (_jsx("ul", { className: `collection-tag-list ${className}`.trim(), "aria-label": "\u6240\u5C5E\u6536\u85CF\u5939", children: names.map((name) => (_jsxs("li", { className: "collection-tag", children: ["#", name] }, name.toLocaleLowerCase("en")))) }));
}
