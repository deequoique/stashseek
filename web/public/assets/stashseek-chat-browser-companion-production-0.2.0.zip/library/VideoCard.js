import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { RouteLink } from "../app/RouteTransition";
import { CollectionTags } from "./CollectionTags";
import { parseWhySaved } from "./collections";
import { lifecycleCopy } from "./lifecycle";
export function formatDuration(seconds) {
    if (seconds === null || !Number.isFinite(seconds) || seconds < 0)
        return null;
    const total = Math.floor(seconds);
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const remaining = total % 60;
    return hours > 0
        ? `${hours}:${String(minutes).padStart(2, "0")}:${String(remaining).padStart(2, "0")}`
        : `${minutes}:${String(remaining).padStart(2, "0")}`;
}
export function VideoCard({ item }) {
    const duration = formatDuration(item.duration_sec);
    const title = item.title?.trim() || "视频信息尚未准备好";
    const savedContext = parseWhySaved(item.why_saved);
    const canEditSavedContext = item.available_actions.includes("edit_why_saved");
    return (_jsxs("article", { className: `video-card${canEditSavedContext ? " video-card--editable" : ""}`, "data-lifecycle": item.lifecycle, children: [_jsxs(RouteLink, { className: "video-card__link", to: `/videos/${item.public_id}`, "aria-label": `${title}，查看详情`, children: [_jsxs("div", { className: "video-card__cover", children: [item.cover_url ? _jsx("img", { src: item.cover_url, alt: "", width: 960, height: 540, loading: "lazy", decoding: "async" }) : _jsx("div", { className: "cover-placeholder", "aria-hidden": "true", children: _jsx("span", { children: "\u6682\u65E0\u5C01\u9762" }) }), duration ? _jsx("span", { className: "duration-badge", children: duration }) : null] }), _jsxs("div", { className: "video-card__body", children: [_jsxs("div", { className: "video-card__topline", children: [_jsx("span", { className: `status-pill status-pill--${item.lifecycle}`, children: lifecycleCopy[item.lifecycle].label }), _jsx("time", { dateTime: item.saved_at, children: new Intl.DateTimeFormat("zh-CN", { month: "short", day: "numeric" }).format(new Date(item.saved_at)) })] }), _jsx("h2", { children: title }), item.author ? _jsx("p", { className: "video-card__author", children: item.author }) : null, _jsx(CollectionTags, { names: savedContext.collections }), savedContext.reason ? _jsx("blockquote", { children: savedContext.reason }) : null, item.lifecycle === "failed" ? _jsx("p", { className: "card-hint", children: "\u6253\u5F00\u8BE6\u60C5\u540E\u53EF\u91CD\u65B0\u6574\u7406" }) : null] })] }), canEditSavedContext ? (_jsx(RouteLink, { className: "video-card__manage", to: `/videos/${item.public_id}#saved-context`, "aria-label": `编辑《${title}》的保存说明和收藏夹`, children: "\u7F16\u8F91\u5F52\u7C7B" })) : null] }));
}
