import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
/**
 * Open until `collapseWhen` turns true, then collapse once; the user may reopen it.
 * Turning `collapseWhen` false again re-arms the collapse and reopens the block.
 */
export function useAutoCollapse(collapseWhen) {
    const [expanded, setExpanded] = useState(true);
    const collapsed = useRef(false);
    useEffect(() => {
        if (!collapseWhen) {
            collapsed.current = false;
            setExpanded(true);
            return;
        }
        if (!collapsed.current) {
            collapsed.current = true;
            setExpanded(false);
        }
    }, [collapseWhen]);
    return [expanded, setExpanded];
}
/**
 * Collapsible, tool-call-style list of steps: a spinner on the running step, a check on
 * finished steps, and failed or skipped states. Used by the workspace answer timeline and
 * the side panel thread.
 */
export function StepTimeline({ summary, steps, expanded, onToggle, stepsLabel = "Agent 执行步骤", className, children, }) {
    return (_jsxs("details", { className: className ? `chat-execution ${className}` : "chat-execution", open: expanded, onToggle: (event) => onToggle(event.currentTarget.open), children: [_jsxs("summary", { children: [_jsx("span", { children: summary }), _jsx("small", { children: expanded ? "收起" : "展开" })] }), _jsxs("div", { className: "chat-execution__body", children: [children, steps.length ? (_jsx("ol", { className: "chat-execution-steps", "aria-label": stepsLabel, children: steps.map((step) => (_jsxs("li", { className: step.detail ? `is-${step.outcome} has-detail` : `is-${step.outcome}`, children: [_jsx("span", { "aria-hidden": "true" }), step.detail ? (_jsxs("div", { children: [_jsx("p", { children: step.text }), step.detail] })) : (_jsx("p", { children: step.text }))] }, step.id))) })) : null] })] }));
}
