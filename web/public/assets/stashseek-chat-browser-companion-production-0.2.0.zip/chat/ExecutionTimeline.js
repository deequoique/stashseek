import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { StepTimeline, useAutoCollapse } from "./StepTimeline";
const STEP_COPY = {
    updating_plan: { running: "正在整理处理步骤", completed: "已更新本轮计划" },
    searching_library: { running: "正在搜索资料库", completed: "已完成资料库搜索" },
    reading_context: { running: "正在读取相关上下文", completed: "已读取相关上下文" },
    checking_source: { running: "正在核对来源", completed: "已核对来源" },
    reviewing_library: { running: "正在查看资料库", completed: "已查看资料库" },
    checking_item: { running: "正在查看条目", completed: "已查看条目" },
    handling_save: { running: "正在处理保存请求", completed: "已处理保存请求" },
    managing_library: { running: "正在处理资料库操作", completed: "已处理资料库操作" },
    working: { running: "正在执行一个步骤", completed: "步骤已完成" },
};
const PLAN_STATUS_COPY = {
    pending: "待处理",
    in_progress: "进行中",
    completed: "已完成",
    blocked: "受阻",
};
function completedWithCount(step) {
    if (step.resultCount === undefined)
        return STEP_COPY[step.code].completed;
    if (step.code === "searching_library") {
        return step.resultCount === 0 ? "未找到匹配片段" : `找到 ${step.resultCount} 个相关片段`;
    }
    if (step.code === "reading_context")
        return `已读取 ${step.resultCount} 个相关片段`;
    if (step.code === "reviewing_library")
        return `找到 ${step.resultCount} 个资料库条目`;
    if (["handling_save", "managing_library"].includes(step.code)) {
        return `已处理 ${step.resultCount} 个条目`;
    }
    return STEP_COPY[step.code].completed;
}
export function executionStepCopy(step) {
    if (step.outcome === "running")
        return STEP_COPY[step.code].running;
    if (step.outcome === "failed")
        return `${STEP_COPY[step.code].running.replace(/^正在/, "")}未能完成`;
    if (step.outcome === "skipped")
        return `已跳过：${STEP_COPY[step.code].running.replace(/^正在/, "")}`;
    return completedWithCount(step);
}
export function ExecutionTimeline({ steps, plan, answerStarted }) {
    const [expanded, setExpanded] = useAutoCollapse(answerStarted);
    if (!steps.length && !plan.length)
        return null;
    const completedSteps = steps.filter((step) => step.outcome !== "running").length;
    const runningStep = steps.find((step) => step.outcome === "running");
    const summary = runningStep
        ? executionStepCopy(runningStep)
        : `执行过程 · ${completedSteps} 个步骤`;
    return (_jsx(StepTimeline, { summary: summary, steps: steps.map((step) => ({ id: step.stepId, text: executionStepCopy(step), outcome: step.outcome })), expanded: expanded, onToggle: setExpanded, children: plan.length ? (_jsxs("section", { className: "chat-execution-plan", "aria-label": "\u672C\u8F6E\u8BA1\u5212", children: [_jsx("p", { children: "\u672C\u8F6E\u8BA1\u5212" }), _jsx("ol", { children: plan.map((item) => (_jsxs("li", { className: `is-${item.status}`, children: [_jsx("span", { "aria-hidden": "true" }), _jsx("strong", { children: item.title }), _jsx("small", { children: PLAN_STATUS_COPY[item.status] })] }, item.id))) })] })) : null }));
}
