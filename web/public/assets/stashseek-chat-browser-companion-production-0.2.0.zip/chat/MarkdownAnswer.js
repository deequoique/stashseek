import { jsx as _jsx } from "react/jsx-runtime";
import Markdown from "react-markdown";
export function MarkdownAnswer({ children }) {
    return (_jsx("div", { className: "chat-markdown", children: _jsx(Markdown, { components: {
                a: ({ children: linkText }) => _jsx("span", { children: linkText }),
                img: ({ alt }) => _jsx("span", { children: alt ?? "" }),
            }, children: children }) }));
}
