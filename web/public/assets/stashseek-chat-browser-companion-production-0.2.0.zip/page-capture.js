const SAFE_ERRORS = new Set([
    "unsupported_page",
    "capture_unavailable",
    "kaltura_entry_missing",
    "caption_fetch_failed",
    "caption_parse_failed",
    "caption_player_not_ready",
    "stale_player_response",
]);
function isSafeError(value) {
    return typeof value === "string" && SAFE_ERRORS.has(value);
}
function isFiniteCue(value) {
    if (!value || typeof value !== "object")
        return false;
    const cue = value;
    return typeof cue.text === "string"
        && cue.text.trim().length > 0
        && cue.text.length <= 10_000
        && typeof cue.start_sec === "number"
        && Number.isFinite(cue.start_sec)
        && cue.start_sec >= 0
        && typeof cue.end_sec === "number"
        && Number.isFinite(cue.end_sec)
        && cue.end_sec >= cue.start_sec;
}
function isHttpsUrl(value) {
    if (typeof value !== "string")
        return false;
    try {
        const parsed = new URL(value);
        return parsed.protocol === "https:" && !parsed.username && !parsed.password;
    }
    catch {
        return false;
    }
}
function isPublicCaptureUrl(value, platform, platformId, field) {
    if (!isHttpsUrl(value))
        return false;
    try {
        const parsed = new URL(value);
        if (parsed.hash || parsed.username || parsed.password)
            return false;
        if (platform === "youtube") {
            if (parsed.hostname !== "www.youtube.com")
                return false;
            let onlyVideoId = true;
            parsed.searchParams.forEach((_value, key) => { if (key !== "v")
                onlyVideoId = false; });
            return parsed.pathname === "/watch" && parsed.searchParams.get("v") === platformId && onlyVideoId;
        }
        if (platform === "bilibili") {
            if (parsed.hostname !== "www.bilibili.com" || parsed.pathname !== `/video/${platformId}`)
                return false;
            if (field === "canonical")
                return !parsed.search;
            // A page URL keeps only a part index above 1.
            return !parsed.search || /^\?p=(?:[2-9]|[1-9][0-9]{1,3})$/.test(parsed.search);
        }
        const canonicalHost = parsed.hostname === "ntulearn.ntu.edu.sg"
            || parsed.hostname === "ntulearnvideo.ntu.edu.sg";
        const pageHost = canonicalHost || parsed.hostname === "ntulearnv1.ntu.edu.sg";
        if (parsed.search || (field === "canonical" ? !canonicalHost : !pageHost))
            return false;
        return field === "page" || parsed.pathname.includes(platformId);
    }
    catch {
        return false;
    }
}
function isPageCapture(value) {
    if (!value || typeof value !== "object")
        return false;
    const capture = value;
    if (capture.platform !== "youtube" && capture.platform !== "ntu_kaltura" && capture.platform !== "bilibili")
        return false;
    if (typeof capture.platform_id !== "string")
        return false;
    if (capture.platform === "youtube" && !/^[A-Za-z0-9_-]{11}$/.test(capture.platform_id))
        return false;
    if (capture.platform === "bilibili" && !/^(?:BV[0-9A-Za-z]{10}|av[0-9]{1,20})$/.test(capture.platform_id))
        return false;
    if (capture.platform === "ntu_kaltura" && !/^[0-9]+_[A-Za-z0-9]+$/.test(capture.platform_id))
        return false;
    if (!isPublicCaptureUrl(capture.canonical_url, capture.platform, capture.platform_id, "canonical")
        || !isPublicCaptureUrl(capture.page_url, capture.platform, capture.platform_id, "page"))
        return false;
    const metadata = capture.metadata;
    if (!metadata || typeof metadata !== "object")
        return false;
    const metadataRecord = metadata;
    if (metadataRecord.title !== null && (typeof metadataRecord.title !== "string" || metadataRecord.title.length > 1_000))
        return false;
    if (metadataRecord.author !== null && (typeof metadataRecord.author !== "string" || metadataRecord.author.length > 1_000))
        return false;
    if (metadataRecord.duration_sec !== null
        && (typeof metadataRecord.duration_sec !== "number" || !Number.isInteger(metadataRecord.duration_sec)
            || metadataRecord.duration_sec < 0 || metadataRecord.duration_sec > 31_536_000))
        return false;
    if (metadataRecord.language !== null && (typeof metadataRecord.language !== "string" || metadataRecord.language.length > 64))
        return false;
    if (metadataRecord.description !== null && (typeof metadataRecord.description !== "string" || metadataRecord.description.length > 50_000))
        return false;
    if (metadataRecord.cover_url !== null && !isHttpsUrl(metadataRecord.cover_url))
        return false;
    if (metadataRecord.cover_url !== null) {
        try {
            const cover = new URL(metadataRecord.cover_url);
            const expectedHost = (capture.platform === "youtube" && cover.hostname === "i.ytimg.com")
                || (capture.platform === "bilibili" && (cover.hostname === "hdslb.com" || cover.hostname.endsWith(".hdslb.com")));
            if (!expectedHost || cover.search || cover.hash || cover.username || cover.password)
                return false;
        }
        catch {
            return false;
        }
    }
    if (!Array.isArray(metadataRecord.tags) || metadataRecord.tags.length > 100
        || !metadataRecord.tags.every((tag) => typeof tag === "string" && tag.trim().length > 0 && tag.length <= 200))
        return false;
    if (!Array.isArray(metadataRecord.chapters) || metadataRecord.chapters.length > 1_000
        || !metadataRecord.chapters.every((value) => {
            if (!value || typeof value !== "object")
                return false;
            const chapter = value;
            return typeof chapter.title === "string" && chapter.title.trim().length > 0 && chapter.title.length <= 500
                && typeof chapter.start_sec === "number" && Number.isFinite(chapter.start_sec) && chapter.start_sec >= 0
                && (chapter.end_sec === null || (typeof chapter.end_sec === "number" && Number.isFinite(chapter.end_sec)
                    && chapter.end_sec >= chapter.start_sec));
        }))
        return false;
    const caption = capture.caption;
    if (!caption || typeof caption !== "object")
        return false;
    const captionRecord = caption;
    if (!Array.isArray(captionRecord.cues) || captionRecord.cues.length > 50_000 || !captionRecord.cues.every(isFiniteCue))
        return false;
    let priorStart = -1;
    let textLength = 0;
    for (const value of captionRecord.cues) {
        const cue = value;
        if (cue.start_sec < priorStart)
            return false;
        priorStart = cue.start_sec;
        textLength += cue.text.length;
        if (textLength > 1_000_000)
            return false;
    }
    if (captionRecord.status === "available") {
        return (captionRecord.source === "official_cc" || captionRecord.source === "auto_caption")
            && typeof captionRecord.language === "string"
            && captionRecord.language.trim().length > 0
            && captionRecord.cues.length > 0;
    }
    return captionRecord.status === "unavailable"
        && captionRecord.source === null
        && captionRecord.language === null
        && captionRecord.cues.length === 0;
}
/** Validates and rebuilds a capture so only the public capture.v1 fields survive. */
export function normalizePageCapture(value) {
    try {
        const cloned = structuredClone(value);
        if (!isPageCapture(cloned))
            return null;
        const metadata = cloned.metadata;
        const caption = cloned.caption.status === "available"
            ? {
                status: "available",
                source: cloned.caption.source,
                language: cloned.caption.language,
                cues: cloned.caption.cues.map((cue) => ({ start_sec: cue.start_sec, end_sec: cue.end_sec, text: cue.text })),
            }
            : { status: "unavailable", source: null, language: null, cues: [] };
        return {
            platform: cloned.platform,
            platform_id: cloned.platform_id,
            canonical_url: cloned.canonical_url,
            page_url: cloned.page_url,
            metadata: {
                title: metadata.title,
                author: metadata.author,
                duration_sec: metadata.duration_sec,
                language: metadata.language,
                description: metadata.description,
                cover_url: metadata.cover_url,
                tags: [...metadata.tags],
                chapters: metadata.chapters.map((chapter) => ({
                    title: chapter.title,
                    start_sec: chapter.start_sec,
                    end_sec: chapter.end_sec,
                })),
            },
            caption,
        };
    }
    catch {
        return null;
    }
}
function captureScore(capture) {
    const title = capture.metadata.title?.trim().toLowerCase() ?? "";
    const genericTitle = /^(media gallery|kaltura(?: media)? player|ntu learn|ntu learn video [a-z0-9_]+)$/.test(title);
    let canonicalHost = "";
    try {
        canonicalHost = new URL(capture.canonical_url).hostname;
    }
    catch { /* Validation filters this in normal use. */ }
    return (capture.caption.status === "available" ? 10_000 + capture.caption.cues.length : 0)
        + (capture.metadata.duration_sec !== null ? 200 : 0)
        + (title && !genericTitle ? 50 : 0)
        + (canonicalHost === "ntulearnvideo.ntu.edu.sg" ? 10 : 0);
}
export function selectBestCapture(captures) {
    return captures.map(normalizePageCapture).filter((capture) => capture !== null).reduce((best, candidate) => (!best || captureScore(candidate) > captureScore(best)
        || (captureScore(candidate) === captureScore(best) && JSON.stringify(candidate) < JSON.stringify(best)) ? candidate : best), undefined);
}
function normalizeAttempt(value) {
    try {
        const directCapture = normalizePageCapture(value);
        if (directCapture) {
            return { status: directCapture.caption.status === "available" ? "captured" : "no_caption", capture: directCapture };
        }
        if (!value || typeof value !== "object")
            return null;
        const attempt = structuredClone(value);
        if (attempt.status === "not_media_frame")
            return { status: "not_media_frame" };
        if (attempt.status === "captured" || attempt.status === "no_caption") {
            const capture = normalizePageCapture(attempt.capture);
            if (!capture)
                return null;
            if (attempt.status === "captured" && capture.caption.status !== "available")
                return null;
            if (attempt.status === "no_caption" && capture.caption.status !== "unavailable")
                return null;
            return { status: attempt.status, capture };
        }
        if (attempt.status === "failed" && isSafeError(attempt.error))
            return { status: "failed", error: attempt.error };
        return null;
    }
    catch {
        return null;
    }
}
function aggregateAttempts(platform, values) {
    const attempts = values.map(normalizeAttempt).filter((attempt) => attempt !== null);
    const captures = attempts.flatMap((attempt) => (attempt.status === "captured" || attempt.status === "no_caption") ? [attempt.capture] : []);
    const selected = selectBestCapture(captures);
    if (selected?.caption.status === "available")
        return selected;
    const failures = attempts.flatMap((attempt) => attempt.status === "failed" ? [attempt.error] : []);
    const retryableFailure = failures.find((error) => error === "caption_fetch_failed" || error === "caption_parse_failed");
    if (retryableFailure)
        throw new Error(retryableFailure);
    if (failures.includes("stale_player_response"))
        throw new Error("stale_player_response");
    if (selected)
        return selected;
    if (platform === "ntu_kaltura" && attempts.length > 0 && attempts.every((attempt) => attempt.status === "not_media_frame")) {
        throw new Error("kaltura_entry_missing");
    }
    throw new Error(failures[0] ?? "capture_unavailable");
}
/** Maps a tab URL to the supported media adapter, or null for any other page. */
export function classifyPageUrl(url) {
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        return null;
    }
    if (parsed.protocol !== "https:")
        return null;
    const host = parsed.hostname.toLowerCase();
    const youtubeHost = host === "www.youtube.com" || host === "youtube.com" || host === "youtu.be";
    const youtubeShape = host === "youtu.be"
        ? /^\/[A-Za-z0-9_-]{11}(?:\/)?$/.test(parsed.pathname)
        : (parsed.pathname === "/watch" && /^[A-Za-z0-9_-]{11}$/.test(parsed.searchParams.get("v") ?? ""))
            || /^\/shorts\/[A-Za-z0-9_-]{11}(?:\/)?$/.test(parsed.pathname);
    const kalturaHost = host === "ntulearn.ntu.edu.sg"
        || host === "ntulearnvideo.ntu.edu.sg"
        || host === "ntulearnv1.ntu.edu.sg";
    if (youtubeHost && youtubeShape)
        return "youtube";
    if (bilibiliVideoRef(url))
        return "bilibili";
    return kalturaHost ? "ntu_kaltura" : null;
}
/**
 * The normalized id (`BV…` or `av…`, as the server connector derives it) and the
 * 1-based part of a Bilibili video page URL, or null for any other URL. An absent
 * or malformed `p` means part 1, as on Bilibili itself.
 */
export function bilibiliVideoRef(url) {
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        return null;
    }
    if (parsed.protocol !== "https:" || parsed.hostname.toLowerCase() !== "www.bilibili.com")
        return null;
    const match = /^\/video\/((?:[aA][vV])[0-9]{1,20}|(?:[bB][vV])[0-9A-Za-z]{10})\/?$/.exec(parsed.pathname);
    if (!match)
        return null;
    const raw = match[1];
    const id = (raw.slice(0, 2).toLowerCase() === "bv" ? "BV" : "av") + raw.slice(2);
    const values = parsed.searchParams.getAll("p");
    const part = values.length === 1 && /^[1-9][0-9]{0,3}$/.test(values[0]) ? Number(values[0]) : 1;
    return { id, part };
}
export async function captureActivePage(tabId, url) {
    const kind = classifyPageUrl(url);
    if (!kind)
        throw new Error("unsupported_page");
    const injection = kind === "youtube" ? captureYouTubePage
        : kind === "bilibili" ? captureBilibiliPage
            : captureKalturaPage;
    const allFrames = kind === "ntu_kaltura";
    let results;
    try {
        results = await chrome.scripting.executeScript({
            target: { tabId, allFrames },
            world: "MAIN",
            func: injection,
        });
    }
    catch {
        // A single inaccessible frame can reject an all-frames call. The top
        // frame is still useful for outer NTULearn pages and gives a stable error.
        if (!allFrames)
            throw new Error("capture_unavailable");
        try {
            results = await chrome.scripting.executeScript({
                target: { tabId, allFrames: false },
                world: "MAIN",
                func: injection,
            });
        }
        catch {
            throw new Error("capture_unavailable");
        }
    }
    const values = results.flatMap((value) => {
        try {
            if (!value || typeof value !== "object")
                return [];
            return [value.result];
        }
        catch {
            return [];
        }
    });
    return aggregateAttempts(kind, values);
}
/** MAIN-world YouTube adapter; keep this function self-contained for MV3. */
export async function captureYouTubePage() {
    const clean = (value) => value
        .replace(/<[^>]+>/g, " ")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/gi, "'")
        .replace(/\s+/g, " ")
        .replace(/\s+([,.;:!?])/g, "$1")
        .trim();
    const fail = (error) => ({ status: "failed", error });
    try {
        const currentUrl = new URL(location.href);
        const id = currentUrl.hostname === "youtu.be"
            ? currentUrl.pathname.split("/").filter(Boolean)[0] ?? ""
            : currentUrl.searchParams.get("v") ?? currentUrl.pathname.split("/").filter(Boolean).at(-1) ?? "";
        if (!/^[A-Za-z0-9_-]{11}$/.test(id))
            return fail("unsupported_page");
        const captureDeadline = Date.now() + 10_000;
        const responseControllers = new WeakMap();
        const abortResponse = (response) => {
            try {
                responseControllers.get(response)?.abort();
            }
            catch { /* A test/page response may not be weak-map compatible. */ }
        };
        const fetchBeforeDeadline = async (input, init) => {
            const remaining = captureDeadline - Date.now();
            if (remaining <= 0)
                throw new Error("caption_fetch_timeout");
            const controller = typeof AbortController === "function" ? new AbortController() : undefined;
            const requestInit = controller ? { ...(init ?? {}), signal: controller.signal } : init;
            let timedOut = false;
            let timer;
            try {
                const response = await Promise.race([
                    fetch(input, requestInit),
                    new Promise((_resolve, reject) => {
                        timer = setTimeout(() => {
                            timedOut = true;
                            try {
                                controller?.abort();
                            }
                            catch { /* AbortController is best effort in page shims. */ }
                            reject(new Error("caption_fetch_timeout"));
                        }, Math.min(1_200, remaining));
                    }),
                ]);
                if (controller)
                    responseControllers.set(response, controller);
                return response;
            }
            finally {
                if (timer !== undefined)
                    clearTimeout(timer);
                if (timedOut) {
                    try {
                        controller?.abort();
                    }
                    catch { /* Already aborted or unavailable. */ }
                }
            }
        };
        const readResponseBeforeDeadline = async (reader, onTimeout) => {
            const remaining = captureDeadline - Date.now();
            if (remaining <= 0)
                throw new Error("caption_body_timeout");
            let timer;
            try {
                return await Promise.race([
                    Promise.resolve().then(reader),
                    new Promise((_resolve, reject) => {
                        timer = setTimeout(() => {
                            try {
                                onTimeout?.();
                            }
                            catch { /* Cleanup is best effort. */ }
                            reject(new Error("caption_body_timeout"));
                        }, Math.min(1_200, remaining));
                    }),
                ]);
            }
            finally {
                if (timer !== undefined)
                    clearTimeout(timer);
            }
        };
        const MAX_YOUTUBE_RESPONSE_BYTES = 4_000_000;
        const readResponseText = async (response) => {
            const stream = response.body;
            if (stream && typeof stream.getReader === "function") {
                const streamReader = stream.getReader();
                const chunks = [];
                let totalBytes = 0;
                const cancelReader = () => {
                    try {
                        const cancel = streamReader.cancel;
                        if (typeof cancel !== "function")
                            return;
                        const pending = cancel.call(streamReader);
                        if (pending && typeof pending.then === "function")
                            void pending.catch(() => undefined);
                    }
                    catch { /* A body can already be closed by the browser. */ }
                };
                try {
                    while (true) {
                        const next = await readResponseBeforeDeadline(() => streamReader.read(), () => {
                            abortResponse(response);
                            cancelReader();
                        });
                        if (next.done)
                            break;
                        const chunk = next.value;
                        if (!(chunk instanceof Uint8Array)) {
                            abortResponse(response);
                            cancelReader();
                            throw new Error("caption_body_unavailable");
                        }
                        totalBytes += chunk.byteLength;
                        if (totalBytes > MAX_YOUTUBE_RESPONSE_BYTES) {
                            abortResponse(response);
                            cancelReader();
                            throw new Error("caption_body_too_large");
                        }
                        chunks.push(chunk);
                    }
                }
                finally {
                    try {
                        streamReader.releaseLock();
                    }
                    catch { /* A consumed body is already released. */ }
                }
                const bytes = new Uint8Array(totalBytes);
                let offset = 0;
                for (const chunk of chunks) {
                    bytes.set(chunk, offset);
                    offset += chunk.byteLength;
                }
                const text = typeof TextDecoder === "function"
                    ? new TextDecoder().decode(bytes)
                    : String.fromCharCode(...bytes);
                if (text.length > MAX_YOUTUBE_RESPONSE_BYTES) {
                    abortResponse(response);
                    cancelReader();
                    throw new Error("caption_body_too_large");
                }
                return text;
            }
            const reader = response;
            if (typeof reader.text !== "function")
                throw new Error("caption_body_unavailable");
            const text = await readResponseBeforeDeadline(() => reader.text(), () => abortResponse(response));
            if (text.length > MAX_YOUTUBE_RESPONSE_BYTES) {
                abortResponse(response);
                throw new Error("caption_body_too_large");
            }
            return text;
        };
        const readResponseJson = async (response) => {
            const reader = response;
            // Real browser Responses are read as text first so a trusted endpoint
            // cannot hand an unbounded body straight to JSON.parse. The JSON-only
            // fallback keeps the page-world adapter compatible with lightweight
            // test doubles and older embedded player shims.
            if (typeof reader.text === "function"
                || (reader.body && typeof reader.body.getReader === "function")) {
                const text = await readResponseText(response);
                return JSON.parse(text);
            }
            if (typeof reader.json === "function") {
                return readResponseBeforeDeadline(() => reader.json(), () => abortResponse(response));
            }
            throw new Error("caption_body_unavailable");
        };
        const currentVideoId = () => {
            try {
                const current = new URL(location.href);
                return current.hostname === "youtu.be"
                    ? current.pathname.split("/").filter(Boolean)[0] ?? ""
                    : current.searchParams.get("v") ?? current.pathname.split("/").filter(Boolean).at(-1) ?? "";
            }
            catch {
                return "";
            }
        };
        const isCurrentVideo = () => currentVideoId() === id;
        const page = globalThis;
        const responses = [];
        const addResponse = (value, depth = 0) => {
            if (depth > 2 || value === null || value === undefined)
                return;
            let parsed = value;
            if (typeof parsed === "string") {
                try {
                    parsed = JSON.parse(parsed);
                }
                catch {
                    return;
                }
            }
            if (!parsed || typeof parsed !== "object")
                return;
            const record = parsed;
            if (record.videoDetails || record.captions)
                responses.push(record);
            const args = record.args && typeof record.args === "object" ? record.args : null;
            const playerVars = record.PLAYER_VARS && typeof record.PLAYER_VARS === "object" ? record.PLAYER_VARS : null;
            for (const nested of [record.playerResponse, record.player_response, record.raw_player_response, args?.player_response, args?.playerResponse, args?.raw_player_response, playerVars?.player_response])
                addResponse(nested, depth + 1);
        };
        const playerElement = (() => {
            try {
                if (typeof document.getElementById === "function") {
                    const moviePlayer = document.getElementById("movie_player");
                    if (moviePlayer)
                        return moviePlayer;
                }
                if (typeof document.querySelector === "function")
                    return document.querySelector("ytd-player");
            }
            catch { /* The player element may be replaced during navigation. */ }
            return null;
        })();
        const holders = [page.movie_player, page.ytdPlayer, page.ytplayer, page.ytPlayer, playerElement];
        const selectedTrackHints = [];
        for (const holder of holders) {
            try {
                const player = holder;
                if (player && typeof player.getPlayerResponse === "function")
                    addResponse(player.getPlayerResponse());
                if (player && typeof player.getOption === "function") {
                    const selected = player.getOption("captions", "track");
                    if (selected && typeof selected === "object") {
                        selectedTrackHints.push(selected);
                        const nested = selected.track;
                        if (nested && typeof nested === "object")
                            selectedTrackHints.push(nested);
                    }
                }
            }
            catch { /* Player can be replaced during SPA navigation. */ }
        }
        for (const holder of [page.ytplayer?.config, page.ytPlayer?.config, page.ytplayerConfig])
            addResponse(holder);
        addResponse(page.ytInitialPlayerResponse);
        const responseId = (response) => {
            const details = response.videoDetails;
            if (!details || typeof details !== "object")
                return null;
            const value = details.videoId;
            return typeof value === "string" ? value : null;
        };
        const accepted = responses.filter((response) => {
            const candidateId = responseId(response);
            return candidateId === null || candidateId === id;
        });
        if (!responses.length)
            return fail("capture_unavailable");
        if (!accepted.length)
            return fail("stale_player_response");
        const identifiedResponses = responses.filter((candidate) => responseId(candidate) !== null);
        if (identifiedResponses.length && !identifiedResponses.some((candidate) => responseId(candidate) === id)) {
            return fail("stale_player_response");
        }
        const captionRenderer = (response) => {
            const captions = response.captions;
            if (!captions || typeof captions !== "object")
                return null;
            const renderer = captions.playerCaptionsTracklistRenderer;
            return renderer && typeof renderer === "object" ? renderer : null;
        };
        const trackList = (response) => {
            const tracks = captionRenderer(response)?.captionTracks;
            return Array.isArray(tracks) ? tracks.filter((track) => Boolean(track && typeof track === "object")) : [];
        };
        const exactResponses = accepted.filter((candidate) => responseId(candidate) === id);
        const responsePool = exactResponses.length ? exactResponses : accepted;
        const response = responsePool.find((candidate) => trackList(candidate).length > 0) ?? responsePool[0];
        const tracks = trackList(response);
        const details = response.videoDetails && typeof response.videoDetails === "object" ? response.videoDetails : {};
        const title = typeof details.title === "string"
            ? clean(details.title).slice(0, 1000)
            : clean(typeof document.title === "string" ? document.title.replace(/\s*-\s*YouTube\s*$/i, "") : "").slice(0, 1000) || null;
        const author = typeof details.author === "string" ? clean(details.author).slice(0, 1000) || null : null;
        const durationValue = Number(details.lengthSeconds);
        const duration = Number.isFinite(durationValue) && durationValue >= 0 ? Math.floor(durationValue) : null;
        // The description keeps its line structure; only control characters are dropped.
        const description = (() => {
            if (typeof details.shortDescription !== "string")
                return null;
            const text = Array.from(details.shortDescription.replace(/\r\n?/g, "\n"))
                .filter((character) => {
                const code = character.codePointAt(0) ?? 0;
                return code === 9 || code === 10 || (code >= 32 && code !== 127);
            })
                .join("")
                .trim()
                .slice(0, 50_000)
                .trim();
            return text || null;
        })();
        // Best-effort chapters from the player-bar markers. YouTube's SPA navigation
        // does not refresh `ytInitialData`, so it is only trusted while it still
        // describes this video; any other shape yields no chapters.
        const chapters = (() => {
            try {
                const data = page.ytInitialData;
                if (!data || typeof data !== "object")
                    return [];
                const endpoint = data.currentVideoEndpoint;
                const watchEndpoint = endpoint && typeof endpoint === "object"
                    ? endpoint.watchEndpoint
                    : null;
                const dataVideoId = watchEndpoint && typeof watchEndpoint === "object"
                    ? watchEndpoint.videoId
                    : null;
                if (dataVideoId !== id)
                    return [];
                const markerLists = [];
                const queue = [data];
                const seen = new Set();
                for (let inspected = 0; inspected < queue.length && inspected < 50_000; inspected += 1) {
                    const value = queue[inspected];
                    if (!value || typeof value !== "object" || seen.has(value))
                        continue;
                    seen.add(value);
                    const record = value;
                    if (Array.isArray(record.markersMap)) {
                        for (const entry of record.markersMap) {
                            if (!entry || typeof entry !== "object")
                                continue;
                            const marker = entry;
                            const markerValue = marker.value && typeof marker.value === "object" ? marker.value : null;
                            if (typeof marker.key === "string" && markerValue && Array.isArray(markerValue.chapters)) {
                                markerLists.push({ key: marker.key, items: markerValue.chapters });
                            }
                        }
                    }
                    if (Array.isArray(value))
                        queue.push(...value);
                    else
                        queue.push(...Object.values(record));
                }
                const preferred = markerLists.find((list) => list.key === "DESCRIPTION_CHAPTERS")
                    ?? markerLists.find((list) => list.key === "AUTO_CHAPTERS")
                    ?? markerLists[0];
                if (!preferred)
                    return [];
                const parsed = [];
                for (const item of preferred.items.slice(0, 2_000)) {
                    const renderer = item && typeof item === "object" ? item.chapterRenderer : null;
                    if (!renderer || typeof renderer !== "object")
                        continue;
                    const fields = renderer;
                    const titleObject = fields.title && typeof fields.title === "object" ? fields.title : {};
                    const runs = Array.isArray(titleObject.runs) ? titleObject.runs : [];
                    const rawTitle = typeof titleObject.simpleText === "string"
                        ? titleObject.simpleText
                        : runs.map((run) => typeof run?.text === "string" ? run.text : "").join("");
                    const chapterTitle = clean(rawTitle).slice(0, 500).trim();
                    const rawStart = fields.timeRangeStartMillis;
                    const startMs = typeof rawStart === "number" ? rawStart
                        : typeof rawStart === "string" && /^\d+$/.test(rawStart) ? Number(rawStart) : Number.NaN;
                    if (!chapterTitle || !Number.isFinite(startMs) || startMs < 0)
                        continue;
                    parsed.push({ title: chapterTitle, start_sec: startMs / 1000 });
                }
                const ordered = parsed
                    .sort((left, right) => left.start_sec - right.start_sec)
                    .filter((chapter, index, all) => index === 0 || chapter.start_sec > all[index - 1].start_sec)
                    .slice(0, 1_000);
                return ordered.map((chapter, index) => ({
                    title: chapter.title,
                    start_sec: chapter.start_sec,
                    end_sec: ordered[index + 1]?.start_sec ?? (duration !== null && duration >= chapter.start_sec ? duration : null),
                }));
            }
            catch {
                return [];
            }
        })();
        const baseCapture = (caption) => ({
            platform: "youtube",
            platform_id: id,
            canonical_url: `https://www.youtube.com/watch?v=${id}`,
            page_url: `https://www.youtube.com/watch?v=${id}`,
            metadata: { title, author, duration_sec: duration, language: caption.status === "available" ? caption.language : null, description, cover_url: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`, tags: [], chapters },
            caption,
        });
        if (!tracks.length)
            return { status: "no_caption", capture: baseCapture({ status: "unavailable", source: null, language: null, cues: [] }) };
        const normalizeCues = (cues) => cues
            .filter((cue) => Number.isFinite(cue.start_sec) && Number.isFinite(cue.end_sec)
            && cue.start_sec >= 0 && cue.end_sec >= cue.start_sec && clean(cue.text))
            .map((cue) => ({ start_sec: cue.start_sec, end_sec: cue.end_sec, text: clean(cue.text) }))
            .sort((left, right) => left.start_sec - right.start_sec);
        const transcriptRendererCues = (renderers) => {
            const unique = new Map();
            for (const renderer of renderers) {
                const startMs = Number(renderer.startMs);
                const endMs = Number(renderer.endMs);
                const snippet = renderer.snippet && typeof renderer.snippet === "object"
                    ? renderer.snippet
                    : {};
                const runs = Array.isArray(snippet.runs) ? snippet.runs : [];
                const text = clean(runs.map((run) => typeof run.text === "string" ? run.text : "").join("")
                    || (typeof snippet.simpleText === "string" ? snippet.simpleText : ""));
                if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || startMs < 0 || endMs < startMs || !text)
                    continue;
                const cue = { start_sec: startMs / 1000, end_sec: endMs / 1000, text };
                unique.set(`${startMs}\u0000${endMs}\u0000${text}`, cue);
            }
            return normalizeCues([...unique.values()]);
        };
        const parseJson3 = (body) => {
            const events = body && typeof body === "object" && Array.isArray(body.events)
                ? body.events
                : [];
            return normalizeCues(events.flatMap((event) => {
                if (!event || typeof event !== "object")
                    return [];
                const startMs = Number(event.tStartMs);
                const durationMs = Number(event.dDurationMs ?? 0);
                const segments = Array.isArray(event.segs) ? event.segs : [];
                const text = clean(segments.map((segment) => typeof segment.utf8 === "string" ? segment.utf8 : "").join(""));
                const start = startMs / 1000;
                const end = (startMs + durationMs) / 1000;
                return Number.isFinite(startMs) && Number.isFinite(durationMs) && startMs >= 0 && durationMs >= 0
                    && Number.isFinite(end) && end >= start && text ? [{ start_sec: start, end_sec: end, text }] : [];
            }));
        };
        const parseClock = (value) => {
            const parts = value.trim().replace(",", ".").split(":").map(Number);
            if (!parts.length || parts.some((part) => !Number.isFinite(part) || part < 0))
                return Number.NaN;
            return parts.reduce((total, part) => total * 60 + part, 0);
        };
        const parseTimedText = (value) => {
            const text = value.replace(/\r/g, "").trim();
            if (!text)
                return [];
            if (text.startsWith("{")) {
                try {
                    const jsonCues = parseJson3(JSON.parse(text));
                    if (jsonCues.length)
                        return jsonCues;
                }
                catch { /* Continue with text formats. */ }
            }
            const blockCues = text.split(/\n{2,}/).flatMap((block) => {
                const lines = block.split("\n").map((line) => line.trim()).filter(Boolean);
                const timingIndex = lines.findIndex((line) => line.includes("-->"));
                if (timingIndex < 0)
                    return [];
                const match = lines[timingIndex].match(/^([^\s]+)\s+-->\s+([^\s]+)/);
                if (!match)
                    return [];
                const start = parseClock(match[1]);
                const end = parseClock(match[2]);
                const cueText = clean(lines.slice(timingIndex + 1).join(" "));
                return Number.isFinite(start) && Number.isFinite(end) && end >= start && cueText
                    ? [{ start_sec: start, end_sec: end, text: cueText }]
                    : [];
            });
            const xmlCues = Array.from(text.matchAll(/<text\b([^>]*)>([\s\S]*?)<\/text>/gi)).flatMap((match) => {
                const attributes = match[1] ?? "";
                const attribute = (name) => {
                    const found = attributes.match(new RegExp(`${name}\\s*=\\s*["']([^"']+)["']`, "i"));
                    return found?.[1] ?? "";
                };
                const start = Number(attribute("start"));
                const duration = Number(attribute("dur"));
                const end = start + duration;
                const cueText = clean(match[2] ?? "");
                return Number.isFinite(start) && Number.isFinite(duration) && start >= 0 && duration >= 0
                    && Number.isFinite(end) && end >= start && cueText
                    ? [{ start_sec: start, end_sec: end, text: cueText }]
                    : [];
            });
            return normalizeCues([...blockCues, ...xmlCues]);
        };
        const isAuto = (track) => track.kind === "asr" || (typeof track.vssId === "string" && track.vssId.startsWith("a."));
        const sameTrack = (hint, track) => {
            if (typeof hint.baseUrl === "string")
                return hint.baseUrl === track.baseUrl;
            if (typeof hint.vssId === "string")
                return hint.vssId === track.vssId;
            if (typeof hint.languageCode !== "string" || hint.languageCode !== track.languageCode)
                return false;
            return hint.kind === undefined || hint.kind === track.kind;
        };
        const preferredIndices = [];
        const addPreferredIndex = (value) => {
            const index = typeof value === "number" ? value
                : typeof value === "string" && /^\d+$/.test(value) ? Number(value) : Number.NaN;
            if (Number.isInteger(index) && index >= 0 && index < tracks.length && !preferredIndices.includes(index))
                preferredIndices.push(index);
        };
        for (const hint of selectedTrackHints)
            addPreferredIndex(tracks.findIndex((track) => sameTrack(hint, track)));
        const renderer = captionRenderer(response);
        addPreferredIndex(renderer?.defaultCaptionTrackIndex);
        const audioTracks = Array.isArray(renderer?.audioTracks)
            ? renderer.audioTracks.filter((track) => Boolean(track && typeof track === "object"))
            : [];
        const rawDefaultAudioIndex = renderer?.defaultAudioTrackIndex;
        const defaultAudioIndex = typeof rawDefaultAudioIndex === "number" ? rawDefaultAudioIndex
            : typeof rawDefaultAudioIndex === "string" && /^\d+$/.test(rawDefaultAudioIndex) ? Number(rawDefaultAudioIndex) : Number.NaN;
        if (Number.isInteger(defaultAudioIndex) && defaultAudioIndex >= 0 && defaultAudioIndex < audioTracks.length) {
            addPreferredIndex(audioTracks[defaultAudioIndex]?.defaultCaptionTrackIndex);
        }
        audioTracks.forEach((audioTrack) => addPreferredIndex(audioTrack.defaultCaptionTrackIndex));
        const fallbackIndices = tracks.map((_track, index) => index)
            .sort((left, right) => Number(isAuto(tracks[left])) - Number(isAuto(tracks[right])));
        const ordered = [...preferredIndices, ...fallbackIndices.filter((index) => !preferredIndices.includes(index))]
            .map((index) => tracks[index]);
        const trustedCaptionResponse = (result) => {
            if (!result.ok)
                return false;
            if (!result.url)
                return true;
            try {
                const finalUrl = new URL(result.url);
                const finalHost = finalUrl.hostname.toLowerCase();
                const trustedFinalHost = finalHost === "youtube.com" || finalHost.endsWith(".youtube.com")
                    || finalHost === "googlevideo.com" || finalHost.endsWith(".googlevideo.com");
                return finalUrl.protocol === "https:" && !finalUrl.username && !finalUrl.password && trustedFinalHost
                    && /timedtext|caption|subtitle/i.test(finalUrl.pathname);
            }
            catch {
                return false;
            }
        };
        const captured = (track, cues) => {
            const languageValue = track.languageCode ?? track.languageName;
            const language = typeof languageValue === "string" && clean(languageValue).length > 0 ? clean(languageValue).slice(0, 64) : "und";
            return {
                status: "captured",
                capture: baseCapture({ status: "available", source: isAuto(track) ? "auto_caption" : "official_cc", language, cues }),
            };
        };
        const POT_CLIENT_KEYS = ["potc", "c", "cver", "cplayer", "cos", "cosver", "cplatform", "cbr", "cbrver", "cbrand", "xorb", "xobt", "xovt"];
        const MAX_POT_PARAM_CHARS = 2_048;
        const POT_WAIT_MS = 3_500;
        const POT_REAPPLY_AFTER_MS = 1_200;
        const potParamsFromUrl = (value) => {
            if (typeof value !== "string" || value.length > 16_384 || !value.includes("/api/timedtext"))
                return null;
            try {
                const url = new URL(value, currentUrl);
                const host = url.hostname.toLowerCase();
                if (url.protocol !== "https:" || url.username || url.password
                    || !(host === "youtube.com" || host.endsWith(".youtube.com")) || url.pathname !== "/api/timedtext")
                    return null;
                if (url.searchParams.get("v") !== id)
                    return null;
                const pot = url.searchParams.get("pot");
                if (!pot || pot.length > MAX_POT_PARAM_CHARS)
                    return null;
                const params = [["pot", pot]];
                for (const key of POT_CLIENT_KEYS) {
                    const found = url.searchParams.get(key);
                    if (found !== null && found.length <= MAX_POT_PARAM_CHARS)
                        params.push([key, found]);
                }
                return params;
            }
            catch {
                return null;
            }
        };
        const potFromResources = () => {
            try {
                const timing = page.performance;
                if (!timing || typeof timing.getEntriesByType !== "function")
                    return null;
                const entries = timing.getEntriesByType("resource");
                for (let index = entries.length - 1; index >= 0; index -= 1) {
                    const params = potParamsFromUrl(entries[index]?.name);
                    if (params)
                        return params;
                }
            }
            catch { /* Resource timing is best effort. */ }
            return null;
        };
        const adShowing = () => {
            try {
                const element = typeof document.getElementById === "function" ? document.getElementById("movie_player") : null;
                return Boolean(element?.classList?.contains("ad-showing"));
            }
            catch {
                return false;
            }
        };
        const captionPlayer = [playerElement, page.movie_player].find((holder) => Boolean(holder) && typeof holder.setOption === "function") ?? null;
        const activeCaptionTrack = (player) => {
            try {
                const value = player.getOption?.("captions", "track");
                if (!value || typeof value !== "object")
                    return null;
                const language = value.languageCode;
                return typeof language === "string" && language.length > 0 ? value : null;
            }
            catch {
                return null;
            }
        };
        const pause = (milliseconds) => new Promise((resolve) => { setTimeout(resolve, milliseconds); });
        // Briefly turns a caption track on so the player requests it, watches for that
        // request, then puts the viewer's caption state back (also works while paused).
        const discoverPotByEnablingCaptions = async (player) => {
            const previous = activeCaptionTrack(player);
            // With captions already on, ask for a different track so the player has to fetch again.
            const requested = (previous ? ordered.find((track) => track.languageCode !== previous.languageCode) : undefined)
                ?? ordered[0] ?? tracks[0];
            const requestedLanguage = typeof requested.languageCode === "string" && requested.languageCode.length > 0
                ? requested.languageCode
                : null;
            const trackOption = requestedLanguage
                ? { languageCode: requestedLanguage, ...(isAuto(requested) ? { kind: "asr" } : {}) }
                : null;
            if (!trackOption && typeof player.toggleSubtitlesOn !== "function")
                return null;
            const apply = () => {
                if (trackOption)
                    player.setOption?.("captions", "track", trackOption);
                else
                    player.toggleSubtitlesOn?.();
            };
            const seen = { params: null };
            let observer = null;
            let touched = false;
            try {
                const Observer = page.PerformanceObserver;
                if (typeof Observer === "function") {
                    try {
                        observer = new Observer((list) => {
                            for (const entry of list.getEntries())
                                seen.params = potParamsFromUrl(entry.name) ?? seen.params;
                        });
                        observer.observe({ type: "resource" });
                    }
                    catch {
                        observer = null;
                    }
                }
                touched = true;
                try {
                    player.loadModule?.("captions");
                }
                catch { /* The module may already be loaded. */ }
                apply();
                const startedAt = Date.now();
                const waitUntil = Math.min(startedAt + POT_WAIT_MS, captureDeadline - 2_500);
                let reapplied = false;
                while (!seen.params && Date.now() < waitUntil && isCurrentVideo()) {
                    await pause(100);
                    seen.params = seen.params ?? potFromResources();
                    if (!seen.params && !reapplied && Date.now() - startedAt >= POT_REAPPLY_AFTER_MS) {
                        reapplied = true;
                        try {
                            apply();
                        }
                        catch { /* Keep waiting for the first request. */ }
                    }
                }
            }
            catch { /* Restore the caption state below whatever happened. */ }
            finally {
                try {
                    observer?.disconnect();
                }
                catch { /* Already disconnected. */ }
                if (touched) {
                    try {
                        if (previous)
                            player.setOption?.("captions", "track", previous);
                        else if (typeof player.unloadModule === "function")
                            player.unloadModule("captions");
                        else
                            player.toggleSubtitles?.();
                    }
                    catch { /* Restoring the viewer's caption state is best effort. */ }
                }
            }
            return seen.params;
        };
        let potParams = potFromResources();
        if (!potParams) {
            // Never touch the captions while an ad owns the player; a retry follows the ad.
            if (adShowing())
                return fail("caption_player_not_ready");
            if (captionPlayer)
                potParams = await discoverPotByEnablingCaptions(captionPlayer);
        }
        if (!isCurrentVideo())
            return fail("stale_player_response");
        const withPot = (url) => {
            const next = new URL(url);
            for (const [key, value] of potParams ?? [])
                next.searchParams.set(key, value);
            return next;
        };
        const errors = [];
        for (const track of ordered) {
            const rawUrl = typeof track.baseUrl === "string" ? track.baseUrl : "";
            let baseCaptionUrl;
            try {
                baseCaptionUrl = new URL(rawUrl, currentUrl);
                const host = baseCaptionUrl.hostname.toLowerCase();
                const trustedHost = host === "youtube.com" || host.endsWith(".youtube.com") || host === "googlevideo.com" || host.endsWith(".googlevideo.com");
                if (baseCaptionUrl.protocol !== "https:" || baseCaptionUrl.username || baseCaptionUrl.password
                    || !trustedHost || !/timedtext|caption|subtitle/i.test(baseCaptionUrl.pathname))
                    throw new Error("bad_url");
            }
            catch {
                errors.push("caption_fetch_failed");
                continue;
            }
            const jsonUrl = withPot(baseCaptionUrl);
            jsonUrl.searchParams.set("fmt", "json3");
            let jsonResponse;
            try {
                jsonResponse = await fetchBeforeDeadline(jsonUrl.toString(), { credentials: "include" });
            }
            catch {
                errors.push("caption_fetch_failed");
                continue;
            }
            if (!trustedCaptionResponse(jsonResponse)) {
                errors.push("caption_fetch_failed");
                continue;
            }
            try {
                const cues = parseJson3(await readResponseJson(jsonResponse));
                if (cues.length)
                    return isCurrentVideo() ? captured(track, cues) : fail("stale_player_response");
            }
            catch { /* Try text formats using fresh requests. */ }
            errors.push("caption_parse_failed");
            const vttUrl = withPot(baseCaptionUrl);
            vttUrl.searchParams.set("fmt", "vtt");
            const fallbackUrls = Array.from(new Set([vttUrl.toString(), withPot(baseCaptionUrl).toString()]));
            for (const fallbackUrl of fallbackUrls) {
                let fallbackResponse;
                try {
                    fallbackResponse = await fetchBeforeDeadline(fallbackUrl, { credentials: "include" });
                }
                catch {
                    errors.push("caption_fetch_failed");
                    continue;
                }
                if (!trustedCaptionResponse(fallbackResponse)) {
                    errors.push("caption_fetch_failed");
                    continue;
                }
                try {
                    const cues = parseTimedText(await readResponseText(fallbackResponse));
                    if (cues.length)
                        return isCurrentVideo() ? captured(track, cues) : fail("stale_player_response");
                }
                catch { /* Continue to the next representation or track. */ }
                errors.push("caption_parse_failed");
            }
        }
        const findTranscriptCommand = (root) => {
            if (!root || typeof root !== "object")
                return null;
            const queue = [root];
            const seen = new Set();
            for (let inspected = 0; queue.length && inspected < 50_000; inspected += 1) {
                const value = queue.shift();
                if (!value || typeof value !== "object" || seen.has(value))
                    continue;
                seen.add(value);
                const record = value;
                const endpoint = record.getTranscriptEndpoint;
                if (endpoint && typeof endpoint === "object") {
                    const params = endpoint.params;
                    if (typeof params === "string" && params.length > 0 && params.length <= 2_000) {
                        const clickTrackingParams = record.clickTrackingParams;
                        return {
                            params,
                            clickTrackingParams: typeof clickTrackingParams === "string" && clickTrackingParams.length <= 2_000
                                ? clickTrackingParams
                                : null,
                        };
                    }
                }
                if (Array.isArray(value))
                    queue.push(...value);
                else
                    queue.push(...Object.values(record));
            }
            return null;
        };
        const transcriptCommand = findTranscriptCommand(page.ytInitialData);
        const transcriptParams = transcriptCommand?.params ?? null;
        let decodedTranscriptParams = null;
        const transcriptParamsMatchCurrentVideo = (() => {
            if (!transcriptParams)
                return false;
            try {
                decodedTranscriptParams = decodeURIComponent(transcriptParams);
                const normalized = decodedTranscriptParams.replace(/-/g, "+").replace(/_/g, "/");
                const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
                const binary = atob(padded);
                const target = Array.from(id).map((character) => character.charCodeAt(0));
                const bytes = Array.from(binary, (character) => character.charCodeAt(0));
                const readVarint = (offset) => {
                    let value = 0;
                    let shift = 0;
                    let cursor = offset;
                    while (cursor < bytes.length && shift <= 63) {
                        const byte = bytes[cursor++];
                        value += (byte & 0x7f) * 2 ** shift;
                        if (!(byte & 0x80))
                            return { value, next: cursor };
                        shift += 7;
                    }
                    return null;
                };
                const sameBytes = (start, end) => {
                    if (end - start !== target.length)
                        return false;
                    return target.every((byte, index) => bytes[start + index] === byte);
                };
                const containsDelimitedVideoId = (start, end, depth) => {
                    if (depth > 5)
                        return false;
                    let cursor = start;
                    while (cursor < end) {
                        const key = readVarint(cursor);
                        if (!key || key.value < 8)
                            return false;
                        cursor = key.next;
                        const wireType = key.value & 0x07;
                        if (wireType === 0) {
                            const value = readVarint(cursor);
                            if (!value)
                                return false;
                            cursor = value.next;
                            continue;
                        }
                        if (wireType === 1) {
                            cursor += 8;
                            if (cursor > end)
                                return false;
                            continue;
                        }
                        if (wireType === 2) {
                            const length = readVarint(cursor);
                            if (!length || length.value < 0 || length.value > end - length.next)
                                return false;
                            const valueStart = length.next;
                            const valueEnd = valueStart + length.value;
                            if (sameBytes(valueStart, valueEnd))
                                return true;
                            if (containsDelimitedVideoId(valueStart, valueEnd, depth + 1))
                                return true;
                            cursor = valueEnd;
                            continue;
                        }
                        if (wireType === 5) {
                            cursor += 4;
                            if (cursor > end)
                                return false;
                            continue;
                        }
                        return false;
                    }
                    return false;
                };
                // The real endpoint uses a base64url-encoded protobuf. Require the
                // current ID as a complete length-delimited protobuf value (including
                // nested messages), rather than accepting an incidental substring.
                if (containsDelimitedVideoId(0, bytes.length, 0))
                    return true;
                // Keep the tiny marker form accepted by page-world test shims and old
                // embedded players, but bind it exactly instead of using substring
                // matching. Real YouTube params never rely on this compatibility path.
                return binary === `video:${id}`;
            }
            catch {
                return false;
            }
        })();
        const configGet = page.ytcfg && typeof page.ytcfg.get === "function" ? page.ytcfg.get.bind(page.ytcfg) : null;
        const apiKey = configGet?.("INNERTUBE_API_KEY");
        const context = configGet?.("INNERTUBE_CONTEXT");
        const clientName = configGet?.("INNERTUBE_CLIENT_NAME");
        const clientVersion = configGet?.("INNERTUBE_CLIENT_VERSION");
        if (isCurrentVideo() && transcriptParamsMatchCurrentVideo && typeof apiKey === "string" && apiKey.length > 0 && apiKey.length <= 256
            && context && typeof context === "object" && (typeof clientName === "string" || typeof clientName === "number")
            && typeof clientVersion === "string" && clientVersion.length > 0 && clientVersion.length <= 128) {
            const endpoint = new URL("/youtubei/v1/get_transcript", currentUrl.origin);
            endpoint.searchParams.set("prettyPrint", "false");
            endpoint.searchParams.set("key", apiKey);
            let transcriptResponse = null;
            try {
                const requestContext = transcriptCommand?.clickTrackingParams
                    ? { ...context, clickTracking: { clickTrackingParams: transcriptCommand.clickTrackingParams } }
                    : context;
                transcriptResponse = await fetchBeforeDeadline(endpoint.toString(), {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "Content-Type": "application/json",
                        "X-YouTube-Client-Name": String(clientName),
                        "X-YouTube-Client-Version": clientVersion,
                    },
                    body: JSON.stringify({ context: requestContext, params: decodedTranscriptParams }),
                });
            }
            catch {
                errors.push("caption_fetch_failed");
            }
            if (transcriptResponse) {
                const validTranscriptResponse = (() => {
                    if (!transcriptResponse?.ok)
                        return false;
                    if (!transcriptResponse.url)
                        return true;
                    try {
                        const finalUrl = new URL(transcriptResponse.url);
                        return finalUrl.origin === currentUrl.origin && finalUrl.pathname === "/youtubei/v1/get_transcript";
                    }
                    catch {
                        return false;
                    }
                })();
                if (!validTranscriptResponse) {
                    errors.push("caption_fetch_failed");
                }
                else {
                    try {
                        const body = await readResponseJson(transcriptResponse);
                        const renderers = [];
                        const queue = [body];
                        const seen = new Set();
                        for (let inspected = 0; queue.length && inspected < 100_000; inspected += 1) {
                            const value = queue.shift();
                            if (!value || typeof value !== "object" || seen.has(value))
                                continue;
                            seen.add(value);
                            const record = value;
                            const renderer = record.transcriptSegmentRenderer;
                            if (renderer && typeof renderer === "object")
                                renderers.push(renderer);
                            if (Array.isArray(value))
                                queue.push(...value);
                            else
                                queue.push(...Object.values(record));
                        }
                        const cues = transcriptRendererCues(renderers);
                        if (cues.length)
                            return isCurrentVideo()
                                ? captured(ordered[0] ?? tracks[0], cues)
                                : fail("stale_player_response");
                        errors.push("caption_parse_failed");
                    }
                    catch {
                        errors.push("caption_parse_failed");
                    }
                }
            }
        }
        const renderedTranscriptCues = () => {
            try {
                if (typeof document.querySelectorAll !== "function")
                    return [];
                const renderers = Array.from(document.querySelectorAll("ytd-transcript-segment-renderer")).flatMap((node) => {
                    const data = node.data;
                    return data && typeof data === "object" ? [data] : [];
                });
                return transcriptRendererCues(renderers);
            }
            catch {
                return [];
            }
        };
        const clickNode = (selector) => {
            try {
                if (typeof document.querySelector !== "function")
                    return false;
                const candidates = typeof document.querySelectorAll === "function"
                    ? Array.from(document.querySelectorAll(selector))
                    : [];
                const visible = candidates.find((candidate) => {
                    try {
                        return typeof candidate.getClientRects === "function" && candidate.getClientRects().length > 0;
                    }
                    catch {
                        return false;
                    }
                });
                const node = visible ?? candidates[0]
                    ?? document.querySelector(selector);
                if (!node || typeof node.click !== "function")
                    return false;
                node.click();
                return true;
            }
            catch {
                return false;
            }
        };
        let domCues = renderedTranscriptCues();
        if (domCues.length)
            return isCurrentVideo() ? captured(ordered[0] ?? tracks[0], domCues) : fail("stale_player_response");
        const supportsTranscriptDom = typeof document.querySelector === "function"
            && typeof document.querySelectorAll === "function";
        if (!domCues.length && supportsTranscriptDom && isCurrentVideo()) {
            clickNode("#description-inline-expander #expand, ytd-text-inline-expander #expand, tp-yt-paper-button#expand");
            let transcriptUiRequested = false;
            for (let attempt = 0; attempt < 10 && Date.now() < captureDeadline && isCurrentVideo(); attempt += 1) {
                if (clickNode("ytd-video-description-transcript-section-renderer button")) {
                    transcriptUiRequested = true;
                    break;
                }
                await new Promise((resolve) => setTimeout(resolve, 100));
            }
            for (let attempt = 0; transcriptUiRequested && attempt < 40 && Date.now() < captureDeadline && isCurrentVideo(); attempt += 1) {
                domCues = renderedTranscriptCues();
                if (domCues.length)
                    return isCurrentVideo() ? captured(ordered[0] ?? tracks[0], domCues) : fail("stale_player_response");
                await new Promise((resolve) => setTimeout(resolve, 100));
            }
        }
        if (!isCurrentVideo())
            return fail("stale_player_response");
        // Without a pot the timed-text endpoints return empty bodies, so a failure
        // here says nothing about the captions: the player just was not ready.
        if (!potParams && (captionPlayer || playerElement || page.movie_player))
            return fail("caption_player_not_ready");
        return fail(errors.includes("caption_fetch_failed") ? "caption_fetch_failed" : "caption_parse_failed");
    }
    catch {
        return fail("capture_unavailable");
    }
}
/** MAIN-world NTULearn/Kaltura adapter; keep this function self-contained for MV3. */
export async function captureKalturaPage() {
    const MAX_CAPTURE_MS = 10_000;
    const MAX_PLAYLIST_CHARS = 256_000;
    const MAX_SEGMENT_CHARS = 512_000;
    const MAX_TOTAL_SEGMENT_CHARS = 4_000_000;
    const MAX_PLAYLIST_SEGMENTS = 240;
    const MAX_PLAYLIST_CUES = 50_000;
    const clean = (value) => value
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]+>/g, " ")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/gi, "'")
        .replace(/\s+/g, " ")
        .replace(/\s+([,.;:!?])/g, "$1")
        .trim();
    const queryAll = (selector) => {
        try {
            return typeof document.querySelectorAll === "function" ? Array.from(document.querySelectorAll(selector)) : [];
        }
        catch {
            return [];
        }
    };
    const queryOne = (selector) => {
        try {
            return typeof document.querySelector === "function" ? document.querySelector(selector) : null;
        }
        catch {
            return null;
        }
    };
    const attribute = (node, name) => {
        try {
            return node?.getAttribute(name) ?? "";
        }
        catch {
            return "";
        }
    };
    const fail = (error) => ({ status: "failed", error });
    try {
        const frameHost = location.hostname.toLowerCase();
        const captureDeadline = Date.now() + MAX_CAPTURE_MS;
        const supportedFrameHost = frameHost === "ntulearn.ntu.edu.sg"
            || frameHost === "ntulearnvideo.ntu.edu.sg"
            || frameHost === "ntulearnv1.ntu.edu.sg"
            || frameHost === "cdnapisec.kaltura.com";
        if (!supportedFrameHost)
            return { status: "not_media_frame" };
        const isNtuMediaHost = frameHost === "ntulearn.ntu.edu.sg"
            || frameHost === "ntulearnvideo.ntu.edu.sg"
            || frameHost === "ntulearnv1.ntu.edu.sg";
        const page = globalThis;
        const readPageValue = (key) => {
            try {
                return page[key];
            }
            catch {
                return undefined;
            }
        };
        const resources = (() => {
            try {
                return typeof performance !== "undefined" ? performance.getEntriesByType("resource").flatMap((entry) => typeof entry.name === "string" ? [entry.name] : []) : [];
            }
            catch {
                return [];
            }
        })();
        const pageText = (() => {
            try {
                return document.documentElement?.innerHTML ?? "";
            }
            catch {
                return "";
            }
        })();
        const iframeUrls = queryAll("iframe[src]").flatMap((frame) => {
            const value = frame.src || attribute(frame, "src");
            return value ? [value] : [];
        });
        // Kaltura entry IDs use a numeric partner prefix. Keeping this aligned
        // with capture.v1 also avoids treating keys such as `entry_id` and
        // `uiconf_id` in serialized page state as media identities.
        const entryPattern = /\b[0-9]+_[A-Za-z0-9]+\b/;
        const entryIds = [];
        const addEntry = (value) => {
            if (typeof value !== "string")
                return;
            const match = value.match(entryPattern)?.[0];
            if (match && !entryIds.includes(match))
                entryIds.push(match);
        };
        addEntry(location.href);
        resources.forEach(addEntry);
        iframeUrls.forEach(addEntry);
        const scanEntries = (value, depth = 0) => {
            if (depth > 3 || value === null || value === undefined)
                return;
            if (typeof value === "string") {
                addEntry(value);
                return;
            }
            if (typeof value !== "object")
                return;
            try {
                if (Array.isArray(value)) {
                    value.slice(0, 80).forEach((item) => scanEntries(item, depth + 1));
                    return;
                }
                for (const key of Object.keys(value).slice(0, 120)) {
                    try {
                        const nested = value[key];
                        if (/entry.?id|media.?id|video.?id/i.test(key))
                            addEntry(nested);
                        if (depth < 2)
                            scanEntries(nested, depth + 1);
                    }
                    catch { /* Skip only the throwing property. */ }
                }
            }
            catch { /* A page-owned getter is untrusted; continue with other sources. */ }
        };
        for (const key of ["kWidget", "kalturaPlayer", "KalturaPlayer", "__INITIAL_STATE__", "__INITIAL_DATA__"])
            scanEntries(readPageValue(key));
        queryAll("[data-entry-id], [data-entryid]").forEach((node) => { addEntry(attribute(node, "data-entry-id")); addEntry(attribute(node, "data-entryid")); });
        for (const match of pageText.matchAll(/(?:entry[_-]?id|entryId)[^A-Za-z0-9]{0,16}([0-9]+_[A-Za-z0-9]+)/gi))
            addEntry(match[1]);
        const entryId = entryIds[0];
        if (!entryId)
            return { status: "not_media_frame" };
        const parseClock = (value) => {
            const normalized = value.trim();
            if (/^\d+(?:\.\d+)?ms$/.test(normalized))
                return Number(normalized.slice(0, -2)) / 1000;
            if (/^\d+(?:\.\d+)?s$/.test(normalized))
                return Number(normalized.slice(0, -1));
            const parts = normalized.replace(",", ".").split(":").map(Number);
            if ((parts.length === 2 || parts.length === 3) && parts.every((part) => Number.isFinite(part) && part >= 0)) {
                return parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts[0] * 60 + parts[1];
            }
            return Number.NaN;
        };
        const normalizeCues = (cues) => cues
            .filter((cue) => Number.isFinite(cue.start_sec) && Number.isFinite(cue.end_sec) && cue.start_sec >= 0 && cue.end_sec >= cue.start_sec && clean(cue.text))
            .map((cue) => ({ start_sec: cue.start_sec, end_sec: cue.end_sec, text: clean(cue.text) }))
            .sort((left, right) => left.start_sec - right.start_sec);
        const parseTimedText = (body) => {
            const parsed = [];
            const normalized = body.replace(/^\uFEFF/, "").replace(/\r/g, "");
            const timestampMapLine = normalized.match(/^X-TIMESTAMP-MAP\s*=\s*(.+)$/im)?.[1];
            let timestampOffset = 0;
            if (timestampMapLine !== undefined) {
                const localValue = timestampMapLine.match(/(?:^|,)\s*LOCAL:([^,\s]+)/i)?.[1];
                const mpegValue = timestampMapLine.match(/(?:^|,)\s*MPEGTS:(\d+)/i)?.[1];
                const localSeconds = localValue === undefined ? Number.NaN : parseClock(localValue);
                const mpegTimestamp = mpegValue === undefined ? Number.NaN : Number(mpegValue);
                if (!Number.isFinite(localSeconds) || !Number.isFinite(mpegTimestamp)
                    || mpegTimestamp < 0 || mpegTimestamp > 8_589_934_591)
                    return [];
                timestampOffset = mpegTimestamp / 90_000 - localSeconds;
            }
            const timing = /^\s*((?:\d{1,2}:)?\d{2}:\d{2}[,.]\d{3})\s*-->\s*((?:\d{1,2}:)?\d{2}:\d{2}[,.]\d{3})(?:\s+.*)?$/;
            for (const block of normalized.split(/\n\s*\n+/)) {
                const lines = block.split("\n");
                const lineIndex = lines.findIndex((line) => timing.test(line));
                if (lineIndex < 0)
                    continue;
                const match = lines[lineIndex]?.match(timing);
                if (!match)
                    continue;
                const start = parseClock(match[1]);
                const end = parseClock(match[2]);
                const text = clean(lines.slice(lineIndex + 1).join(" "));
                const adjustedStart = start + timestampOffset;
                const adjustedEnd = end + timestampOffset;
                if (Number.isFinite(adjustedStart) && Number.isFinite(adjustedEnd) && adjustedStart >= 0 && adjustedEnd >= adjustedStart && text)
                    parsed.push({ start_sec: adjustedStart, end_sec: adjustedEnd, text });
            }
            if (!parsed.length && /<(?:tt|p)\b/i.test(normalized)) {
                const addXmlCue = (begin, endValue, dur, textValue) => {
                    const start = parseClock(begin);
                    const explicitEnd = parseClock(endValue);
                    const duration = parseClock(dur);
                    const end = Number.isFinite(explicitEnd) ? explicitEnd : start + duration;
                    const text = clean(textValue);
                    const adjustedStart = start + timestampOffset;
                    const adjustedEnd = end + timestampOffset;
                    if (Number.isFinite(adjustedStart) && Number.isFinite(adjustedEnd) && adjustedStart >= 0 && adjustedEnd >= adjustedStart && text)
                        parsed.push({ start_sec: adjustedStart, end_sec: adjustedEnd, text });
                };
                if (typeof DOMParser !== "undefined") {
                    try {
                        const xml = new DOMParser().parseFromString(normalized, "application/xml");
                        Array.from(xml.querySelectorAll("p[begin]")).forEach((node) => addXmlCue(node.getAttribute("begin") ?? "", node.getAttribute("end") ?? "", node.getAttribute("dur") ?? "", node.textContent ?? ""));
                    }
                    catch { /* Use the conservative attribute parser below. */ }
                }
                if (!parsed.length) {
                    const pPattern = /<p\b([^>]*)>([\s\S]*?)<\/p>/gi;
                    for (const match of normalized.matchAll(pPattern)) {
                        const attrs = match[1] ?? "";
                        const get = (name) => attrs.match(new RegExp(`${name}\\s*=\\s*["']([^"']+)["']`, "i"))?.[1] ?? "";
                        addXmlCue(get("begin"), get("end"), get("dur"), match[2] ?? "");
                    }
                }
            }
            return normalizeCues(parsed);
        };
        const readNativeCues = (track) => {
            try {
                return normalizeCues(Array.from(track.cues ?? []).flatMap((rawCue) => {
                    const cue = rawCue;
                    return typeof cue.text === "string" ? [{ start_sec: cue.startTime, end_sec: cue.endTime, text: cue.text }] : [];
                }));
            }
            catch {
                return [];
            }
        };
        const trackLanguage = (value) => typeof value === "string" && clean(value).length ? clean(value).slice(0, 64) : "und";
        const isCaptionKind = (value) => typeof value !== "string" || !value
            || value === "captions" || value === "subtitles";
        const nativeTracks = queryAll("video").flatMap((video) => {
            try {
                return Array.from(video.textTracks ?? []);
            }
            catch {
                return [];
            }
        }).filter((track) => isCaptionKind(track.kind));
        const previousModes = nativeTracks.map((track) => {
            try {
                return track.mode;
            }
            catch {
                return "disabled";
            }
        });
        let nativeCapture = null;
        try {
            nativeTracks.forEach((track) => { try {
                if (track.mode === "disabled")
                    track.mode = "hidden";
            }
            catch { /* Continue with other tracks. */ } });
            for (let attempt = 0; attempt < 10 && !nativeTracks.some((track) => (track.cues?.length ?? 0) > 0); attempt += 1) {
                if (!nativeTracks.length)
                    break;
                await new Promise((resolve) => setTimeout(resolve, 50));
            }
            const ordered = nativeTracks.map((track, index) => ({ track, index })).sort((left, right) => Number(previousModes[right.index] === "showing") - Number(previousModes[left.index] === "showing"));
            for (const item of ordered) {
                const cues = readNativeCues(item.track);
                if (cues.length) {
                    nativeCapture = { language: trackLanguage(item.track.language), cues };
                    break;
                }
            }
        }
        finally {
            nativeTracks.forEach((track, index) => { try {
                track.mode = previousModes[index] ?? "disabled";
            }
            catch { /* A removed track is harmless. */ } });
        }
        if (nativeCapture?.cues?.length) {
            const video = queryOne("video");
            const durationValue = Number(video?.duration);
            nativeCapture.duration = Number.isFinite(durationValue) && durationValue >= 0 ? Math.floor(durationValue) : null;
        }
        const isPlaylistUrl = (value) => {
            try {
                const parsed = new URL(value, location.href);
                return /\.m3u8$/i.test(parsed.pathname)
                    && /caption_captionasset[^/]*\/action\/servewebvtt\b/i.test(parsed.pathname);
            }
            catch {
                return false;
            }
        };
        const isPlaylistSegmentUrl = (value) => {
            try {
                const parsed = new URL(value, location.href);
                return /caption_captionasset[^/]*\/action\/servewebvtt\b/i.test(parsed.pathname)
                    && /(?:\/|[?&])segmentindex(?:\/|=)/i.test(`${parsed.pathname}?${parsed.searchParams.toString()}`);
            }
            catch {
                return false;
            }
        };
        const isDirectTimedTextUrl = (value) => {
            try {
                const parsed = new URL(value, location.href);
                const pathname = parsed.pathname.toLowerCase();
                if (/\.(?:css|js|mjs|html?|json|png|jpe?g|gif|svg|woff2?)$/i.test(pathname))
                    return false;
                return /\.(?:vtt|srt|dfxp|ttml)$/i.test(pathname)
                    || (/(?:caption|subtitle|timedtext|texttrack)/i.test(pathname)
                        && !/\/captions?(?:[-_]|\/|$)/i.test(pathname));
            }
            catch {
                return false;
            }
        };
        const trustedCaptionUrl = (value) => {
            try {
                const parsed = new URL(value, location.href);
                const host = parsed.hostname.toLowerCase();
                const trustedHost = host === "ntulearn.ntu.edu.sg"
                    || host === "ntulearnvideo.ntu.edu.sg"
                    || host === "ntulearnv1.ntu.edu.sg"
                    || host === "kaltura.com"
                    || host.endsWith(".kaltura.com");
                const normalized = parsed.toString();
                const captionShape = isPlaylistUrl(normalized) || isDirectTimedTextUrl(normalized);
                return parsed.protocol === "https:" && !parsed.username && !parsed.password && trustedHost && captionShape ? normalized : null;
            }
            catch {
                return null;
            }
        };
        const dedupeCues = (cues) => {
            const unique = new Map();
            for (const cue of normalizeCues(cues)) {
                const key = `${cue.start_sec}\u0000${cue.end_sec}\u0000${cue.text}`;
                if (!unique.has(key))
                    unique.set(key, cue);
                if (unique.size > MAX_PLAYLIST_CUES)
                    return [];
            }
            return [...unique.values()].sort((left, right) => left.start_sec - right.start_sec);
        };
        const captionRequestCredentials = (value) => {
            try {
                const resourceOrigin = new URL(value, location.href).origin;
                const pageOrigin = new URL(location.href).origin;
                return resourceOrigin === pageOrigin ? "include" : "omit";
            }
            catch {
                return "omit";
            }
        };
        const fetchCaptionResponse = async (url) => {
            const remaining = captureDeadline - Date.now();
            if (remaining <= 0)
                return { failure: "fetch" };
            let timer;
            const controller = typeof AbortController === "undefined" ? undefined : new AbortController();
            try {
                const response = await Promise.race([
                    fetch(url, { credentials: captionRequestCredentials(url), ...(controller ? { signal: controller.signal } : {}) }),
                    new Promise((_resolve, reject) => {
                        timer = setTimeout(() => {
                            controller?.abort();
                            reject(new Error("caption_fetch_timeout"));
                        }, Math.min(1_200, remaining));
                    }),
                ]);
                if (!response.ok)
                    return { failure: "fetch" };
                const finalUrl = response.url || url;
                if (!trustedCaptionUrl(finalUrl))
                    return { failure: "fetch" };
                const textRemaining = captureDeadline - Date.now();
                if (textRemaining <= 0)
                    return { failure: "fetch" };
                if (timer !== undefined)
                    clearTimeout(timer);
                timer = undefined;
                const bodyPromise = typeof response.text === "function"
                    ? response.text()
                    : (async () => {
                        const reader = response.body?.getReader();
                        if (!reader)
                            throw new Error("caption_body_missing");
                        const chunks = [];
                        while (true) {
                            const part = await reader.read();
                            if (part.done)
                                break;
                            if (part.value)
                                chunks.push(part.value);
                        }
                        const total = chunks.reduce((n, chunk) => n + chunk.length, 0);
                        const merged = new Uint8Array(total);
                        let offset = 0;
                        for (const chunk of chunks) {
                            merged.set(chunk, offset);
                            offset += chunk.length;
                        }
                        return new TextDecoder().decode(merged);
                    })();
                const body = await Promise.race([
                    bodyPromise,
                    new Promise((_resolve, reject) => {
                        timer = setTimeout(() => {
                            controller?.abort();
                            reject(new Error("caption_body_timeout"));
                        }, Math.min(1_200, textRemaining));
                    }),
                ]);
                const maxChars = isPlaylistUrl(finalUrl) ? MAX_PLAYLIST_CHARS : MAX_SEGMENT_CHARS;
                if (body.length > maxChars)
                    return { failure: "fetch" };
                return { body, finalUrl };
            }
            catch {
                return { failure: "fetch" };
            }
            finally {
                if (timer !== undefined)
                    clearTimeout(timer);
                controller?.abort();
            }
        };
        const playlistSegments = (body, playlistUrl) => {
            const lines = body.replace(/^\uFEFF/, "").replace(/\r/g, "").split("\n");
            if (lines[0]?.trim() !== "#EXTM3U")
                return null;
            const segments = [];
            let ended = false;
            for (const rawLine of lines.slice(1)) {
                const line = rawLine.trim();
                if (!line)
                    continue;
                if (/^#EXT-X-ENDLIST\b/i.test(line)) {
                    ended = true;
                    continue;
                }
                if (line.startsWith("#"))
                    continue;
                if (ended)
                    return null;
                let resolved;
                try {
                    resolved = new URL(line, playlistUrl).toString();
                }
                catch {
                    return null;
                }
                const trusted = trustedCaptionUrl(resolved);
                if (!trusted || isPlaylistUrl(trusted))
                    return null;
                if (!segments.includes(trusted))
                    segments.push(trusted);
                if (segments.length > MAX_PLAYLIST_SEGMENTS)
                    return null;
            }
            return ended && segments.length ? segments : null;
        };
        const isEmptyWebVttSegment = (body) => {
            const normalized = body.replace(/^\uFEFF/, "").replace(/\r/g, "");
            return /^WEBVTT(?:[ \t].*)?(?:\n|$)/.test(normalized) && !normalized.includes("-->");
        };
        const playlistMemberUrls = new Set();
        const readCaptionResource = async (url) => {
            const response = await fetchCaptionResponse(url);
            if ("failure" in response)
                return { cues: [], failure: "fetch" };
            const playlist = isPlaylistUrl(response.finalUrl);
            if (!playlist) {
                const cues = parseTimedText(response.body);
                return cues.length ? { cues } : { cues: [], failure: "parse" };
            }
            const segments = playlistSegments(response.body, response.finalUrl);
            if (!segments)
                return { cues: [], failure: "parse" };
            segments.forEach((segment) => playlistMemberUrls.add(segment));
            const merged = [];
            let totalSegmentChars = 0;
            for (const segment of segments) {
                const segmentResponse = await fetchCaptionResponse(segment);
                if ("failure" in segmentResponse)
                    return { cues: [], failure: "fetch" };
                totalSegmentChars += segmentResponse.body.length;
                if (totalSegmentChars > MAX_TOTAL_SEGMENT_CHARS)
                    return { cues: [], failure: "fetch" };
                const cues = parseTimedText(segmentResponse.body);
                if (!cues.length) {
                    if (isEmptyWebVttSegment(segmentResponse.body))
                        continue;
                    return { cues: [], failure: "parse" };
                }
                merged.push(...cues);
                if (merged.length > MAX_PLAYLIST_CUES)
                    return { cues: [], failure: "parse" };
            }
            const cues = dedupeCues(merged);
            return cues.length ? { cues } : { cues: [], failure: "parse" };
        };
        const candidates = [];
        const urls = new Set();
        let sawStandalonePlaylistSegment = false;
        const addUrl = (value, language = "und") => {
            if (typeof value !== "string")
                return;
            const trusted = trustedCaptionUrl(value.replace(/\\\//g, "/").replace(/&amp;/g, "&"));
            if (!trusted || urls.has(trusted))
                return;
            if (isPlaylistSegmentUrl(trusted)) {
                sawStandalonePlaylistSegment = true;
                return;
            }
            urls.add(trusted);
            candidates.push({ url: trusted, language: trackLanguage(language) });
        };
        const inlineCandidates = [];
        const addInline = (value, language = "und") => {
            if (!Array.isArray(value))
                return;
            const cues = normalizeCues(value.flatMap((raw) => {
                if (!raw || typeof raw !== "object")
                    return [];
                const record = raw;
                const start = Number(record.start_sec ?? record.startTime ?? record.start ?? record.begin);
                const end = Number(record.end_sec ?? record.endTime ?? record.end);
                const text = typeof record.text === "string" ? record.text : typeof record.content === "string" ? record.content : "";
                return Number.isFinite(start) && Number.isFinite(end) ? [{ start_sec: start, end_sec: end, text }] : [];
            }));
            if (cues.length)
                inlineCandidates.push({ language: trackLanguage(language), cues });
        };
        const domTracks = [...queryAll("track[src]"), ...queryAll("track")].filter((node, index, nodes) => nodes.indexOf(node) === index);
        domTracks.forEach((node) => {
            const track = node;
            if (!isCaptionKind(track.kind || attribute(node, "kind")))
                return;
            const language = trackLanguage(track.srclang || attribute(node, "srclang"));
            if (track.track) {
                const cues = readNativeCues(track.track);
                if (cues.length)
                    inlineCandidates.push({ language: trackLanguage(track.track.language || language), cues });
            }
            addUrl(track.src || attribute(node, "src"), language);
        });
        const playerRoots = ["kWidget", "kalturaPlayer", "KalturaPlayer", "__INITIAL_STATE__", "__INITIAL_DATA__"]
            .map(readPageValue);
        const inspectDescriptor = (value, keyHint = "", depth = 0) => {
            if (depth > 3 || value === null || value === undefined)
                return;
            if (typeof value === "string") {
                if (/caption|subtitle|timedtext|texttrack|track|src|url|href/i.test(keyHint))
                    addUrl(value);
                return;
            }
            if (Array.isArray(value)) {
                value.slice(0, 80).forEach((item) => inspectDescriptor(item, keyHint, depth + 1));
                return;
            }
            if (typeof value !== "object")
                return;
            const record = value;
            let language = "und";
            try {
                language = trackLanguage(record.languageCode ?? record.language ?? record.lang ?? record.srclang);
            }
            catch { /* Use und. */ }
            if (/caption|subtitle|timedtext|texttrack|^text$|getTextTracks|getCaptionTracks/i.test(keyHint)) {
                try {
                    addInline(record.cues ?? record.events, language);
                }
                catch { /* Skip malformed inline cues. */ }
            }
            try {
                for (const key of Object.keys(record).slice(0, 80)) {
                    try {
                        const nested = record[key];
                        if (typeof nested === "string" && /caption|subtitle|timedtext|texttrack|track|src|url|href/i.test(key))
                            addUrl(nested, language);
                        else if (depth < 2 && (Array.isArray(nested) || (nested && typeof nested === "object")))
                            inspectDescriptor(nested, key, depth + 1);
                    }
                    catch { /* Skip only the throwing property. */ }
                }
            }
            catch { /* A player-owned getter must not abort other caption sources. */ }
        };
        const addPlayerTracks = (root) => {
            if (!root || (typeof root !== "object" && typeof root !== "function"))
                return;
            const holder = root;
            for (const method of ["getTextTracks", "getTracks", "getCaptionTracks"]) {
                try {
                    const fn = holder[method];
                    if (typeof fn === "function") {
                        const value = fn.call(root);
                        inspectDescriptor(value, method);
                    }
                }
                catch { /* Player APIs differ by Kaltura version. */ }
            }
            for (const key of ["textTracks", "tracks", "captionTracks", "subtitles", "captions"]) {
                try {
                    const value = holder[key];
                    if (Array.isArray(value))
                        value.forEach((track) => inspectDescriptor(track, key));
                }
                catch { /* A player-owned getter must not abort other caption sources. */ }
            }
        };
        playerRoots.forEach(addPlayerTracks);
        playerRoots.forEach((root) => inspectDescriptor(root));
        resources.forEach((value) => addUrl(value));
        for (const match of pageText.matchAll(/https?:\\?\/\\?\/[^"'<>\s]+/gi))
            addUrl(match[0]);
        const playlistCandidates = candidates
            .filter((candidate) => candidate.url && isPlaylistUrl(candidate.url))
            .map((candidate) => candidate.language === "und" && nativeCapture?.language
            ? { ...candidate, language: nativeCapture.language }
            : candidate);
        const resourceCandidates = candidates.filter((candidate) => !candidate.url || !isPlaylistUrl(candidate.url));
        const nativeCandidates = nativeCapture?.cues?.length ? [nativeCapture] : [];
        // Native/DOM cues on an HLS-backed TextTrack may contain only the currently
        // buffered window. A discovered finite playlist is the only source that
        // can prove every segment was read, so do not fall back to partial in-memory
        // cues when that playlist exists but fails.
        const allCandidates = playlistCandidates.length
            ? [...playlistCandidates, ...resourceCandidates]
            : [...nativeCandidates, ...inlineCandidates, ...resourceCandidates];
        const makeCapture = (cues, language, title, duration) => {
            const pageUrl = isNtuMediaHost
                ? `https://${frameHost}${location.pathname}` : `https://ntulearnvideo.ntu.edu.sg/media/${entryId}`;
            return {
                platform: "ntu_kaltura",
                platform_id: entryId,
                canonical_url: `https://ntulearnvideo.ntu.edu.sg/media/${entryId}`,
                page_url: pageUrl,
                metadata: { title, author: null, duration_sec: duration, language, description: null, cover_url: null, tags: [], chapters: [] },
                caption: { status: "available", source: "official_cc", language, cues },
            };
        };
        if (!allCandidates.length && !nativeTracks.length) {
            if (sawStandalonePlaylistSegment)
                return fail("caption_parse_failed");
            return {
                status: "no_caption",
                capture: {
                    platform: "ntu_kaltura",
                    platform_id: entryId,
                    canonical_url: `https://ntulearnvideo.ntu.edu.sg/media/${entryId}`,
                    page_url: isNtuMediaHost
                        ? `https://${frameHost}${location.pathname}` : `https://ntulearnvideo.ntu.edu.sg/media/${entryId}`,
                    metadata: { title: null, author: null, duration_sec: null, language: null, description: null, cover_url: null, tags: [], chapters: [] },
                    caption: { status: "unavailable", source: null, language: null, cues: [] },
                },
            };
        }
        const errors = [];
        for (const candidate of allCandidates) {
            if (candidate.cues?.length)
                return {
                    status: "captured",
                    capture: makeCapture(candidate.cues, trackLanguage(candidate.language), null, candidate.duration ?? null),
                };
            if (!candidate.url)
                continue;
            if (playlistMemberUrls.has(candidate.url))
                continue;
            const resource = await readCaptionResource(candidate.url);
            if (resource.failure) {
                errors.push(resource.failure === "fetch" ? "caption_fetch_failed" : "caption_parse_failed");
                continue;
            }
            const cues = resource.cues;
            const language = trackLanguage(candidate.language);
            const video = queryOne("video");
            const durationValue = Number(video?.duration);
            const metaTitle = queryOne("meta[property='og:title']")?.content;
            const title = [metaTitle, queryOne("h1")?.textContent, typeof document.title === "string" ? document.title : ""]
                .map((value) => clean(value ?? ""))
                .find((value) => value && !/^(media gallery|kaltura(?: media)? player)$/i.test(value)) ?? `NTULearn video ${entryId}`;
            return { status: "captured", capture: makeCapture(cues, language, title.slice(0, 1000), Number.isFinite(durationValue) && durationValue >= 0 ? Math.floor(durationValue) : null) };
        }
        return fail(errors.includes("caption_fetch_failed") ? "caption_fetch_failed" : "caption_parse_failed");
    }
    catch {
        return fail("capture_unavailable");
    }
}
/**
 * MAIN-world Bilibili adapter; keep this function self-contained for MV3.
 *
 * Everything is read inside the page with the viewer's own session: the video's
 * page state, the player API (which lists subtitles, including the AI subtitles
 * that need a login) and the subtitle JSON. Signed subtitle URLs and cookies stay
 * in this function; only cues and public metadata are returned.
 */
export async function captureBilibiliPage() {
    const MAX_BODY_BYTES = 4_000_000;
    const MAX_CUES = 50_000;
    const MAX_TEXT_CHARS = 1_000_000;
    const MAX_SUBTITLE_TRIES = 3;
    const REQUEST_MS = 6_000;
    const deadline = Date.now() + 12_000;
    const fail = (error) => ({ status: "failed", error });
    const asRecord = (value) => (value && typeof value === "object" && !Array.isArray(value) ? value : null);
    const clean = (value) => value
        .replace(/<[^>]+>/g, " ")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/gi, "'")
        .replace(/\s+/g, " ")
        .trim();
    const positiveInteger = (value) => {
        const number = typeof value === "number" ? value : typeof value === "string" && /^[0-9]{1,18}$/.test(value) ? Number(value) : Number.NaN;
        return Number.isSafeInteger(number) && number > 0 ? number : null;
    };
    const hdslbHost = (host) => host === "hdslb.com" || host.endsWith(".hdslb.com");
    try {
        // Identity comes from the URL, normalized exactly like the server connector's
        // platform id, so a captured video and a URL import reach one library item.
        const locate = () => {
            let url;
            try {
                url = new URL(location.href);
            }
            catch {
                return null;
            }
            if (url.protocol !== "https:" || url.hostname.toLowerCase() !== "www.bilibili.com")
                return null;
            const match = /^\/video\/((?:[aA][vV])[0-9]{1,20}|(?:[bB][vV])[0-9A-Za-z]{10})\/?$/.exec(url.pathname);
            if (!match)
                return null;
            const raw = match[1];
            const values = url.searchParams.getAll("p");
            return {
                id: (raw.slice(0, 2).toLowerCase() === "bv" ? "BV" : "av") + raw.slice(2),
                part: values.length === 1 && /^[1-9][0-9]{0,3}$/.test(values[0]) ? Number(values[0]) : 1,
            };
        };
        const target = locate();
        if (!target)
            return fail("unsupported_page");
        const { id, part } = target;
        const isCurrent = () => {
            const now = locate();
            return now !== null && now.id === id && now.part === part;
        };
        const withTimeout = (work, onTimeout) => {
            const remaining = deadline - Date.now();
            if (remaining <= 0)
                return Promise.reject(new Error("timeout"));
            return new Promise((resolve, reject) => {
                const timer = setTimeout(() => {
                    try {
                        onTimeout();
                    }
                    catch { /* Aborting is best effort. */ }
                    reject(new Error("timeout"));
                }, Math.min(REQUEST_MS, remaining));
                Promise.resolve().then(work).then((value) => { clearTimeout(timer); resolve(value); }, (error) => { clearTimeout(timer); reject(error); });
            });
        };
        const readBody = async (response) => {
            const declared = Number(response.headers?.get?.("content-length"));
            if (Number.isFinite(declared) && declared > MAX_BODY_BYTES)
                throw new Error("too_large");
            const stream = response.body;
            if (!stream || typeof stream.getReader !== "function") {
                const text = await response.text();
                if (text.length > MAX_BODY_BYTES)
                    throw new Error("too_large");
                return text;
            }
            const reader = stream.getReader();
            const chunks = [];
            let total = 0;
            try {
                for (;;) {
                    const next = await reader.read();
                    if (next.done)
                        break;
                    const chunk = next.value;
                    if (!ArrayBuffer.isView(chunk))
                        throw new Error("body_unavailable");
                    total += chunk.byteLength;
                    if (total > MAX_BODY_BYTES) {
                        try {
                            void reader.cancel().catch(() => undefined);
                        }
                        catch { /* Already closed. */ }
                        throw new Error("too_large");
                    }
                    chunks.push(new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength));
                }
            }
            finally {
                try {
                    reader.releaseLock();
                }
                catch { /* A consumed body is already released. */ }
            }
            const bytes = new Uint8Array(total);
            let offset = 0;
            for (const chunk of chunks) {
                bytes.set(chunk, offset);
                offset += chunk.byteLength;
            }
            return new TextDecoder().decode(bytes);
        };
        // One bounded request. `credentials` is "include" only for api.bilibili.com;
        // the signed subtitle CDN URL authenticates itself and is fetched without
        // cookies. Every redirect target is revalidated against the trusted host.
        const fetchText = async (url, credentials, trusted) => {
            if (url.protocol !== "https:" || url.username || url.password || !trusted(url.hostname.toLowerCase())) {
                throw new Error("untrusted");
            }
            const controller = typeof AbortController === "function" ? new AbortController() : undefined;
            return withTimeout(async () => {
                const response = await fetch(url.toString(), { credentials, ...(controller ? { signal: controller.signal } : {}) });
                if (!response.ok)
                    throw new Error("http");
                if (response.url) {
                    const final = new URL(response.url);
                    if (final.protocol !== "https:" || final.username || final.password || !trusted(final.hostname.toLowerCase())) {
                        try {
                            void response.body?.cancel().catch(() => undefined);
                        }
                        catch { /* Nothing to cancel. */ }
                        throw new Error("untrusted");
                    }
                }
                return readBody(response);
            }, () => controller?.abort());
        };
        const apiHost = (host) => host === "api.bilibili.com";
        const fetchApi = async (path) => {
            const text = await fetchText(new URL(`https://api.bilibili.com${path}`), "include", apiHost);
            return asRecord(JSON.parse(text));
        };
        // 1. The video's data. The page's own state is only trusted while it still
        // describes the video in the URL (Bilibili navigates between episodes without
        // reloading); otherwise the public view API for this very id supplies it.
        const sameVideo = (data) => {
            if (!data)
                return false;
            return id.startsWith("BV") ? data.bvid === id : positiveInteger(data.aid) === Number(id.slice(2));
        };
        const readState = () => {
            try {
                return asRecord(globalThis.__INITIAL_STATE__);
            }
            catch {
                return null;
            }
        };
        const state = readState();
        const stateVideo = asRecord(state?.videoData);
        let video = sameVideo(stateVideo) ? stateVideo : null;
        const fromState = video !== null;
        if (!video) {
            try {
                const query = id.startsWith("BV") ? `bvid=${id}` : `aid=${id.slice(2)}`;
                const viewed = await fetchApi(`/x/web-interface/view?${query}`);
                const data = viewed?.code === 0 ? asRecord(viewed.data) : null;
                if (sameVideo(data))
                    video = data;
            }
            catch { /* Reported below as a stale or missing page state. */ }
        }
        if (!isCurrent())
            return fail("stale_player_response");
        if (!video) {
            // A state describing another video is stale; a state without video data is
            // not a page this adapter understands; no state yet means the page is loading.
            return fail(stateVideo ? "stale_player_response" : state ? "capture_unavailable" : "caption_player_not_ready");
        }
        const pages = Array.isArray(video.pages) ? video.pages : [];
        const partEntry = asRecord(pages[part - 1]);
        if (part > 1 && (!partEntry || (partEntry.page !== undefined && partEntry.page !== part))) {
            return fail("capture_unavailable");
        }
        const cid = positiveInteger(partEntry?.cid) ?? (part === 1 ? positiveInteger(video.cid) : null);
        if (cid === null)
            return fail("capture_unavailable");
        const aid = positiveInteger(video.aid);
        const cleanedTitle = typeof video.title === "string" ? clean(video.title) : "";
        const partName = typeof partEntry?.part === "string" ? clean(partEntry.part) : "";
        const title = (pages.length > 1
            ? `${cleanedTitle} p${String(part).padStart(2, "0")} ${partName}`.trim()
            : cleanedTitle || (typeof document.title === "string" ? clean(document.title.replace(/[_-]\s*哔哩哔哩.*$/u, "")) : "")).slice(0, 1_000) || null;
        const owner = asRecord(video.owner);
        const uploader = fromState ? asRecord(state?.upData) : null;
        const authorValue = typeof owner?.name === "string" ? owner.name : typeof uploader?.name === "string" ? uploader.name : "";
        const author = clean(authorValue).slice(0, 1_000) || null;
        const durationValue = partEntry?.duration ?? video.duration;
        const duration = typeof durationValue === "number" && Number.isFinite(durationValue) && durationValue >= 0 && durationValue <= 31_536_000
            ? Math.floor(durationValue)
            : null;
        // Bilibili stores "-" when a video has no description; control characters go.
        const description = (() => {
            if (typeof video.desc !== "string")
                return null;
            const text = Array.from(video.desc.replace(/\r\n?/g, "\n"))
                .filter((character) => {
                const code = character.codePointAt(0) ?? 0;
                return code === 9 || code === 10 || (code >= 32 && code !== 127);
            })
                .join("")
                .trim()
                .slice(0, 50_000)
                .trim();
            return text && text !== "-" ? text : null;
        })();
        const coverUrl = (() => {
            if (typeof video.pic !== "string")
                return null;
            try {
                const cover = new URL(video.pic.trim().replace(/^http:/i, "https:"), "https://www.bilibili.com/");
                if (cover.protocol !== "https:" || cover.username || cover.password || !hdslbHost(cover.hostname.toLowerCase()))
                    return null;
                const stripped = `https://${cover.hostname.toLowerCase()}${cover.pathname}`;
                return stripped.length <= 2_048 ? stripped : null;
            }
            catch {
                return null;
            }
        })();
        const tags = fromState && Array.isArray(state?.tags)
            ? state.tags.flatMap((entry) => {
                const name = asRecord(entry)?.tag_name;
                const tag = typeof name === "string" ? clean(name).slice(0, 200) : "";
                return tag ? [tag] : [];
            }).filter((tag, index, all) => all.indexOf(tag) === index).slice(0, 20)
            : [];
        // 2. The player API lists this part's subtitles and chapters. No request
        // signature is needed; the viewer's cookies unlock login-only subtitles.
        let info;
        try {
            const query = aid !== null ? `aid=${aid}` : `bvid=${encodeURIComponent(String(video.bvid))}`;
            info = await fetchApi(`/x/player/wbi/v2?${query}&cid=${cid}`);
        }
        catch (error) {
            return fail(error instanceof SyntaxError ? "caption_parse_failed" : "caption_fetch_failed");
        }
        if (!info || info.code !== 0)
            return fail("caption_fetch_failed");
        const data = asRecord(info.data);
        if (!isCurrent())
            return fail("stale_player_response");
        const chapters = (() => {
            const points = Array.isArray(data?.view_points) ? data.view_points : [];
            const parsed = [];
            for (const entry of points.slice(0, 2_000)) {
                const point = asRecord(entry);
                const chapterTitle = typeof point?.content === "string" ? clean(point.content).slice(0, 500) : "";
                const from = point?.from;
                if (!chapterTitle || typeof from !== "number" || !Number.isFinite(from) || from < 0)
                    continue;
                parsed.push({ title: chapterTitle, start_sec: from });
            }
            const ordered = parsed
                .sort((left, right) => left.start_sec - right.start_sec)
                .filter((chapter, index, all) => index === 0 || chapter.start_sec > all[index - 1].start_sec)
                .slice(0, 1_000);
            return ordered.map((chapter, index) => ({
                title: chapter.title,
                start_sec: chapter.start_sec,
                end_sec: ordered[index + 1]?.start_sec ?? (duration !== null && duration >= chapter.start_sec ? duration : null),
            }));
        })();
        const baseCapture = (caption) => ({
            platform: "bilibili",
            platform_id: id,
            canonical_url: `https://www.bilibili.com/video/${id}`,
            page_url: part > 1 ? `https://www.bilibili.com/video/${id}?p=${part}` : `https://www.bilibili.com/video/${id}`,
            metadata: {
                title,
                author,
                duration_sec: duration,
                language: caption.status === "available" ? caption.language : null,
                description,
                cover_url: coverUrl,
                tags,
                chapters,
            },
            caption,
        });
        const subtitleBlock = asRecord(data?.subtitle);
        const listed = Array.isArray(subtitleBlock?.subtitles) ? subtitleBlock.subtitles : [];
        const tracks = [];
        let refused = 0;
        for (const entry of listed.slice(0, 50)) {
            const item = asRecord(entry);
            const lan = typeof item?.lan === "string" ? item.lan.trim().toLowerCase().replace(/_/g, "-") : "";
            const rawUrl = typeof item?.subtitle_url === "string" ? item.subtitle_url.trim() : "";
            if (!lan || !rawUrl || rawUrl.length > 4_096)
                continue;
            let url;
            try {
                url = new URL(rawUrl.startsWith("//") ? `https:${rawUrl}` : rawUrl.replace(/^http:/i, "https:"));
            }
            catch {
                refused += 1;
                continue;
            }
            if (url.protocol !== "https:" || url.username || url.password || !hdslbHost(url.hostname.toLowerCase())) {
                refused += 1;
                continue;
            }
            const auto = lan.startsWith("ai-");
            const base = (auto ? lan.slice(3) : lan).split("-")[0] ?? "";
            tracks.push({ url, language: base || "und", auto, rank: (auto ? 2 : 0) + (base === "zh" ? 0 : 1) });
        }
        if (!tracks.length) {
            // Subtitles that were listed but not trusted are a failed read, not an absence.
            return refused > 0
                ? fail("caption_fetch_failed")
                : { status: "no_caption", capture: baseCapture({ status: "unavailable", source: null, language: null, cues: [] }) };
        }
        tracks.sort((left, right) => left.rank - right.rank);
        const parseSubtitle = (body) => {
            const lines = Array.isArray(asRecord(body)?.body) ? asRecord(body).body : [];
            const cues = [];
            for (const entry of lines) {
                const line = asRecord(entry);
                const from = line?.from;
                const to = line?.to;
                const text = typeof line?.content === "string" ? clean(line.content) : "";
                if (typeof from !== "number" || !Number.isFinite(from) || from < 0 || !text || text.length > 10_000)
                    continue;
                const end = typeof to === "number" && Number.isFinite(to) ? Math.max(to, from) : from;
                cues.push({ start_sec: from, end_sec: end, text });
            }
            return cues.sort((left, right) => left.start_sec - right.start_sec);
        };
        const errors = [];
        for (const track of tracks.slice(0, MAX_SUBTITLE_TRIES)) {
            let text;
            try {
                text = await fetchText(track.url, "omit", hdslbHost);
            }
            catch {
                errors.push("caption_fetch_failed");
                continue;
            }
            let cues;
            try {
                cues = parseSubtitle(JSON.parse(text));
            }
            catch {
                errors.push("caption_parse_failed");
                continue;
            }
            if (!cues.length) {
                errors.push("caption_parse_failed");
                continue;
            }
            if (cues.length > MAX_CUES || cues.reduce((total, cue) => total + cue.text.length, 0) > MAX_TEXT_CHARS) {
                errors.push("caption_parse_failed");
                continue;
            }
            if (!isCurrent())
                return fail("stale_player_response");
            return {
                status: "captured",
                capture: baseCapture({ status: "available", source: track.auto ? "auto_caption" : "official_cc", language: track.language, cues }),
            };
        }
        return fail(errors.includes("caption_fetch_failed") ? "caption_fetch_failed" : "caption_parse_failed");
    }
    catch {
        return fail("capture_unavailable");
    }
}
const MAX_SEEK_SEC = 31_536_000;
/** True for a playback position the player helpers accept: finite, non-negative, at most one year. */
export function isSeekSeconds(value) {
    return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= MAX_SEEK_SEC;
}
/**
 * MAIN-world player probe and seek; keep this function self-contained for MV3
 * (Chrome serialises `func`, so it may use only its own arguments and globals).
 * With `seekSec === null` it only reads the position of this frame's video.
 */
export function controlPlayer(seekSec, kind) {
    try {
        if (typeof document.querySelectorAll !== "function")
            return { status: "no_video" };
        const moviePlayer = kind === "youtube" && typeof document.getElementById === "function"
            ? document.getElementById("movie_player")
            : null;
        let candidates;
        if (kind === "youtube") {
            // While an ad plays, the main video element holds the ad, not the page's video.
            if (moviePlayer?.classList?.contains("ad-showing"))
                return { status: "no_video" };
            // Hover previews elsewhere on the page also use <video>; only the main player counts.
            const main = Array.from(document.querySelectorAll("video.html5-main-video"));
            candidates = (main.length ? main : Array.from(document.querySelectorAll("#movie_player video")));
        }
        else if (kind === "bilibili") {
            // The player renders a <video> or a <bwp-video> element (both expose the media
            // API). Hover previews on other cards also use <video>, so the main player's
            // wrapper wins and the whole page is only a fallback.
            const main = Array.from(document.querySelectorAll(".bpx-player-video-wrap video, .bpx-player-video-wrap bwp-video, #bilibili-player video, #bilibili-player bwp-video, #bilibiliPlayer video, #bilibiliPlayer bwp-video"));
            candidates = (main.length ? main : Array.from(document.querySelectorAll("video, bwp-video")));
        }
        else {
            candidates = Array.from(document.querySelectorAll("video"));
        }
        const entries = candidates.map((video) => {
            const duration = Number(video.duration);
            const known = Number.isFinite(duration) && duration > 0;
            const ready = video.readyState >= 1 && known;
            return { video, duration: known ? duration : null, ready, playing: ready && !video.paused && !video.ended };
        });
        const rank = (entry) => (entry.ready ? 2 : 0) + (entry.playing ? 1 : 0);
        const best = entries.reduce((chosen, entry) => (!chosen || rank(entry) > rank(chosen) ? entry : chosen), undefined);
        if (!best)
            return { status: "no_video" };
        let seeked = false;
        if (seekSec !== null) {
            const target = best.duration !== null ? Math.min(seekSec, best.duration) : seekSec;
            if (kind === "youtube") {
                const global = globalThis;
                const player = moviePlayer ?? global.movie_player;
                try {
                    if (player && typeof player.seekTo === "function") {
                        player.seekTo(target, true);
                        seeked = true;
                    }
                }
                catch { /* Fall back to the media element below. */ }
            }
            if (kind === "bilibili") {
                const player = globalThis.player;
                try {
                    if (player && typeof player.seek === "function") {
                        player.seek(target);
                        seeked = true;
                    }
                }
                catch { /* Fall back to the media element below. */ }
            }
            if (!seeked) {
                try {
                    best.video.currentTime = target;
                    seeked = true;
                }
                catch { /* A page-owned element may refuse the assignment. */ }
            }
        }
        let current = Number(best.video.currentTime);
        if (kind === "bilibili" && seekSec === null) {
            try {
                const player = globalThis.player;
                const reported = typeof player?.getCurrentTime === "function" ? Number(player.getCurrentTime()) : Number.NaN;
                if (Number.isFinite(reported) && reported >= 0)
                    current = reported;
            }
            catch { /* The media element's position stands. */ }
        }
        return {
            status: "video",
            current_sec: Number.isFinite(current) && current >= 0 ? current : 0,
            ready: best.ready,
            playing: best.playing,
            seeked,
        };
    }
    catch {
        return { status: "no_video" };
    }
}
function parseVideoProbe(value) {
    try {
        if (!value || typeof value !== "object")
            return null;
        const probe = value;
        if (probe.status !== "video")
            return null;
        if (!isSeekSeconds(probe.current_sec))
            return null;
        if (typeof probe.ready !== "boolean" || typeof probe.playing !== "boolean" || typeof probe.seeked !== "boolean")
            return null;
        return { status: "video", current_sec: probe.current_sec, ready: probe.ready, playing: probe.playing, seeked: probe.seeked };
    }
    catch {
        return null;
    }
}
async function runPlayerProbe(tabId, target, kind, seekSec) {
    const results = await chrome.scripting.executeScript({
        target: { tabId, ...target },
        world: "MAIN",
        func: controlPlayer,
        args: [seekSec, kind],
    });
    return results.flatMap((entry) => {
        try {
            if (!entry || typeof entry !== "object")
                return [];
            const frame = entry;
            const probe = parseVideoProbe(frame.result);
            if (!probe)
                return [];
            return [{ frameId: typeof frame.frameId === "number" && Number.isInteger(frame.frameId) && frame.frameId >= 0 ? frame.frameId : null, probe }];
        }
        catch {
            return [];
        }
    });
}
/** Reads every frame; a rejected all-frames call (one inaccessible frame) retries the top frame only. */
async function probeFrames(tabId, kind, seekSec, targets) {
    for (const target of targets) {
        try {
            return await runPlayerProbe(tabId, target, kind, seekSec);
        }
        catch { /* Try the next, narrower target. */ }
    }
    return [];
}
function playerTargets(kind) {
    // The Kaltura player lives in a cross-origin frame; YouTube's and Bilibili's are in the top frame.
    return kind === "ntu_kaltura" ? [{ allFrames: true }, { allFrames: false }] : [{ allFrames: false }];
}
function bestFrame(frames) {
    const rank = (frame) => (frame.probe.ready ? 2 : 0) + (frame.probe.playing ? 1 : 0);
    return frames.reduce((best, frame) => {
        if (!best || rank(frame) > rank(best))
            return frame;
        if (rank(frame) === rank(best) && (frame.frameId ?? Infinity) < (best.frameId ?? Infinity))
            return frame;
        return best;
    }, undefined);
}
/** Current playback position in seconds, or null when the page has no ready video. */
export async function readPlaybackSeconds(tabId, url) {
    const kind = classifyPageUrl(url);
    if (!kind)
        throw new Error("unsupported_page");
    const best = bestFrame(await probeFrames(tabId, kind, null, playerTargets(kind)));
    return best?.probe.ready ? Math.round(best.probe.current_sec * 1000) / 1000 : null;
}
/** Seeks the page's player; rejects with `seek_failed` when no player accepted the position. */
export async function seekPlayback(tabId, url, startSec) {
    if (!isSeekSeconds(startSec))
        throw new Error("invalid_command");
    const kind = classifyPageUrl(url);
    if (!kind)
        throw new Error("unsupported_page");
    if (kind !== "ntu_kaltura") {
        // YouTube's and Bilibili's players live in the top frame.
        const frames = await probeFrames(tabId, kind, startSec, playerTargets(kind));
        if (!frames.some((frame) => frame.probe.seeked))
            throw new Error("seek_failed");
        return;
    }
    // Locate the frame holding the player first, so a stray video in another
    // frame is never moved.
    const best = bestFrame(await probeFrames(tabId, kind, null, playerTargets(kind)));
    if (!best)
        throw new Error("seek_failed");
    const targets = best.frameId !== null ? [{ frameIds: [best.frameId] }] : [{ allFrames: true }];
    const frames = await probeFrames(tabId, kind, startSec, targets);
    if (!frames.some((frame) => frame.probe.seeked))
        throw new Error("seek_failed");
}
