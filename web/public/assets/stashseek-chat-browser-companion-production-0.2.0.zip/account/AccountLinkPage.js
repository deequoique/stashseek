import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMutation } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { ApiError, consumeLinkToken, createTelegramLinkToken } from "../api/client";
const LINK_TOKEN_MAX_LENGTH = 128;
const TELEGRAM_BOT_HANDLE = "@notebook_agent_bot";
const TELEGRAM_BOT_URL = "https://t.me/notebook_agent_bot";
const LINK_ERROR_MESSAGES = {
    link_token_used: "该绑定码已使用，请在 Telegram Bot 中重新发送 /link web 获取新的绑定码。",
    link_token_expired: "该绑定码已过期，请在 Telegram Bot 中重新发送 /link web 获取新的绑定码。",
    link_channel_mismatch: "该绑定码的目标渠道不匹配，请回到 Telegram Bot 重新获取。",
    link_merge_busy: "目标账户仍有内容正在处理，请稍后使用同一个绑定码重试。",
    link_account_disabled: "账户当前不可用，暂时无法完成绑定。",
    link_source_unbound: "Telegram 账户尚未注册，请先在 Bot 中发送 /start 后再试。",
    link_merge_conflict: "账户状态发生变化，请在 Telegram Bot 中重新获取绑定码后再试。",
    link_token_invalid: "绑定码无效，请检查后重试。",
    session_invalid: "登录已失效，请重新登录。",
};
export function linkErrorMessage(error, fallback = "绑定暂时没有完成，请稍后重试。") {
    if (error instanceof ApiError)
        return LINK_ERROR_MESSAGES[error.code] ?? fallback;
    return fallback;
}
export function AccountLinkPage({ createToken = createTelegramLinkToken, consumeToken = consumeLinkToken, onLinked, }) {
    const [generatedToken, setGeneratedToken] = useState(null);
    const [tokenDraft, setTokenDraft] = useState("");
    const [tokenInputError, setTokenInputError] = useState(null);
    const [copyStatus, setCopyStatus] = useState(null);
    const commandRef = useRef(null);
    const createMutation = useMutation({
        mutationFn: createToken,
        // Link tokens are credentials. Remove the mutation response as soon as
        // this observer is replaced or unmounted instead of retaining it for the
        // default MutationCache garbage-collection window.
        gcTime: 0,
        onSuccess: ({ token }) => {
            setGeneratedToken(token);
            setCopyStatus(null);
        },
    });
    const consumeMutation = useMutation({
        mutationFn: (token) => consumeToken(token),
        // The pasted token is also stored as mutation variables, so it needs the
        // same immediate in-memory teardown when the user leaves this feature.
        gcTime: 0,
        onSuccess: (result) => {
            if (result.linked)
                onLinked();
            else
                setTokenInputError("绑定暂时没有完成，请稍后重试。");
        },
    });
    const command = generatedToken ? `/link ${generatedToken}` : null;
    const createError = createMutation.isError
        ? linkErrorMessage(createMutation.error, "暂时无法生成绑定码，请稍后重试。")
        : null;
    const consumeError = consumeMutation.isError
        ? linkErrorMessage(consumeMutation.error)
        : null;
    function generateToken() {
        if (!createMutation.isPending)
            createMutation.mutate();
    }
    async function copyCommand() {
        if (!command)
            return;
        try {
            const writeText = navigator.clipboard?.writeText;
            if (!writeText)
                throw new Error("clipboard_unavailable");
            await writeText.call(navigator.clipboard, command);
            setCopyStatus("copied");
        }
        catch {
            // Keep the command visible for keyboard selection when clipboard access
            // is unavailable or denied by the browser.
            commandRef.current?.focus();
            setCopyStatus("fallback");
        }
    }
    function submitToken(event) {
        event.preventDefault();
        if (consumeMutation.isPending)
            return;
        const value = tokenDraft.trim();
        if (!value) {
            setTokenInputError("请输入 Telegram Bot 返回的绑定码。");
            consumeMutation.reset();
            return;
        }
        if (value.length > LINK_TOKEN_MAX_LENGTH) {
            setTokenInputError("绑定码过长，请检查后重试。");
            consumeMutation.reset();
            return;
        }
        setTokenInputError(null);
        consumeMutation.mutate(value);
    }
    return (_jsxs("section", { className: "account-link-page telegram-link-page", "aria-labelledby": "account-link-title", children: [_jsxs("header", { className: "account-link-page__heading", children: [_jsx("p", { className: "eyebrow", children: "\u8D26\u6237\u8BBE\u7F6E" }), _jsx("h1", { id: "account-link-title", children: "\u7ED1\u5B9A Telegram" }), _jsx("p", { children: "\u7ED1\u5B9A\u540E\uFF0C\u63D2\u4EF6\u5DE5\u4F5C\u533A\u90AE\u7BB1\u8D26\u6237\u548C Telegram Bot \u4F1A\u5171\u7528\u540C\u4E00\u4EFD\u79C1\u4EBA\u8D44\u6599\u5E93\uFF1B\u4E24\u4E2A\u6E20\u9053\u7684\u804A\u5929\u5386\u53F2\u4ECD\u7136\u72EC\u7ACB\u4FDD\u5B58\u3002" })] }), _jsxs("div", { className: "account-link-grid", children: [_jsxs("section", { className: "account-link-card", "aria-labelledby": "account-link-web-title", children: [_jsxs("header", { className: "account-link-card__header", children: [_jsxs("div", { className: "account-link-card__meta", "aria-hidden": "true", children: [_jsx("p", { className: "step-number", children: "01" }), _jsx("span", { children: "WEB \u2192 TELEGRAM" })] }), _jsx("h2", { id: "account-link-web-title", children: "\u4ECE\u63D2\u4EF6\u5DE5\u4F5C\u533A\u53D1\u8D77\u7ED1\u5B9A" }), _jsx("p", { children: "\u5728\u8FD9\u91CC\u751F\u6210\u4E00\u6B21\u6027\u6307\u4EE4\uFF0C\u518D\u53D1\u9001\u7ED9 Telegram Bot\u3002" })] }), _jsxs("p", { className: "account-link-bot", children: [_jsx("span", { children: "\u540C\u4E00\u4E2A Telegram Bot" }), _jsxs("a", { href: TELEGRAM_BOT_URL, target: "_blank", rel: "noopener noreferrer", "aria-label": `${TELEGRAM_BOT_HANDLE}（在新标签页打开）`, children: [TELEGRAM_BOT_HANDLE, _jsx("span", { "aria-hidden": "true", children: " \u2197" })] })] }), _jsxs("div", { className: "account-link-action-panel", children: [_jsxs("div", { className: "field account-link-command-field", children: [_jsx("span", { className: "account-link-field-label", id: "web-link-command-label", children: "Telegram \u7ED1\u5B9A\u6307\u4EE4" }), _jsx("div", { className: `account-link-token-slot${command ? " has-value" : ""}`, "aria-labelledby": "web-link-command-label", "aria-live": "polite", children: command ? (_jsx("code", { ref: commandRef, tabIndex: 0, children: command })) : (_jsx("span", { children: "\u751F\u6210\u540E\u5C06\u5728\u8FD9\u91CC\u663E\u793A\u4E00\u6B21\u6027 /link \u6307\u4EE4" })) }), _jsx("p", { className: "field-help", children: command
                                                    ? "绑定码短期有效，只能使用一次，请勿转发给他人。"
                                                    : "指令只在本页临时显示；离开页面后不会保留。" })] }), _jsx("button", { className: "button button--primary button--wide", type: "button", onClick: generateToken, disabled: createMutation.isPending, children: createMutation.isPending
                                            ? "正在生成…"
                                            : generatedToken
                                                ? "重新生成绑定码"
                                                : "生成 Telegram 绑定码" }), command ? (_jsx("button", { className: "button button--quiet button--wide", type: "button", onClick: () => void copyCommand(), children: "\u590D\u5236\u6307\u4EE4" })) : null, copyStatus === "copied" ? (_jsx("p", { className: "account-link-status", role: "status", children: "\u6307\u4EE4\u5DF2\u590D\u5236\uFF0C\u53EF\u4EE5\u7C98\u8D34\u5230 Telegram Bot\u3002" })) : null, copyStatus === "fallback" ? (_jsx("p", { className: "account-link-status", role: "status", children: "\u6D4F\u89C8\u5668\u672A\u5141\u8BB8\u590D\u5236\uFF0C\u8BF7\u9009\u4E2D\u4E0A\u65B9\u6307\u4EE4\u540E\u624B\u52A8\u590D\u5236\u3002" })) : null] }), command ? (_jsx("p", { className: "field-help account-link-token-note", children: "\u91CD\u65B0\u751F\u6210\u4E0D\u4F1A\u5728\u9875\u9762\u4E0A\u58F0\u660E\u65E7\u7801\u5DF2\u64A4\u9500\uFF0C\u6700\u7EC8\u72B6\u6001\u4EE5\u540E\u7AEF\u4E3A\u51C6\u3002" })) : null, createError ? _jsx("p", { className: "inline-error", role: "alert", children: createError }) : null] }), _jsxs("section", { className: "account-link-card", "aria-labelledby": "account-link-telegram-title", children: [_jsxs("header", { className: "account-link-card__header", children: [_jsxs("div", { className: "account-link-card__meta", "aria-hidden": "true", children: [_jsx("p", { className: "step-number", children: "02" }), _jsx("span", { children: "TELEGRAM \u2192 WEB" })] }), _jsx("h2", { id: "account-link-telegram-title", children: "\u4ECE Telegram \u53D1\u8D77\u7ED1\u5B9A" }), _jsxs("p", { children: ["\u5148\u5411 Bot \u53D1\u9001 ", _jsx("code", { children: "/link web" }), "\uFF0C\u518D\u628A\u8FD4\u56DE\u7684\u7ED1\u5B9A\u7801\u7C98\u8D34\u5230\u8FD9\u91CC\u3002"] })] }), _jsxs("p", { className: "account-link-bot", children: [_jsx("span", { children: "\u540C\u4E00\u4E2A Telegram Bot" }), _jsxs("a", { href: TELEGRAM_BOT_URL, target: "_blank", rel: "noopener noreferrer", "aria-label": `${TELEGRAM_BOT_HANDLE}（在新标签页打开）`, children: [TELEGRAM_BOT_HANDLE, _jsx("span", { "aria-hidden": "true", children: " \u2197" })] })] }), _jsxs("form", { className: "account-link-form account-link-action-panel", onSubmit: submitToken, noValidate: true, children: [_jsxs("div", { className: "field", children: [_jsx("label", { htmlFor: "telegram-link-token", children: "Telegram \u7ED1\u5B9A\u7801" }), _jsx("input", { id: "telegram-link-token", name: "telegram-link-token", type: "text", autoComplete: "off", spellCheck: false, maxLength: LINK_TOKEN_MAX_LENGTH, value: tokenDraft, onChange: (event) => {
                                                    setTokenDraft(event.target.value);
                                                    if (tokenInputError)
                                                        setTokenInputError(null);
                                                    if (consumeMutation.isError)
                                                        consumeMutation.reset();
                                                }, "aria-describedby": "telegram-link-token-help" }), _jsx("p", { className: "field-help", id: "telegram-link-token-help", children: "\u53EA\u5728\u672C\u9875\u4E34\u65F6\u4F7F\u7528\uFF1B\u683C\u5F0F\u3001\u6709\u6548\u671F\u548C\u8D26\u6237\u5F52\u5E76\u72B6\u6001\u7531\u670D\u52A1\u5668\u6821\u9A8C\u3002" })] }), _jsx("button", { className: "button button--primary button--wide", type: "submit", disabled: consumeMutation.isPending, children: consumeMutation.isPending ? "正在绑定…" : "确认绑定" }), tokenInputError ? _jsx("p", { className: "inline-error", role: "alert", children: tokenInputError }) : null, consumeError ? _jsx("p", { className: "inline-error", role: "alert", children: consumeError }) : null, consumeMutation.isPending ? (_jsx("p", { className: "account-link-status", "aria-live": "polite", children: "\u6B63\u5728\u786E\u8BA4\u8D26\u6237\u5F52\u5E76\uFF0C\u8BF7\u4E0D\u8981\u91CD\u590D\u63D0\u4EA4\u3002" })) : null] })] })] }), _jsx("p", { className: "account-link-warning", role: "note", children: "\u7ED1\u5B9A\u7801\u548C Bot \u51ED\u636E\u4E0D\u4F1A\u4FDD\u5B58\u5230\u6D4F\u89C8\u5668\u3001\u7F51\u5740\u6216\u804A\u5929\u8BB0\u5F55\u4E4B\u5916\u7684\u641C\u85CF\u52A9\u624B\u65E5\u5FD7\u4E2D\u3002" })] }));
}
