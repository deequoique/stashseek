import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { CollectionTags } from "../library/CollectionTags";
import { formatWhySavedWithCollections, parseWhySaved, validateCollectionName, WHY_SAVED_MAX_LENGTH, } from "../library/collections";
import { lifecycleCopy } from "../library/lifecycle";
import { formatDuration } from "../library/VideoCard";
import { RouteLink } from "../app/RouteTransition";
function timestampUrl(url, seconds, platform) {
    const parsed = new URL(url);
    if (platform === "ntu_kaltura")
        return `${parsed.origin}${parsed.pathname}`;
    if (platform === "bilibili")
        parsed.search = "";
    parsed.searchParams.set("t", String(Math.max(0, Math.floor(seconds))));
    return parsed.toString();
}
function formatTimestamp(seconds) {
    return formatDuration(seconds) ?? "0:00";
}
function formatLanguage(code) {
    if (!code)
        return null;
    const normalized = code.trim().toLowerCase();
    const names = {
        zh: "中文",
        "zh-cn": "简体中文",
        "zh-hans": "简体中文",
        "zh-tw": "繁体中文",
        "zh-hant": "繁体中文",
        en: "英文",
        "en-us": "英文",
        "en-gb": "英文",
        ja: "日文",
        ko: "韩文",
    };
    return names[normalized] ?? names[normalized.split("-")[0] ?? ""] ?? null;
}
function titleDensity(title) {
    const wideCharacter = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u;
    const visualLength = Array.from(title).reduce((length, character) => length + (wideCharacter.test(character) ? 2 : 1), 0);
    return visualLength > 44 ? "compact" : "standard";
}
export function VideoDetailView({ item, initiallyEditSavedContext = false, transcriptPages, onLoadMore, onRetryTranscript, onArchive, onRestore, onRetry, onUpdateWhySaved, actionPending = false, actionError = false, transcriptPending = false, transcriptInitialPending = false, transcriptError = false, }) {
    const savedContext = parseWhySaved(item.why_saved);
    const title = item.title?.trim() || "视频信息尚未准备好";
    const [editingReason, setEditingReason] = useState(initiallyEditSavedContext);
    const [reason, setReason] = useState(savedContext.reason);
    const [collections, setCollections] = useState(savedContext.collections);
    const [newCollection, setNewCollection] = useState("");
    const [collectionError, setCollectionError] = useState(null);
    const blocks = transcriptPages.flatMap((page) => page.blocks);
    const nextCursor = transcriptPages.at(-1)?.next_cursor ?? null;
    const actions = new Set(item.available_actions);
    const language = formatLanguage(item.lang);
    const platformLabel = item.platform === "ntu_kaltura"
        ? "NTULearn"
        : item.platform === "bilibili" ? "Bilibili" : "YouTube";
    const collectionSuffixLength = collections.reduce((total, name) => total + name.length + 1, Math.max(0, collections.length - 1));
    const reasonLimit = Math.max(0, WHY_SAVED_MAX_LENGTH - collectionSuffixLength - (collections.length > 0 ? 1 : 0));
    function toggleSavedContextEditing() {
        if (!editingReason) {
            setReason(savedContext.reason);
            setCollections(savedContext.collections);
            setNewCollection("");
            setCollectionError(null);
        }
        setEditingReason((value) => !value);
    }
    function addCollection() {
        const validationError = validateCollectionName(newCollection);
        if (validationError) {
            setCollectionError(validationError);
            return;
        }
        const normalized = parseWhySaved(`#${newCollection.trim().replace(/^#/u, "")}`).collections[0];
        if (!normalized)
            return;
        setCollections((current) => current.some((name) => name.toLocaleLowerCase("en") === normalized.toLocaleLowerCase("en"))
            ? current
            : [...current, normalized]);
        setNewCollection("");
        setCollectionError(null);
    }
    async function submitReason(event) {
        event.preventDefault();
        try {
            const formatted = formatWhySavedWithCollections(reason, collections);
            if (formatted.error)
                throw new Error(formatted.error);
            await onUpdateWhySaved(formatted.value);
            setEditingReason(false);
        }
        catch {
            // The parent mutation renders a safe error while this form stays editable.
        }
    }
    return (_jsxs("article", { className: "detail-layout", children: [_jsxs("header", { className: "detail-hero", children: [_jsx("div", { className: "detail-cover", children: item.cover_url ? _jsx("img", { src: item.cover_url, alt: "", width: 960, height: 540, fetchPriority: "high" }) : _jsx("div", { className: "cover-placeholder cover-placeholder--large", "aria-hidden": "true", children: _jsx("span", { children: "\u6682\u65E0\u5C01\u9762" }) }) }), _jsxs("div", { className: "detail-heading", children: [_jsx("span", { className: `status-pill status-pill--${item.lifecycle}`, children: lifecycleCopy[item.lifecycle].label }), _jsx("h1", { className: "detail-title", "data-title-density": titleDensity(title), children: title }), _jsxs("p", { className: "detail-meta", children: [item.author ? _jsx("span", { children: item.author }) : null, item.duration_sec !== null ? _jsx("span", { children: formatDuration(item.duration_sec) }) : null, language ? _jsx("span", { children: language }) : null] }), _jsxs("div", { className: "detail-actions", "aria-label": "\u89C6\u9891\u64CD\u4F5C", children: [_jsxs("a", { className: "button button--primary", href: item.url, target: "_blank", rel: "noreferrer", children: ["\u5728 ", platformLabel, " \u67E5\u770B"] }), actions.has("retry") ? _jsx("button", { className: "button button--quiet", disabled: actionPending, onClick: onRetry, children: "\u91CD\u65B0\u6574\u7406" }) : null, actions.has("archive") ? _jsx("button", { className: "button button--ghost", disabled: actionPending, onClick: onArchive, children: "\u5F52\u6863" }) : null, actions.has("restore") ? _jsx("button", { className: "button button--quiet", disabled: actionPending, onClick: onRestore, children: "\u6062\u590D\u5230\u8D44\u6599\u5E93" }) : null] }), actionError ? _jsx("p", { className: "inline-error", role: "alert", "aria-label": "\u89C6\u9891\u64CD\u4F5C\u5931\u8D25", children: "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002" }) : null, item.error_code === "youtube_rate_limited" ? _jsxs("p", { className: "inline-error", children: ["\u670D\u52A1\u5668\u6682\u65F6\u65E0\u6CD5\u8BBF\u95EE YouTube\u3002\u4F60\u53EF\u4EE5\u6253\u5F00\u539F\u89C6\u9891\uFF0C\u4F7F\u7528 ", _jsx(RouteLink, { to: "/account/browser-companion", children: "\u6D4F\u89C8\u5668\u4F34\u4FA3" }), " \u4ECE\u5F53\u524D\u6D4F\u89C8\u5668\u4FDD\u5B58\u5B57\u5E55\u3002"] }) : null, item.error_code === "bilibili_rate_limited" ? _jsx("p", { className: "inline-error", children: "\u670D\u52A1\u5668\u6682\u65F6\u65E0\u6CD5\u8BBF\u95EE Bilibili\uFF0C\u8BF7\u7A0D\u540E\u91CD\u65B0\u6574\u7406\u3002" }) : null] })] }), _jsxs("section", { className: "detail-section reason-section", id: "saved-context", "aria-labelledby": "reason-title", children: [_jsxs("div", { className: "section-heading-row", children: [_jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "\u4FDD\u5B58\u8BF4\u660E" }), _jsx("h2", { id: "reason-title", children: "\u4E3A\u4EC0\u4E48\u4FDD\u5B58" })] }), actions.has("edit_why_saved") ? _jsx("button", { className: "text-button", onClick: toggleSavedContextEditing, children: editingReason ? "取消" : "编辑说明和收藏夹" }) : null] }), !editingReason ? _jsx(CollectionTags, { names: savedContext.collections, className: "collection-tag-list--detail" }) : null, editingReason ? (_jsxs("form", { className: "saved-context-form", onSubmit: submitReason, children: [_jsxs("fieldset", { className: "detail-collection-editor", children: [_jsx("legend", { children: "\u6240\u5C5E\u6536\u85CF\u5939" }), collections.length > 0 ? (_jsx("ul", { className: "editable-collection-list", "aria-label": "\u6B63\u5728\u7F16\u8F91\u7684\u6536\u85CF\u5939", children: collections.map((name) => (_jsxs("li", { children: [_jsxs("span", { children: ["#", name] }), _jsx("button", { type: "button", "aria-label": `移除收藏夹 ${name}`, onClick: () => setCollections((current) => current.filter((value) => value !== name)), children: "\u00D7" })] }, name.toLocaleLowerCase("en")))) })) : _jsx("p", { className: "field-help", children: "\u5F53\u524D\u672A\u5F52\u7C7B\uFF0C\u53EF\u4EE5\u5728\u4E0B\u65B9\u6DFB\u52A0\u4E00\u4E2A\u6536\u85CF\u5939\u3002" }), _jsxs("div", { className: "detail-collection-create", children: [_jsxs("label", { className: "field", children: [_jsx("span", { children: "\u65B0\u6536\u85CF\u5939" }), _jsx("input", { name: "detail-new-collection", autoComplete: "off", value: newCollection, maxLength: 21, placeholder: "\u4F8B\u5982\uFF1A\u4EA7\u54C1\u8C03\u7814", onChange: (event) => { setNewCollection(event.target.value); setCollectionError(null); } })] }), _jsx("button", { className: "button button--quiet", type: "button", onClick: addCollection, children: "\u6DFB\u52A0" })] }), collectionError ? _jsx("p", { className: "inline-error", role: "alert", children: collectionError }) : null] }), _jsxs("label", { className: "field", children: [_jsx("span", { className: "sr-only", children: "\u4FDD\u5B58\u8BF4\u660E" }), _jsx("textarea", { name: "why-saved-detail", autoComplete: "off", rows: 3, maxLength: reasonLimit, value: reason, onChange: (event) => setReason(event.target.value) })] }), _jsx("button", { className: "button button--quiet", disabled: actionPending, type: "submit", children: "\u4FDD\u5B58\u8BF4\u660E\u548C\u6536\u85CF\u5939" })] })) : _jsx("p", { children: savedContext.reason || "还没有添加保存说明。" })] }), item.chapters.length > 0 ? (_jsxs("section", { className: "detail-section", "aria-labelledby": "chapters-title", children: [_jsx("p", { className: "eyebrow", children: "\u5FEB\u901F\u8DF3\u8F6C" }), _jsx("h2", { id: "chapters-title", children: "\u7AE0\u8282" }), _jsx("ol", { className: "chapter-list", "aria-label": "\u89C6\u9891\u7AE0\u8282", tabIndex: 0, children: item.chapters.map((chapter, index) => {
                            const start = Number(chapter.start_sec ?? chapter.start_time ?? chapter.start ?? 0);
                            return (_jsx("li", { children: _jsxs("a", { href: timestampUrl(item.url, start, item.platform), target: "_blank", rel: "noreferrer", children: [_jsx("time", { children: formatTimestamp(start) }), _jsx("span", { children: chapter.title?.trim() || `章节 ${index + 1}` })] }) }, `${start}-${index}`));
                        }) })] })) : null, item.description?.trim() ? (_jsxs("section", { className: "detail-section", "aria-labelledby": "description-title", children: [_jsxs("p", { className: "eyebrow", children: ["\u6765\u81EA ", platformLabel] }), _jsx("h2", { id: "description-title", children: "\u89C6\u9891\u7B80\u4ECB" }), _jsx("p", { className: "description-copy", children: item.description })] })) : null, item.summary?.trim() ? (_jsxs("section", { className: "detail-section", "aria-labelledby": "summary-title", children: [_jsx("p", { className: "eyebrow", children: "\u6574\u7406\u7ED3\u679C" }), _jsx("h2", { id: "summary-title", children: "\u6458\u8981" }), _jsx("p", { className: "description-copy", children: item.summary })] })) : null, _jsxs("section", { className: "detail-section transcript-section", "aria-labelledby": "transcript-title", children: [_jsxs("div", { className: "section-heading-row", children: [_jsxs("div", { className: "transcript-heading-copy", children: [_jsx("p", { className: "eyebrow", children: "\u6839\u636E\u539F\u89C6\u9891\u5B57\u5E55\u6574\u7406" }), _jsx("h2", { id: "transcript-title", children: "\u5B57\u5E55\u8282\u9009" }), _jsx("p", { className: "transcript-guide", children: "\u70B9\u51FB\u65F6\u95F4\u8DF3\u5230\u539F\u89C6\u9891\u5BF9\u5E94\u4F4D\u7F6E" })] }), blocks.length > 0 ? _jsxs("span", { className: "block-count", children: ["\u8282\u9009 ", blocks.length, " \u6BB5"] }) : null] }), transcriptError ? (_jsxs("div", { className: "inline-error transcript-error", role: "alert", "aria-label": "\u5B57\u5E55\u52A0\u8F7D\u5931\u8D25", children: [_jsx("p", { children: "\u5B57\u5E55\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002" }), onRetryTranscript ? _jsx("button", { className: "button button--quiet", type: "button", onClick: onRetryTranscript, children: "\u91CD\u65B0\u52A0\u8F7D\u5B57\u5E55" }) : null] })) : transcriptInitialPending ? (_jsx("p", { className: "muted", "aria-live": "polite", "aria-busy": "true", children: "\u6B63\u5728\u52A0\u8F7D\u5B57\u5E55\u2026" })) : blocks.length > 0 ? (_jsxs("div", { className: "transcript-reader", role: "region", "aria-label": "\u5B57\u5E55\u8282\u9009\uFF0C\u53EF\u6EDA\u52A8\u67E5\u770B", tabIndex: 0, children: [_jsx("ol", { className: "transcript-list", children: blocks.map((block) => (_jsxs("li", { children: [_jsx("a", { href: block.source_url, target: "_blank", rel: "noreferrer", "aria-label": `从 ${formatTimestamp(block.start_sec)} 播放`, children: _jsx("time", { children: formatTimestamp(block.start_sec) }) }), _jsx("p", { children: block.text })] }, block.ordinal))) }), nextCursor ? _jsx("button", { className: "button button--quiet button--wide", disabled: transcriptPending, onClick: onLoadMore, children: "\u7EE7\u7EED\u52A0\u8F7D\u5B57\u5E55" }) : null] })) : (_jsx("p", { className: "muted", children: item.lifecycle === "ready" ? "这个视频没有可显示的字幕。" : "整理完成后可查看字幕。" }))] })] }));
}
