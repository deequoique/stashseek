/** Reads once straight away, then every `intervalMs` until stopped, the deadline, or `onResult` says stop. */
export function startPolling(options) {
    let timer = null;
    let stopped = false;
    let reading = false;
    const clear = () => {
        if (timer !== null)
            clearTimeout(timer);
        timer = null;
    };
    const schedule = (delayMs) => {
        if (stopped)
            return;
        clear();
        timer = setTimeout(() => { void tick(); }, delayMs);
    };
    async function tick() {
        timer = null;
        if (stopped || reading)
            return;
        if (options.now() >= options.deadlineAt) {
            stopped = true;
            options.onDeadline();
            return;
        }
        if (!options.isVisible()) {
            schedule(options.intervalMs);
            return;
        }
        reading = true;
        let nextDelay = options.intervalMs;
        try {
            const value = await options.fetch();
            if (stopped)
                return;
            if (options.onResult(value) === "stop") {
                stopped = true;
                return;
            }
        }
        catch (error) {
            if (stopped)
                return;
            if (options.onError(error) === "stop") {
                stopped = true;
                return;
            }
            nextDelay = options.backoffMs;
        }
        finally {
            reading = false;
        }
        schedule(nextDelay);
    }
    schedule(0);
    return {
        stop() {
            stopped = true;
            clear();
        },
        nudge() {
            if (stopped || reading)
                return;
            schedule(0);
        },
    };
}
