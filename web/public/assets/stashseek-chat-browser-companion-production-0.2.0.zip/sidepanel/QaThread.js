import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { MarkdownAnswer } from "../chat/MarkdownAnswer";
import { StepTimeline, useAutoCollapse } from "../chat/StepTimeline";
import { formatTimestamp, panelAnswerText } from "./copy";
import { collectProgress, collectResult, collectSteps, collectSummary, collectWorkspacePath, qaSteps, qaSummary } from "./steps";
function CitationChips({ citations, onOpen, }) {
    if (!citations.length)
        return null;
    return (_jsx("ol", { className: "sp-citations", "aria-label": "\u56DE\u7B54\u4F9D\u636E", children: citations.map((citation, index) => {
            const time = typeof citation.start_sec === "number" ? formatTimestamp(citation.start_sec) : null;
            return (_jsxs("li", { children: [_jsxs("button", { className: "sp-citation", type: "button", title: time ? `跳转到 ${time}` : "在新标签页打开", onClick: () => onOpen(citation), children: [_jsx("span", { className: "sp-citation__time", children: time ?? "打开" }), _jsx("span", { className: "sp-citation__title", children: citation.title })] }), _jsxs("details", { className: "sp-citation__excerpt", children: [_jsx("summary", { children: "\u5C55\u5F00\u5B57\u5E55\u4F9D\u636E" }), _jsx("p", { children: citation.excerpt })] })] }, `${citation.url}:${citation.start_sec ?? ""}:${index}`));
        }) }));
}
/** Client-side steps above a streamed answer; folds away once the answer starts. */
function TurnSteps({ turn }) {
    const steps = qaSteps(turn);
    const [expanded, setExpanded] = useAutoCollapse(turn.answer !== "" || turn.status !== "streaming");
    return (_jsx(StepTimeline, { className: "sp-timeline", summary: qaSummary(steps), steps: steps, expanded: expanded, onToggle: setExpanded, stepsLabel: "\u56DE\u7B54\u6B65\u9AA4" }));
}
/** Re-renders every `tickMs` while `active`, returning the current time. */
function useClock(now, tickMs, active) {
    const [value, setValue] = useState(now);
    useEffect(() => {
        if (!active)
            return undefined;
        setValue(now());
        const timer = setInterval(() => setValue(now()), tickMs);
        return () => clearInterval(timer);
    }, [active, now, tickMs]);
    return value;
}
/** The 「收藏视频」 action as a tool-call-style block: steps, elapsed time and ETA, then the way to the item. */
function CollectBlock({ entry, now, tickMs, onOpenWorkspace }) {
    const active = entry.phase !== "done";
    const clock = useClock(now, tickMs, active);
    const progress = collectProgress(entry, clock);
    const steps = collectSteps(entry).map((step) => (step.outcome === "running" && progress ? { ...step, detail: _jsx("small", { className: "sp-step-detail", children: progress }) } : step));
    const [expanded, setExpanded] = useAutoCollapse(entry.outcome === "ready" || entry.outcome === "already_exists");
    const result = collectResult(entry);
    const workspacePath = collectWorkspacePath(entry);
    return (_jsxs("article", { className: "sp-collect", "aria-busy": active, "aria-label": "\u6536\u85CF\u89C6\u9891", children: [_jsx(StepTimeline, { className: "sp-timeline", summary: collectSummary(entry, steps), steps: steps, expanded: expanded, onToggle: setExpanded, stepsLabel: "\u6536\u85CF\u6B65\u9AA4" }), result ? _jsx("p", { className: "sp-collect__result", "data-tone": result.tone, role: "status", children: result.text }) : null, workspacePath ? (_jsx("button", { className: "sp-link sp-collect__link", type: "button", onClick: () => onOpenWorkspace(workspacePath), children: "\u5728\u5DE5\u4F5C\u533A\u67E5\u770B" })) : null] }));
}
export function QaThread({ thread, now, clockTickMs, onOpenCitation, onRetry, onOpenWorkspace }) {
    return (_jsx("ol", { className: "sp-turns", "aria-label": "\u89C6\u9891\u95EE\u7B54", children: thread.map((entry) => {
            if (entry.kind === "collect") {
                return (_jsx("li", { className: "sp-turn sp-turn--action", children: _jsx(CollectBlock, { entry: entry, now: now, tickMs: clockTickMs, onOpenWorkspace: onOpenWorkspace }) }, entry.id));
            }
            const turn = entry;
            return (_jsxs("li", { className: "sp-turn", children: [_jsx("p", { className: "sp-question", children: turn.question }), _jsxs("article", { className: `sp-answer sp-answer--${turn.status}`, "aria-busy": turn.status === "streaming", children: [_jsx(TurnSteps, { turn: turn }), turn.status === "streaming" && !turn.answer ? _jsx("p", { className: "sr-only", role: "status", children: "\u6B63\u5728\u56DE\u7B54\u2026" }) : null, turn.answer ? _jsx(MarkdownAnswer, { children: panelAnswerText(turn.answer, turn.citations.length > 0) }) : null, turn.status === "failed" || turn.status === "stopped" ? (_jsxs("p", { className: "sp-answer__state", role: turn.status === "failed" ? "alert" : "status", children: [turn.error, turn.status === "failed" ? (_jsxs(_Fragment, { children: [" ", _jsx("button", { className: "sp-link", type: "button", onClick: () => onRetry(turn.id), children: "\u91CD\u8BD5" })] })) : null] })) : null, turn.status === "done" ? _jsx(CitationChips, { citations: turn.citations, onOpen: onOpenCitation }) : null] })] }, turn.id));
        }) }));
}
