/** A failed worker command. `code` is the worker's stable error string. */
export class WorkerError extends Error {
    code;
    constructor(code) {
        super(code);
        this.code = code;
        this.name = "WorkerError";
    }
}
async function send(command) {
    let reply;
    try {
        reply = await chrome.runtime.sendMessage(command);
    }
    catch {
        throw new WorkerError("worker_unavailable");
    }
    if (typeof reply !== "object" || reply === null)
        throw new WorkerError("worker_unavailable");
    const { ok, result, error } = reply;
    if (ok === true)
        return result;
    throw new WorkerError(typeof error === "string" && error ? error : "request_failed");
}
export const workerApi = {
    status: () => send({ type: "STATUS" }),
    startLogin: async (email) => { await send({ type: "START_LOGIN", email }); },
    finishLogin: async (email, code) => { await send({ type: "FINISH_LOGIN", email, code }); },
    readPage: (tabId) => send({ type: "READ_PAGE", tabId }),
    playback: async (tabId) => (await send({ type: "PLAYBACK", tabId })).playback_sec,
    seek: async (tabId, startSec) => { await send({ type: "SEEK", tabId, start_sec: startSec }); },
    saveCapture: (page) => send({ type: "SAVE_CAPTURE", page }),
    openWorkspace: async () => { await send({ type: "OPEN_WORKSPACE" }); },
    disconnect: async () => { await send({ type: "DISCONNECT" }); },
};
