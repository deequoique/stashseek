export const TERMINAL_OUTCOMES = new Set([
    "ready",
    "already_exists",
    "needs_action",
    "failed",
    "archived",
    "submitted",
    "timeout",
    "quota_exceeded",
    "unsupported_url",
    "unsupported_part",
    "submit_failed",
]);
export function newCollectEntry(id, videoKey, now) {
    return {
        kind: "collect",
        id,
        videoKey,
        phase: "reading",
        path: null,
        fallback: null,
        itemPublicId: null,
        startedAt: now,
        durationSec: null,
        segments: null,
        captionless: false,
        existing: false,
        stage: null,
        stageSince: null,
        workingStage: null,
        sawTranscribing: false,
        outcome: null,
        errorCode: null,
        retryable: false,
        retrying: false,
    };
}
/** Ends the entry with an outcome that needs no further polling. */
export function finishEntry(entry, outcome, errorCode = null) {
    return { ...entry, phase: "done", outcome, errorCode: errorCode ?? entry.errorCode, retrying: false };
}
const WORKING_STAGES = new Set(["queued", "fetching", "transcribing", "chunking", "embedding"]);
export function isWorkingStage(stage) {
    return stage !== null && WORKING_STAGES.has(stage);
}
/** The stage of an item from a server that predates the `stage` field. */
function stageFromLifecycle(item, path) {
    if (item.lifecycle === "processing")
        return path === "capture" ? "chunking" : "fetching";
    return item.lifecycle;
}
const SIX_HOURS_MS = 6 * 60 * 60 * 1000;
/**
 * When a stage began. The first stage seen may predate the click (an item that was already being
 * processed), so the server's timestamp is used once, clamped to the past. Later stages begin when
 * the panel sees the change: the server timestamp is the dispatch time, which is older than any
 * stage after the first.
 */
function stageStart(item, first, now) {
    if (!first || !item.stage_updated_at)
        return now;
    const serverTime = Date.parse(item.stage_updated_at);
    return Number.isFinite(serverTime) && serverTime <= now && now - serverTime < SIX_HOURS_MS ? serverTime : now;
}
function outcomeFor(item, entry) {
    switch (item.lifecycle) {
        case "ready": return entry.existing ? "already_exists" : "ready";
        case "needs_action": return "needs_action";
        case "failed": return "failed";
        case "archived": return "archived";
        default: return null;
    }
}
/** Folds one library item read into the entry. */
export function applyItem(entry, item, now) {
    const stage = item.stage ?? stageFromLifecycle(item, entry.path);
    const changed = stage !== entry.stage;
    const next = {
        ...entry,
        retrying: false,
        durationSec: item.duration_sec ?? entry.durationSec,
        retryable: item.available_actions.includes("retry"),
        stage,
        stageSince: changed ? stageStart(item, entry.stage === null, now) : entry.stageSince,
    };
    if (isWorkingStage(stage)) {
        next.workingStage = stage;
        if (stage === "transcribing")
            next.sawTranscribing = true;
    }
    const outcome = outcomeFor(item, entry);
    if (outcome) {
        next.phase = "done";
        next.outcome = outcome;
        next.errorCode = item.error_code ?? null;
    }
    return next;
}
export function toStored(entry) {
    const stored = { ...entry };
    delete stored.retrying;
    return stored;
}
const PATHS = new Set(["capture", "url"]);
const STAGES = new Set(["queued", "fetching", "transcribing", "chunking", "embedding", "ready", "needs_action", "failed", "archived"]);
const FALLBACKS = new Set(["read_failed", "no_captions", "not_paired", "capture_failed"]);
/** Restores a persisted entry, or null when the stored value is not a usable in-progress entry. */
export function parseStored(value) {
    if (typeof value !== "object" || value === null)
        return null;
    const v = value;
    const text = (key) => (typeof v[key] === "string" ? v[key] : null);
    const num = (key) => (typeof v[key] === "number" && Number.isFinite(v[key]) ? v[key] : null);
    const id = text("id");
    const videoKey = text("videoKey");
    const itemPublicId = text("itemPublicId");
    const startedAt = num("startedAt");
    if (!id || !videoKey || !itemPublicId || startedAt === null)
        return null;
    // Only an item that was being followed can resume; earlier phases leave nothing to follow.
    if (v.phase !== "tracking" || !PATHS.has(v.path))
        return null;
    const working = text("workingStage");
    return {
        ...newCollectEntry(id, videoKey, startedAt),
        phase: "tracking",
        path: v.path,
        fallback: FALLBACKS.has(v.fallback) ? v.fallback : null,
        itemPublicId,
        durationSec: num("durationSec"),
        segments: num("segments"),
        captionless: v.captionless === true,
        existing: v.existing === true,
        stage: STAGES.has(v.stage) ? v.stage : null,
        stageSince: num("stageSince"),
        workingStage: isWorkingStage(working) ? working : null,
        sawTranscribing: v.sawTranscribing === true,
        retryable: v.retryable === true,
    };
}
