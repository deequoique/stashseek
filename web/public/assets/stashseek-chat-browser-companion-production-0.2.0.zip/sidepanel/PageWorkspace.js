import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { BILIBILI_NO_CAPTIONS_HINT, workerErrorCopy } from "./copy";
import { PanelLogin } from "./PanelLogin";
import { QaThread } from "./QaThread";
import { isActiveCollect } from "./useCollect";
import { questionBlock, usePageQa } from "./usePageQa";
const MAX_QUESTION_CHARS = 4000;
const SUGGESTIONS = ["这个视频讲了什么？", "刚才说的是什么意思？"];
const PLATFORM_LABEL = { youtube: "YouTube", ntu_kaltura: "NTULearn", bilibili: "哔哩哔哩" };
function captionLine(session) {
    if (session.readStatus === "error")
        return { tone: "error", text: workerErrorCopy(session.readError ?? "request_failed") };
    const { page } = session;
    if (!page)
        return { tone: "loading", text: "正在读取字幕…" };
    const block = questionBlock(page);
    if (page.caption.status === "available") {
        const kind = page.caption.source === "auto_caption" ? "自动字幕" : "官方字幕";
        return { tone: "ready", text: `字幕可用 · ${kind} · ${page.caption.cues.length} 条` };
    }
    return block
        ? { tone: "action", text: block }
        : { tone: "action", text: "该视频没有字幕，提问将仅基于标题和简介回答" };
}
export function PageWorkspace({ deps, paired, pageQa, onPairedChange, onSessionInvalid, onLogout }) {
    const controller = usePageQa(deps, onSessionInvalid, { paired, onGrantRejected: () => onPairedChange(false) });
    const { tab, session } = controller;
    const [draft, setDraft] = useState("");
    const [connecting, setConnecting] = useState(false);
    function openWorkspaceRoute(route) {
        void deps.tabs.openUrl(deps.workspaceUrl(route));
    }
    function submit(event) {
        event.preventDefault();
        if (!draft.trim() || session?.asking)
            return;
        controller.ask(draft);
        setDraft("");
    }
    const ready = session?.readStatus === "ready";
    const block = session?.page ? questionBlock(session.page) : null;
    const asking = session?.asking === true;
    const caption = session ? captionLine(session) : null;
    const collecting = session?.thread.some(isActiveCollect) === true;
    return (_jsxs("div", { className: "sp-shell", children: [_jsxs("header", { className: "sp-brand", children: [_jsx("span", { className: "sp-brand__mark", "aria-hidden": "true", children: _jsx("i", {}) }), _jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "STASHSEEK CHAT" }), _jsx("p", { className: "sp-brand__name", children: "\u641C\u85CF\u52A9\u624B" })] }), _jsx("button", { className: "sp-link", type: "button", onClick: onLogout, children: "\u9000\u51FA\u767B\u5F55" })] }), tab === undefined ? _jsx("p", { className: "sp-hint", role: "status", children: "\u6B63\u5728\u8BFB\u53D6\u5F53\u524D\u9875\u9762\u2026" }) : null, tab !== undefined && !session ? (_jsxs("section", { className: "sp-hint sp-empty", "aria-labelledby": "sp-empty-title", children: [_jsx("h1", { id: "sp-empty-title", children: "\u6253\u5F00 YouTube \u6216\u54D4\u54E9\u54D4\u54E9\u89C6\u9891\u540E\u63D0\u95EE" }), _jsx("p", { children: "\u5207\u5230\u4E00\u4E2A\u89C6\u9891\u9875\uFF0C\u5C31\u53EF\u4EE5\u76F4\u63A5\u95EE\u5B83\u8BB2\u4E86\u4EC0\u4E48\uFF0C\u5E76\u8DF3\u5230\u5BF9\u5E94\u7684\u65F6\u95F4\u70B9\u3002" })] })) : null, session ? (_jsxs(_Fragment, { children: [_jsxs("section", { className: "sp-video", "aria-labelledby": "sp-video-title", children: [_jsx("p", { className: "eyebrow", children: PLATFORM_LABEL[session.platform] }), _jsx("h1", { id: "sp-video-title", children: session.page?.metadata.title ?? (session.readStatus === "error" ? "无法读取视频信息" : "正在读取视频信息…") }), caption ? (_jsxs("div", { className: "sp-status", "data-tone": caption.tone, children: [_jsx("span", { className: "sp-status__dot", "aria-hidden": "true" }), _jsx("p", { role: "status", children: caption.text })] })) : null, session.page?.platform === "bilibili" && session.page.caption.status === "unavailable" ? (_jsx("p", { className: "sp-hint", children: BILIBILI_NO_CAPTIONS_HINT })) : null, session.readStatus === "error" ? (_jsx("button", { className: "text-button", type: "button", onClick: controller.reread, children: "\u91CD\u65B0\u8BFB\u53D6" })) : null, _jsx("button", { className: "button button--primary button--wide sp-collect-button", type: "button", disabled: collecting, onClick: controller.collect, children: collecting ? "收藏中…" : "收藏视频" }), connecting ? (_jsxs("div", { className: "sp-connect", children: [_jsx("p", { children: "\u8FDE\u63A5\u8FD9\u53F0\u8BBE\u5907\u540E\uFF0C\u6536\u85CF\u65F6\u53EF\u4EE5\u76F4\u63A5\u8BFB\u53D6\u6D4F\u89C8\u5668\u91CC\u7684\u5B57\u5E55\uFF08\u5305\u62EC\u9700\u8981\u767B\u5F55\u624D\u80FD\u770B\u7684\u5B57\u5E55\uFF09\uFF0C\u8BF7\u7528\u90AE\u7BB1\u9A8C\u8BC1\u7801\u786E\u8BA4\u3002" }), _jsx(PanelLogin, { worker: deps.worker, onCancel: () => setConnecting(false), onDone: () => { onPairedChange(true); setConnecting(false); } })] })) : paired ? null : (_jsx("button", { className: "text-button sp-connect-toggle", type: "button", onClick: () => setConnecting(true), children: "\u8FDE\u63A5\u8FD9\u53F0\u8BBE\u5907\uFF0C\u76F4\u63A5\u8BFB\u53D6\u6D4F\u89C8\u5668\u91CC\u7684\u5B57\u5E55" })), _jsx("p", { className: "sp-privacy", children: "\u63D0\u95EE\u65F6\u5B57\u5E55\u53EA\u7528\u4E8E\u751F\u6210\u56DE\u7B54\uFF0C\u5386\u53F2\u8BB0\u5F55\u53EA\u4FDD\u7559\u5F15\u7528\u7684\u77ED\u53E5\uFF1B\u70B9\u300C\u6536\u85CF\u89C6\u9891\u300D\u624D\u4F1A\u628A\u89C6\u9891\u4FDD\u5B58\u5230\u8D44\u6599\u5E93\u3002" })] }), _jsxs("section", { className: "sp-qa", "aria-label": "\u5C31\u5F53\u524D\u89C6\u9891\u63D0\u95EE", children: [pageQa && session.thread.length === 0 && !block ? (_jsx("div", { className: "sp-suggestions", "aria-label": "\u793A\u4F8B\u95EE\u9898", children: SUGGESTIONS.map((suggestion) => (_jsx("button", { type: "button", onClick: () => setDraft(suggestion), children: suggestion }, suggestion))) })) : null, _jsx(QaThread, { thread: session.thread, now: deps.now, clockTickMs: deps.clockTickMs, onOpenCitation: (citation) => { void controller.openCitation(citation); }, onRetry: controller.retry, onOpenWorkspace: openWorkspaceRoute }), controller.notice ? _jsx("p", { className: "sp-hint", role: "status", children: controller.notice }) : null, pageQa ? null : _jsx("p", { className: "sp-hint", children: "\u5F53\u524D\u670D\u52A1\u672A\u5F00\u653E\u89C6\u9891\u95EE\u7B54\uFF0C\u4F60\u4ECD\u7136\u53EF\u4EE5\u6536\u85CF\u89C6\u9891\u3002" })] }), pageQa && !block ? (_jsxs("form", { className: "sp-compose", onSubmit: submit, children: [_jsx("label", { className: "sr-only", htmlFor: "sp-question", children: "\u5C31\u5F53\u524D\u89C6\u9891\u63D0\u95EE" }), _jsx("textarea", { id: "sp-question", rows: 2, maxLength: MAX_QUESTION_CHARS, value: draft, disabled: !ready, placeholder: ready ? "就这个视频提问…" : "正在读取字幕…", onChange: (event) => setDraft(event.target.value), onKeyDown: (event) => {
                                    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                                        event.preventDefault();
                                        event.currentTarget.form?.requestSubmit();
                                    }
                                } }), asking ? (_jsx("button", { className: "button button--quiet", type: "button", onClick: controller.stop, children: "\u505C\u6B62" })) : (_jsx("button", { className: "button button--primary", type: "submit", disabled: !ready || !draft.trim(), children: "\u53D1\u9001" }))] })) : null] })) : null, _jsx("footer", { className: "sp-footer", children: _jsx("button", { className: "text-button", type: "button", onClick: () => { void deps.worker.openWorkspace(); }, children: "\u6253\u5F00\u5DE5\u4F5C\u533A" }) })] }));
}
