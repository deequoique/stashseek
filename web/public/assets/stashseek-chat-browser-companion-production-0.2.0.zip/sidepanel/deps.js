import { getCapabilities, getLibraryItem, getSession, streamPageQuestion, submitVideoBatch } from "../api/client";
import { newConversationId } from "./pageIdentity";
import { workerApi } from "./workerApi";
function toPanelTab(tab) {
    return tab?.id === undefined ? null : { id: tab.id, url: tab.url ?? null };
}
async function queryActive() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return toPanelTab(tab);
}
const chromeTabs = {
    getActive: queryActive,
    subscribe(listener) {
        let activeId = null;
        let live = true;
        const deliver = (tab) => {
            if (!live)
                return;
            activeId = tab?.id ?? null;
            listener(tab);
        };
        const refresh = () => { void queryActive().then(deliver, () => deliver(null)); };
        const onUpdated = (tabId, change, tab) => {
            // Other tabs, and updates that change neither the URL nor the load state, cannot change the video.
            if (tabId !== activeId || (change.url === undefined && change.status !== "complete"))
                return;
            deliver(toPanelTab(tab));
        };
        chrome.tabs.onActivated.addListener(refresh);
        chrome.tabs.onUpdated.addListener(onUpdated);
        refresh();
        return () => {
            live = false;
            chrome.tabs.onActivated.removeListener(refresh);
            chrome.tabs.onUpdated.removeListener(onUpdated);
        };
    },
    async openUrl(url) {
        await chrome.tabs.create({ url });
    },
};
const COLLECT_STORAGE_KEY = "collectEntries";
async function readCollectMap() {
    const stored = await chrome.storage.session.get([COLLECT_STORAGE_KEY]);
    const value = stored[COLLECT_STORAGE_KEY];
    return typeof value === "object" && value !== null ? value : {};
}
/** `chrome.storage.session`: cleared when the browser closes and never shared with web pages. Failures are not fatal. */
const sessionCollectStore = {
    async load(videoKey) {
        try {
            return (await readCollectMap())[videoKey] ?? null;
        }
        catch {
            return null;
        }
    },
    async save(videoKey, entry) {
        try {
            await chrome.storage.session.set({ [COLLECT_STORAGE_KEY]: { ...(await readCollectMap()), [videoKey]: entry } });
        }
        catch { /* Resuming is a convenience. */ }
    },
    async clear(videoKey) {
        try {
            const rest = await readCollectMap();
            delete rest[videoKey];
            await chrome.storage.session.set({ [COLLECT_STORAGE_KEY]: rest });
        }
        catch { /* Resuming is a convenience. */ }
    },
};
export const defaultDeps = {
    worker: workerApi,
    tabs: chromeTabs,
    getSession,
    getCapabilities,
    streamQuestion: streamPageQuestion,
    submitBatch: submitVideoBatch,
    getItem: getLibraryItem,
    collectStore: sessionCollectStore,
    now: () => Date.now(),
    isVisible: () => document.visibilityState === "visible",
    workspaceUrl: (route) => chrome.runtime.getURL(`workspace.html#${route}`),
    createId: () => crypto.randomUUID(),
    createConversationId: newConversationId,
    settleDelayMs: 600,
    retryDelayMs: 1500,
    requestTimeoutMs: 10_000,
    pollIntervalMs: 2_500,
    pollBackoffMs: 10_000,
    pollMaxMs: 30 * 60 * 1000,
    collectReadWaitMs: 20_000,
    clockTickMs: 1_000,
};
