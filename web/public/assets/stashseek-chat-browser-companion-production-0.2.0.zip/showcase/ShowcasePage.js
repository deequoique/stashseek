import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { BrandLogo } from "../app/BrandLogo";
import { BROWSER_COMPANION_DOWNLOAD_URL } from "../app/browserCompanion";
import { RouteLink } from "../app/RouteTransition";
const demoScenes = [
    {
        id: "product",
        index: "01",
        audience: "产品调研",
        title: "从礼貌反馈里，找出真实需求",
        question: "我该怎样采访早期用户，才不会只得到礼貌性的肯定？",
        sourceTitle: "How to Talk to Users",
        sourceCreator: "Eric Migicovsky · Y Combinator",
        sourceUrl: "https://www.youtube.com/watch?v=MT4Ig2uqjTc",
        thumbnailUrl: "https://i.ytimg.com/vi/MT4Ig2uqjTc/hqdefault.jpg",
        previewSummary: {
            zh: "先从最近一次真实经历问起：最困难的环节是什么、目前怎样解决，以及是否已经为替代方案付出时间或金钱。",
            en: "Start with a recent real experience: ask what was hardest, how it was handled, and whether the person already sought an alternative.",
        },
        summaryDurationSeconds: { zh: 36, en: 42 },
        answerLead: "不要先推销方案，也不要让用户预测未来。把对话拉回到已经发生过的具体经历。",
        answerPoints: [
            "先问最近一次遇到问题的时间、地点和上下文，而不是“你会不会用这个功能”。",
            "观察对方是否已经花时间或金钱寻找替代方案，用行动判断痛点强度。",
            "追问现有方案哪里不好，从具体缺口中提炼功能和产品表达。",
        ],
        evidence: [
            {
                label: "06:07",
                note: "从最难的具体环节开始提问",
                url: "https://www.youtube.com/watch?v=MT4Ig2uqjTc&t=367s",
            },
            {
                label: "08:16",
                note: "追问最近一次真实经历",
                url: "https://www.youtube.com/watch?v=MT4Ig2uqjTc&t=496s",
            },
            {
                label: "11:17",
                note: "检查用户是否主动找过解决办法",
                url: "https://www.youtube.com/watch?v=MT4Ig2uqjTc&t=677s",
            },
        ],
    },
    {
        id: "ai",
        index: "02",
        audience: "AI 入门",
        title: "把抽象概念，拆成能复述的结构",
        question: "用高中生能理解的方式解释：神经网络到底在做什么？",
        sourceTitle: "But what is a neural network?",
        sourceCreator: "Grant Sanderson · 3Blue1Brown",
        sourceUrl: "https://www.youtube.com/watch?v=aircAruvnKk",
        thumbnailUrl: "https://i.ytimg.com/vi/aircAruvnKk/hqdefault.jpg",
        previewSummary: {
            zh: "把手写数字图片看成 784 个亮度输入；网络逐层组合这些数字，最后给出 10 个数字类别的判断。",
            en: "Treat a 28×28 image as 784 brightness inputs; layered transformations combine them into scores for ten digit classes.",
        },
        summaryDurationSeconds: { zh: 34, en: 40 },
        answerLead: "可以先把它理解成一个会调参数的数字转换器：输入很多数字，经过多层变换，输出一组判断结果。",
        answerPoints: [
            "示例把一张 28×28 的手写数字图片转换成 784 个亮度值，每个值进入一个输入神经元。",
            "中间层根据权重和偏置计算新的激活值，让像素逐层组合成边缘、形状等更高层特征。",
            "整个网络本质上是一个从 784 个输入到 10 个输出的函数；训练就是不断调整其中的参数。",
        ],
        evidence: [
            {
                label: "03:08",
                note: "28×28 像素如何成为 784 个输入",
                url: "https://www.youtube.com/watch?v=aircAruvnKk&t=188s",
            },
            {
                label: "04:03",
                note: "隐藏层与逐层激活",
                url: "https://www.youtube.com/watch?v=aircAruvnKk&t=243s",
            },
            {
                label: "15:39",
                note: "把整个网络理解成一个函数",
                url: "https://www.youtube.com/watch?v=aircAruvnKk&t=939s",
            },
        ],
    },
    {
        id: "practice",
        index: "03",
        audience: "技能训练",
        title: "把“多练”变成“有效地练”",
        question: "怎样让技能练习更有效，而不是机械重复？",
        sourceTitle: "How to practice effectively...for just about anything",
        sourceCreator: "Annie Bosler & Don Greene · TED-Ed",
        sourceUrl: "https://www.youtube.com/watch?v=f2O6mQkFiiw",
        thumbnailUrl: "https://i.ytimg.com/vi/f2O6mQkFiiw/hqdefault.jpg",
        previewSummary: {
            zh: "有效练习重在专注、挑战能力边缘、慢速建立正确动作，并通过高质量重复与休息持续修正。",
            en: "Effective practice uses focused work near the edge of ability, slow correct repetitions, feedback, and planned breaks.",
        },
        summaryDurationSeconds: { zh: 32, en: 38 },
        answerLead: "有效练习不只看时长，更看注意力、难度边界和反馈质量。",
        answerPoints: [
            "练习时减少干扰，把注意力集中在当前任务和最薄弱的环节上。",
            "新动作先放慢，优先建立正确且高质量的重复，再逐渐提高速度。",
            "把练习拆成多次短时段并安排休息；动作已经建立后，也可以用清晰的心理演练巩固。",
        ],
        evidence: [
            {
                label: "02:26",
                note: "持续、专注且贴近能力边界",
                url: "https://www.youtube.com/watch?v=f2O6mQkFiiw&t=146s",
            },
            {
                label: "03:05",
                note: "先慢速练出正确动作",
                url: "https://www.youtube.com/watch?v=f2O6mQkFiiw&t=185s",
            },
            {
                label: "03:18",
                note: "高频重复与间隔休息",
                url: "https://www.youtube.com/watch?v=f2O6mQkFiiw&t=198s",
            },
        ],
    },
];
const audienceIconPaths = {
    learner: [
        "M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0",
        "M6 21v-2a4 4 0 0 1 4 -4h.5",
        "M17.8 20.817l-2.172 1.138a.392 .392 0 0 1 -.568 -.41l.415 -2.411l-1.757 -1.707a.389 .389 0 0 1 .217 -.665l2.428 -.352l1.086 -2.193a.392 .392 0 0 1 .702 0l1.086 2.193l2.428 .352a.39 .39 0 0 1 .217 .665l-1.757 1.707l.414 2.41a.39 .39 0 0 1 -.567 .411l-2.172 -1.138",
    ],
    research: [
        "M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0",
        "M6 21v-2a4 4 0 0 1 4 -4h1.5",
        "M15 18a3 3 0 1 0 6 0a3 3 0 1 0 -6 0",
        "M20.2 20.2l1.8 1.8",
    ],
    creator: [
        "M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0",
        "M6 21v-2a4 4 0 0 1 4 -4h3.5",
        "M18.42 15.61a2.1 2.1 0 0 1 2.97 2.97l-3.39 3.42h-3v-3l3.42 -3.39",
    ],
    channels: [
        "M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0",
        "M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1",
        "M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0",
        "M17 10h2a2 2 0 0 1 2 2v1",
        "M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0",
        "M3 13v-1a2 2 0 0 1 2 -2h2",
    ],
};
function AudienceIcon({ name }) {
    return (_jsx("span", { className: "showcase-audience__icon", "aria-hidden": "true", children: _jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", children: audienceIconPaths[name].map((path) => _jsx("path", { d: path }, path)) }) }));
}
const audiences = [
    {
        icon: "learner",
        title: "深度学习者",
        copy: "收藏了大量课程、访谈和演讲，希望按问题重新调取，而不是从头重看。",
    },
    {
        icon: "research",
        title: "研究与产品团队",
        copy: "需要跨视频比对观点，并把每个结论快速定位回原始上下文。",
    },
    {
        icon: "creator",
        title: "创作者与知识工作者",
        copy: "想把看过的内容变成可复用素材，同时保留标题、片段与时间戳。",
    },
    {
        icon: "channels",
        title: "跨平台收集",
        copy: "如果部署启用了多个聊天入口，绑定后的账号可以共用一份私人资料库，并通过插件工作区完成登录。",
    },
];
const processSteps = [
    {
        index: "01",
        title: "提交并归档视频来源",
        copy: "通过已启用的聊天入口或插件工作区保存 YouTube 链接，并补充保存理由或预期用途，便于后续识别与筛选。",
        output: "视频来源 + 保存说明",
    },
    {
        index: "02",
        title: "异步解析并建立索引",
        copy: "系统在后台提取视频标题、章节与字幕，将长内容切分为可检索片段，并保留片段与原视频之间的对应关系。",
        output: "字幕与章节 → 内容索引",
    },
    {
        index: "03",
        title: "在个人资料库中检索",
        copy: "用户可以直接用自然语言描述问题；系统只在当前账户的资料库范围内定位相关片段，并组织回答所需的上下文。",
        output: "自然语言问题 → 相关原文",
    },
    {
        index: "04",
        title: "生成带来源依据的回答",
        copy: "回答基于检索到的原文片段生成，并附带视频标题、引用摘录和可跳转时间点，方便回到完整语境核对。",
        output: "回答依据 + 原视频时间点",
    },
];
function ArrowIcon() {
    return (_jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "M5 12h13M13 6l6 6-6 6" }) }));
}
function TypewriterText({ text }) {
    return (_jsxs(_Fragment, { children: [_jsx("span", { className: "sr-only", children: text }), _jsx("span", { className: "demo-typewriter", "aria-hidden": "true", children: text })] }));
}
export function ShowcasePage() {
    const [activeDemoId, setActiveDemoId] = useState("product");
    const [heroCoverId, setHeroCoverId] = useState(null);
    const [hasRun, setHasRun] = useState(false);
    const [summaryLanguage, setSummaryLanguage] = useState("zh");
    const activeDemo = demoScenes.find((scene) => scene.id === activeDemoId) ?? demoScenes[0];
    const activeSummary = activeDemo.previewSummary[summaryLanguage];
    const summaryDuration = activeDemo.summaryDurationSeconds[summaryLanguage];
    function selectDemo(id) {
        setActiveDemoId(id);
        setHasRun(false);
    }
    return (_jsxs("div", { className: "showcase-page", children: [_jsx("a", { className: "showcase-skip", href: "#showcase-main", children: "\u8DF3\u5230\u4E3B\u8981\u5185\u5BB9" }), _jsxs("header", { className: "showcase-nav", children: [_jsxs(RouteLink, { className: "showcase-brand", to: "/", "aria-label": "\u641C\u85CF\u52A9\u624B\u9996\u9875", children: [_jsx(BrandLogo, { className: "showcase-brand__mark" }), _jsx("span", { children: "STASHSEEK / CHAT" })] }), _jsxs("nav", { "aria-label": "\u5C55\u793A\u9875\u5BFC\u822A", children: [_jsx("a", { href: "#purpose", children: "\u9879\u76EE\u76EE\u7684" }), _jsx("a", { href: "#process", children: "\u4F7F\u7528\u6D41\u7A0B" }), _jsx("a", { href: "#demo", children: "\u8BD5\u7528\u573A\u666F" })] }), _jsxs("div", { className: "showcase-nav__actions", children: [_jsx("a", { className: "showcase-nav__companion", download: true, href: BROWSER_COMPANION_DOWNLOAD_URL, children: "\u4E0B\u8F7D\u6D4F\u89C8\u5668\u63D2\u4EF6" }), _jsxs(RouteLink, { className: "showcase-nav__cta", to: "/login", children: ["\u8FDB\u5165\u8D44\u6599\u5E93 ", _jsx(ArrowIcon, {})] })] })] }), _jsxs("main", { id: "showcase-main", tabIndex: -1, children: [_jsxs("section", { className: "showcase-hero", "aria-labelledby": "showcase-title", children: [_jsx("div", { className: "showcase-hero__grid", "aria-hidden": "true" }), _jsxs("div", { className: "showcase-hero__copy", children: [_jsxs("p", { className: "showcase-kicker", children: [_jsx("span", { children: "\u641C\u85CF\u52A9\u624B \u00B7 \u6536\u85CF\u5185\u5BB9\u5BF9\u8BDD" }), _jsx("span", { children: "2026 / HACKATHON" })] }), _jsxs("h1", { id: "showcase-title", children: ["\u8BA9\u6536\u85CF\u8FC7\u7684\u5185\u5BB9\uFF0C", _jsx("em", { children: "\u76F4\u63A5\u56DE\u7B54\u4F60\u3002" })] }), _jsx("p", { className: "showcase-hero__lead", children: "\u4E0D\u7528\u5206\u7C7B\u6216\u6574\u7406\uFF0C\u76F4\u63A5\u95EE\u4E00\u53E5\uFF0C\u5C31\u80FD\u627E\u5230\u6536\u85CF\u8FC7\u7684\u89C6\u9891\u548C\u539F\u6587\u65F6\u95F4\u70B9\u3002" }), _jsxs("div", { className: "showcase-hero__actions", children: [_jsxs("a", { className: "showcase-button showcase-button--signal", href: "#demo", children: ["\u5148\u8BD5\u4E00\u4E2A\u771F\u5B9E\u573A\u666F ", _jsx(ArrowIcon, {})] }), _jsx("a", { className: "showcase-button showcase-button--line", href: "#process", children: "\u67E5\u770B\u5DE5\u4F5C\u65B9\u5F0F" })] })] }), _jsxs("div", { className: "showcase-hero__instrument", "aria-label": "\u4ECE\u89C6\u9891\u5230\u53EF\u8FFD\u6EAF\u7B54\u6848\u7684\u5904\u7406\u8DEF\u5F84", children: [_jsx("div", { className: "instrument-cover-stack", "aria-label": "\u8D44\u6599\u5E93\u4E2D\u7684\u4E09\u4E2A\u771F\u5B9E\u89C6\u9891\u6765\u6E90", onMouseLeave: () => setHeroCoverId(null), children: demoScenes.map((scene, index) => (_jsxs("a", { className: `instrument-cover${heroCoverId === scene.id ? " is-front" : ""}`, href: "#demo", "aria-label": `打开 ${scene.sourceTitle} 问答场景`, onMouseEnter: () => setHeroCoverId(scene.id), onFocus: () => setHeroCoverId(scene.id), onBlur: () => setHeroCoverId(null), onClick: () => selectDemo(scene.id), children: [_jsx("span", { className: "instrument-cover__wire", "aria-hidden": "true" }), _jsx("img", { src: scene.thumbnailUrl, alt: `${scene.sourceTitle} 视频封面`, width: "480", height: "360", decoding: "async", fetchPriority: index === demoScenes.length - 1 ? "high" : "auto" }), _jsxs("span", { className: "instrument-cover__caption", children: [_jsx("span", { children: scene.index }), _jsx("strong", { children: scene.sourceTitle })] })] }, scene.id))) }), _jsxs("div", { className: "instrument-readout", children: [_jsxs("p", { children: [_jsx("span", { children: "\u4F60\u6536\u85CF" }), _jsx("strong", { children: "\u4E00\u6BB5 YouTube \u89C6\u9891" })] }), _jsxs("p", { children: [_jsx("span", { children: "\u7CFB\u7EDF\u6574\u7406" }), _jsx("strong", { children: "\u5B57\u5E55\u4E0E\u91CD\u70B9\u5185\u5BB9" })] }), _jsxs("p", { children: [_jsx("span", { children: "\u4F60\u83B7\u5F97" }), _jsx("strong", { children: "\u7B54\u6848 / \u539F\u6587 / \u65F6\u95F4\u70B9" })] })] })] }), _jsxs("div", { className: "showcase-hero__rail", "aria-label": "\u9879\u76EE\u6838\u5FC3\u80FD\u529B", children: [_jsx("span", { children: "01 / \u6536\u85CF" }), _jsx("span", { children: "02 / \u7406\u89E3" }), _jsx("span", { children: "03 / \u68C0\u7D22" }), _jsx("span", { children: "04 / \u56DE\u6E90" })] })] }), _jsxs("section", { className: "showcase-section showcase-purpose", id: "purpose", "aria-labelledby": "purpose-title", children: [_jsxs("div", { className: "showcase-section__label", children: [_jsx("span", { children: "01" }), _jsx("p", { children: "WHY IT EXISTS" })] }), _jsxs("div", { className: "showcase-purpose__content", children: [_jsx("p", { className: "showcase-overline", children: "\u9879\u76EE\u76EE\u7684" }), _jsxs("h2", { id: "purpose-title", children: ["\u4E0D\u8981\u8BA9\u9057\u5FD8\u6210\u4E3A", _jsx("br", {}), _jsx("em", { children: "\u6536\u85CF\u89C6\u9891\u7684\u7EC8\u70B9\u3002" })] }), _jsxs("div", { className: "showcase-purpose__statement", children: [_jsx("p", { children: "\u5F53\u6211\u4EEC\u6309\u4E0B\u6536\u85CF\u952E\u7684\u5239\u90A3\uFF0C\u4F60\u662F\u5426\u4F1A\u60F3\u5230\u8FD9\u662F\u4F60\u6700\u540E\u4E00\u6B21\u4E0E\u4F60\u7684\u89C6\u9891\u78B0\u9762\uFF1F\u6211\u4EEC\u4E0D\u5E0C\u671B\u89C6\u9891\u53EA\u6210\u4E3A\u6536\u85CF\u5939\u7684\u4E00\u4E32\u94FE\u63A5\uFF0C\u6211\u4EEC\u5E0C\u671B\u5F53\u4F60\u6709\u9700\u8981\u7684\u65F6\u5019\uFF0C\u80FD\u4E00\u773C\u627E\u5230\u4F60\u60F3\u8981\u7684\u5185\u5BB9\u3002\u641C\u85CF\u52A9\u624B\u4E0D\u8981\u6C42\u4F60\u7ED9\u6536\u85CF\u5939\u5206\u7C7B\uFF0C\u53EA\u8981\u76F4\u63A5\u95EE\u4E00\u53E5\uFF0C\u5C31\u80FD\u627E\u5230\u89C6\u9891\u8BB2\u8FC7\u4EC0\u4E48\u3002" }), _jsx("p", { children: "\u5B83\u5148\u4ECE\u4F60\u7684\u8D44\u6599\u5E93\u91CC\u627E\u5230\u76F8\u5173\u539F\u6587\uFF0C\u518D\u7EC4\u7EC7\u7B54\u6848\uFF1B\u627E\u4E0D\u5230\u65F6\u4F1A\u660E\u786E\u8BF4\u660E\uFF0C\u4E0D\u4F1A\u51ED\u6A21\u578B\u8BB0\u5FC6\u8865\u51FA\u4E00\u4E2A\u770B\u4F3C\u5408\u7406\u7684\u7ED3\u8BBA\u3002" })] })] }), _jsxs("div", { className: "showcase-purpose__proofs", "aria-label": "\u9879\u76EE\u539F\u5219", children: [_jsxs("article", { children: [_jsx("span", { children: "01" }), _jsx("h3", { children: "\u72EC\u7ACB\u8D44\u6599\u7A7A\u95F4" }), _jsx("p", { children: "\u6BCF\u4F4D\u7528\u6237\u62E5\u6709\u72EC\u7ACB\u7684\u79C1\u4EBA\u8D44\u6599\u5E93\u3002\u9875\u9762\u5185\u5BB9\u3001\u68C0\u7D22\u7ED3\u679C\u4E0E\u56DE\u7B54\u4F9D\u636E\u90FD\u9650\u5B9A\u5728\u5F53\u524D\u8D26\u6237\u8303\u56F4\u5185\uFF0C\u4E0D\u4E0E\u5176\u4ED6\u7528\u6237\u7684\u6570\u636E\u6DF7\u7528\u3002" })] }), _jsxs("article", { children: [_jsx("span", { children: "02" }), _jsx("h3", { children: "\u57FA\u4E8E\u539F\u6587\u751F\u6210\u56DE\u7B54" }), _jsx("p", { children: "\u7CFB\u7EDF\u5148\u68C0\u7D22\u8D44\u6599\u5E93\u4E2D\u7684\u76F8\u5173\u5B57\u5E55\u7247\u6BB5\uFF0C\u518D\u636E\u6B64\u7EC4\u7EC7\u7B54\u6848\uFF1B\u7F3A\u5C11\u8DB3\u591F\u4F9D\u636E\u65F6\u4F1A\u660E\u786E\u8BF4\u660E\uFF0C\u4E0D\u7528\u6A21\u578B\u8BB0\u5FC6\u8865\u5168\u3002" })] }), _jsxs("article", { children: [_jsx("span", { children: "03" }), _jsx("h3", { children: "\u7B54\u6848\u4F9D\u636E\u5168\u7A0B\u53EF\u8FFD\u6EAF" }), _jsx("p", { children: "\u56DE\u7B54\u4F1A\u540C\u65F6\u5173\u8054\u89C6\u9891\u6807\u9898\u3001\u539F\u6587\u7247\u6BB5\u4E0E\u5BF9\u5E94\u65F6\u95F4\u70B9\uFF0C\u65B9\u4FBF\u968F\u65F6\u8FD4\u56DE\u539F\u89C6\u9891\uFF0C\u6838\u5BF9\u7ED3\u8BBA\u6240\u5728\u7684\u5B8C\u6574\u4E0A\u4E0B\u6587\u3002" })] })] })] }), _jsxs("section", { className: "showcase-section showcase-audience", "aria-labelledby": "audience-title", children: [_jsxs("div", { className: "showcase-section__label", children: [_jsx("span", { children: "02" }), _jsx("p", { children: "WHO IT SERVES" })] }), _jsxs("div", { className: "showcase-audience__heading", children: [_jsx("p", { className: "showcase-overline", children: "\u9002\u7528\u4EBA\u7FA4" }), _jsxs("h2", { id: "audience-title", children: [_jsx("span", { className: "showcase-audience__lead-in", children: "\u4E3A\u4E86\u8BA9\u4F60\u8DF3\u8FC7\u7B49\u5F85\u800C\u8BBE\u8BA1\uFF1A" }), _jsxs("span", { children: ["\u201C\u6211\u597D\u50CF\u770B\u8FC7\u8FD9\u4E2A\u2026\u2026", _jsx("br", {}), "\u6211\u627E\u627E\uFF1F\u201D"] })] })] }), _jsx("div", { className: "showcase-audience__grid", children: audiences.map((audience) => (_jsxs("article", { children: [_jsx(AudienceIcon, { name: audience.icon }), _jsx("h3", { children: audience.title }), _jsx("p", { children: audience.copy })] }, audience.title))) })] }), _jsxs("section", { className: "showcase-section showcase-process", id: "process", "aria-labelledby": "process-title", children: [_jsxs("div", { className: "showcase-section__label showcase-section__label--light", children: [_jsx("span", { children: "03" }), _jsx("p", { children: "HOW IT WORKS" })] }), _jsxs("div", { className: "showcase-process__heading", children: [_jsx("p", { className: "showcase-overline", children: "\u89C6\u9891\u77E5\u8BC6\u5904\u7406\u6D41\u7A0B" }), _jsxs("h2", { id: "process-title", children: ["\u4ECE\u89C6\u9891\u5F52\u6863\uFF0C", _jsx("br", {}), "\u5230\u53EF\u8FFD\u6EAF\u7684\u56DE\u7B54\u3002"] }), _jsx("p", { children: "\u89C6\u9891\u94FE\u63A5\u63D0\u4EA4\u540E\uFF0C\u7CFB\u7EDF\u4F1A\u5728\u540E\u53F0\u63D0\u53D6\u6807\u9898\u3001\u7AE0\u8282\u548C\u5B57\u5E55\uFF0C\u5EFA\u7ACB\u53EF\u68C0\u7D22\u7684\u5185\u5BB9\u7D22\u5F15\uFF1B\u5904\u7406\u671F\u95F4\u4E0D\u5F71\u54CD\u7EE7\u7EED\u804A\u5929\u6216\u6D4F\u89C8\u8D44\u6599\u5E93\u3002" })] }), _jsx("ol", { className: "showcase-process__list", children: processSteps.map((step) => (_jsxs("li", { children: [_jsx("span", { className: "process-index", children: step.index }), _jsxs("div", { children: [_jsx("h3", { children: step.title }), _jsx("p", { children: step.copy })] }), _jsx("code", { children: step.output })] }, step.index))) })] }), _jsxs("section", { className: "showcase-section showcase-demo", id: "demo", "aria-labelledby": "demo-title", children: [_jsxs("div", { className: "showcase-section__label", children: [_jsx("span", { children: "04" }), _jsx("p", { children: "TRY THE FLOW" })] }), _jsxs("div", { className: "showcase-demo__heading", children: [_jsxs("div", { children: [_jsx("p", { className: "showcase-overline", children: "\u771F\u5B9E\u6765\u6E90 \u00B7 \u9884\u8BBE\u8BD5\u7528" }), _jsxs("h2", { id: "demo-title", children: ["\u9009\u4E00\u4E2A\u573A\u666F\uFF0C", _jsx("br", {}), "\u770B\u7B54\u6848\u51FA\u5904\u3002"] })] }), _jsx("p", { children: "\u4E0B\u5217\u7B54\u6848\u662F\u6839\u636E\u516C\u5F00\u5B57\u5E55\u9884\u5148\u6574\u7406\u7684\u4EA4\u4E92\u6F14\u793A\uFF0C\u4E0D\u4F1A\u8C03\u7528\u6A21\u578B\u6216\u4E0A\u4F20\u6570\u636E\u3002\u771F\u5B9E\u4F7F\u7528\u65F6\uFF0C\u6765\u6E90\u4F1A\u66FF\u6362\u6210\u4F60\u81EA\u5DF1\u7684\u8D44\u6599\u5E93\u5185\u5BB9\u3002" })] }), _jsx("div", { className: "demo-selector", "aria-label": "\u9009\u62E9\u8BD5\u7528\u573A\u666F", children: demoScenes.map((scene) => (_jsxs("button", { className: scene.id === activeDemoId ? "is-active" : undefined, type: "button", "aria-pressed": scene.id === activeDemoId, onClick: () => selectDemo(scene.id), children: [_jsx("span", { children: scene.index }), _jsx("strong", { children: scene.audience }), _jsx("small", { children: scene.title })] }, scene.id))) }), _jsxs("div", { className: "demo-workbench", children: [_jsxs("aside", { className: "demo-source-card", children: [_jsxs("div", { className: "demo-source-card__visual", children: [_jsx("img", { src: activeDemo.thumbnailUrl, alt: `当前场景：${activeDemo.sourceTitle} 视频封面`, width: "480", height: "360", decoding: "async" }), _jsxs("div", { className: "demo-subtitle-language", role: "group", "aria-label": "\u7247\u6BB5\u8981\u70B9\u8BED\u8A00", children: [_jsx("button", { type: "button", "aria-label": "\u663E\u793A\u4E2D\u6587\u8981\u70B9", "aria-pressed": summaryLanguage === "zh", onClick: () => setSummaryLanguage("zh"), children: _jsx("span", { "aria-hidden": "true", children: "\u4E2D" }) }), _jsx("button", { type: "button", "aria-label": "\u663E\u793A\u82F1\u6587\u8981\u70B9", "aria-pressed": summaryLanguage === "en", onClick: () => setSummaryLanguage("en"), children: _jsx("span", { "aria-hidden": "true", children: "EN" }) })] }), _jsxs("div", { className: "demo-subtitle-bar", "data-testid": "demo-subtitle-ticker", children: [_jsx("span", { className: "demo-subtitle-bar__mark", "aria-hidden": "true", children: "\u8981\u70B9" }), _jsxs("span", { className: "sr-only", children: ["\u7247\u6BB5\u8981\u70B9\uFF1A", activeSummary] }), _jsx("div", { className: "demo-subtitle-viewport", "aria-hidden": "true", children: _jsxs("div", { className: `demo-subtitle-track demo-subtitle-track--${summaryDuration}`, children: [_jsx("span", { children: activeSummary }), _jsx("span", { children: activeSummary })] }, `${activeDemo.id}-${summaryLanguage}`) })] })] }), _jsxs("div", { className: "demo-source-card__body", children: [_jsx("p", { className: "showcase-overline", children: "\u5DF2\u5BFC\u5165\u6765\u6E90" }), _jsx("h3", { children: activeDemo.sourceTitle }), _jsx("p", { children: activeDemo.sourceCreator }), _jsxs("div", { className: "demo-source-card__status", children: [_jsxs("span", { children: [_jsx("i", {}), " \u5B57\u5E55\u5DF2\u6574\u7406"] }), _jsx("span", { children: "\u5185\u5BB9\u5DF2\u53EF\u67E5\u627E" })] }), _jsxs("a", { href: activeDemo.sourceUrl, target: "_blank", rel: "noreferrer", children: ["\u67E5\u770B\u539F\u89C6\u9891 ", _jsx(ArrowIcon, {})] })] })] }), _jsxs("div", { className: "demo-console", children: [_jsxs("div", { className: "demo-console__bar", children: [_jsx("span", { children: "STASHSEEK CHAT / \u573A\u666F\u8BD5\u7528" }), _jsxs("span", { className: "demo-console__mode", children: [_jsx("i", {}), " \u6765\u6E90\u6838\u5BF9\u6A21\u5F0F"] })] }), _jsxs("div", { className: "demo-question", children: [_jsx("span", { children: "\u4F60\u7684\u95EE\u9898" }), _jsx("p", { children: activeDemo.question })] }), _jsxs("div", { className: "demo-pipeline", "aria-label": "\u9884\u8BBE\u56DE\u7B54\u6F14\u793A\u6B65\u9AA4", children: [_jsx("span", { className: hasRun ? "is-complete" : undefined, children: "01 \u7406\u89E3\u95EE\u9898" }), _jsx("span", { className: hasRun ? "is-complete" : undefined, children: "02 \u67E5\u627E\u76F8\u5173\u7247\u6BB5" }), _jsx("span", { className: hasRun ? "is-complete" : undefined, children: "03 \u6838\u5BF9\u539F\u6587" })] }), !hasRun ? (_jsx("div", { className: "demo-console__ready", children: _jsxs("button", { className: "showcase-button showcase-button--signal", type: "button", onClick: () => setHasRun(true), children: ["\u67E5\u770B\u8FD9\u6B21\u56DE\u7B54 ", _jsx(ArrowIcon, {})] }) })) : (_jsxs("article", { className: "demo-answer", "aria-live": "polite", children: [_jsxs("div", { className: "demo-answer__label", children: [_jsx(BrandLogo, { className: "demo-answer__mark" }), _jsx("p", { children: "\u57FA\u4E8E 3 \u4E2A\u5B57\u5E55\u7247\u6BB5" })] }), _jsx("p", { className: "demo-answer__lead", children: _jsx(TypewriterText, { text: activeDemo.answerLead }) }), _jsx("ol", { children: activeDemo.answerPoints.map((point) => (_jsx("li", { children: _jsx(TypewriterText, { text: point }) }, point))) }), _jsxs("div", { className: "demo-evidence", children: [_jsx("p", { children: "\u53EF\u6838\u5BF9\u8BC1\u636E" }), activeDemo.evidence.map((evidence) => (_jsxs("a", { href: evidence.url, target: "_blank", rel: "noreferrer", children: [_jsx("strong", { children: evidence.label }), _jsx("span", { children: evidence.note }), _jsx(ArrowIcon, {})] }, evidence.url)))] }), _jsx("button", { className: "demo-reset", type: "button", onClick: () => setHasRun(false), children: "\u6536\u8D77\u7B54\u6848" })] }))] })] })] }), _jsxs("section", { className: "showcase-cta", "aria-labelledby": "showcase-cta-title", children: [_jsx("p", { className: "showcase-overline", children: "YOUR KNOWLEDGE / YOUR EVIDENCE" }), _jsxs("h2", { id: "showcase-cta-title", children: ["\u7B54\u6848\u4E0E\u539F\u6587\uFF0C", _jsx("br", {}), "\u4E00\u6B65\u4E4B\u9065"] }), _jsxs(RouteLink, { className: "showcase-button showcase-button--dark", to: "/login", children: ["\u8FDB\u5165\u79C1\u4EBA\u8D44\u6599\u5E93 ", _jsx(ArrowIcon, {})] }), _jsx("p", { className: "showcase-cta__note", children: "\u63D2\u4EF6\u5DE5\u4F5C\u533A\u8D1F\u8D23\u767B\u5F55\u3001\u8D44\u6599\u5E93\u7BA1\u7406\u548C\u5B57\u5E55\u9605\u8BFB\uFF1B\u5E26\u6765\u6E90\u95EE\u7B54\u53D1\u751F\u5728\u5DF2\u542F\u7528\u7684\u804A\u5929\u6216 MCP \u5165\u53E3 \u00B7 \u53EF\u7528\u5165\u53E3\u4EE5\u90E8\u7F72\u914D\u7F6E\u4E3A\u51C6" })] })] }), _jsxs("footer", { className: "showcase-footer", children: [_jsxs(RouteLink, { className: "showcase-brand showcase-brand--footer", to: "/", children: [_jsx(BrandLogo, { className: "showcase-brand__mark" }), _jsx("span", { children: "STASHSEEK / CHAT" })] }), _jsxs("p", { children: [_jsx("span", { children: "Built for EAZO Global Hackathon" }), _jsx("a", { href: "https://beian.miit.gov.cn/", target: "_blank", rel: "noreferrer", children: "\u7CA4ICP\u59072026101890\u53F7-1" })] }), _jsxs("div", { className: "showcase-footer__links", children: [_jsxs("a", { href: "https://github.com/deequoique/stashseek", target: "_blank", rel: "noreferrer", "aria-label": "\u5728 GitHub \u67E5\u770B StashSeek \u6E90\u7801\uFF0C\u6B22\u8FCE\u63D0\u4EA4 Issue \u4E0E PR", children: [_jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "M12 .7a11.5 11.5 0 0 0-3.6 22.4c.6.1.8-.2.8-.5v-2c-3.4.7-4.1-1.4-4.1-1.4-.5-1.4-1.3-1.8-1.3-1.8-1.1-.7.1-.7.1-.7 1.2.1 1.9 1.2 1.9 1.2 1.1 1.9 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.7-.3-5.5-1.4-5.5-6 0-1.3.5-2.4 1.2-3.2-.1-.3-.5-1.5.1-3.2 0 0 1-.3 3.3 1.2a11.3 11.3 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.6 1.7.2 2.9.1 3.2.7.8 1.2 1.9 1.2 3.2 0 4.6-2.8 5.7-5.5 6 .4.4.8 1.1.8 2.2v3.3c0 .3.2.6.8.5A11.5 11.5 0 0 0 12 .7Z" }) }), "GitHub \u00B7 \u6B22\u8FCE\u63D0 Issue / PR"] }), _jsx("a", { href: "#showcase-main", children: "\u56DE\u5230\u9876\u90E8 \u2191" })] })] })] }));
}
