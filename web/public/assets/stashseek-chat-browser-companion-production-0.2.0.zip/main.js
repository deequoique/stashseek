import { jsx as _jsx } from "react/jsx-runtime";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./app/App";
import "./styles.css";
const root = document.getElementById("root");
if (!root)
    throw new Error("Application root is missing");
createRoot(root).render(_jsx(StrictMode, { children: _jsx(App, {}) }));
