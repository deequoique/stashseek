import { jsx as _jsx } from "react/jsx-runtime";
/** Opens the public privacy policy of this build's API origin in a new tab. Renders nothing without a single API origin. */
export function PrivacyLink({ deps }) {
    let href;
    try {
        href = deps.privacyUrl();
    }
    catch {
        return null;
    }
    return _jsx("a", { className: "text-button sp-privacy-link", href: href, target: "_blank", rel: "noopener noreferrer", children: "\u9690\u79C1\u653F\u7B56" });
}
