export class StreamingUnavailableError extends Error {
    code = "streaming_disabled";
    constructor(message = "流式回答当前未启用") {
        super(message);
        this.name = "StreamingUnavailableError";
    }
}
export class ConversationStreamError extends Error {
    code;
    response;
    constructor(code, message, response) {
        super(message);
        this.code = code;
        this.response = response;
        this.name = "ConversationStreamError";
    }
}
export class ApiError extends Error {
    status;
    code;
    constructor(status, code, message) {
        super(message);
        this.status = status;
        this.code = code;
    }
}
let unauthorizedHandler = null;
export function setUnauthorizedHandler(handler) {
    unauthorizedHandler = handler;
}
function cookie(name) {
    const prefix = `${encodeURIComponent(name)}=`;
    const entry = document.cookie
        .split(";")
        .map((value) => value.trim())
        .find((value) => value.startsWith(prefix));
    return entry ? decodeURIComponent(entry.slice(prefix.length)) : null;
}
export async function requestJson(path, init = {}) {
    const headers = new Headers(init.headers);
    if (init.body && !headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
    }
    if (init.method && !["GET", "HEAD", "OPTIONS"].includes(init.method.toUpperCase())) {
        const csrf = cookie("__Host-kb_csrf");
        if (csrf)
            headers.set("X-CSRF-Token", csrf);
    }
    let requestUrl = path;
    if (!/^https?:\/\//.test(path) && typeof chrome !== "undefined" && chrome.storage?.local && globalThis.location?.protocol === "chrome-extension:") {
        const state = await chrome.storage.local.get(["apiOrigin", "accessToken"]);
        const origin = typeof state.apiOrigin === "string" ? state.apiOrigin : "https://stashseek.deequoique.tech";
        requestUrl = `${origin}${path}`;
        if (typeof state.accessToken === "string" && !headers.has("Authorization"))
            headers.set("Authorization", `Bearer ${state.accessToken}`);
    }
    const response = await fetch(requestUrl, {
        ...init,
        headers,
        credentials: "same-origin",
    });
    if (!response.ok) {
        const fallback = { code: "request_failed", message: "请求无法完成" };
        const payload = await response.json().catch(() => fallback);
        const error = new ApiError(response.status, payload.code ?? fallback.code, payload.message ?? fallback.message);
        // Login verification failures are 401s too, but they are recoverable
        // form errors.  Only an invalidated browser session tears down the
        // private query client and redirects to the login route.
        if (response.status === 401 && payload.code === "session_invalid") {
            unauthorizedHandler?.();
        }
        throw error;
    }
    if (response.status === 204)
        return undefined;
    return response.json();
}
export function createLoginChallenge(channel) {
    return requestJson("/api/v1/auth/challenges", {
        method: "POST",
        body: JSON.stringify({ target_channel: channel }),
    });
}
function browserAuthorization(browserSecret) {
    return { Authorization: `Bearer ${browserSecret}` };
}
export function getChallengeStatus(challengeId, browserSecret) {
    return requestJson("/api/v1/auth/challenges/status", {
        method: "POST",
        headers: browserAuthorization(browserSecret),
        body: JSON.stringify({ public_id: challengeId }),
    });
}
export function exchangeChallenge(challengeId, browserSecret) {
    return requestJson("/api/v1/auth/sessions", {
        method: "POST",
        headers: browserAuthorization(browserSecret),
        body: JSON.stringify({ public_id: challengeId }),
    });
}
export function requestEmailChallenge(email) {
    return requestJson("/api/v1/extension/auth/challenge", { method: "POST", body: JSON.stringify({ email }) }).then(async (r) => {
        lastExtensionChallenge = r.challenge_id;
        if (typeof chrome !== "undefined" && chrome.storage?.local)
            await chrome.storage.local.set({ loginChallengeId: r.challenge_id });
        return { status: "accepted", challenge_id: r.challenge_id };
    });
}
let lastExtensionChallenge = null;
export async function verifyEmailChallenge(email, code) {
    let challengeId = lastExtensionChallenge;
    if (!challengeId && typeof chrome !== "undefined" && chrome.storage?.local) {
        const state = await chrome.storage.local.get(["loginChallengeId"]);
        challengeId = typeof state.loginChallengeId === "string" ? state.loginChallengeId : null;
    }
    if (!challengeId)
        throw new Error("challenge_missing");
    const session = await requestJson("/api/v1/extension/auth/verify", { method: "POST", body: JSON.stringify({ challenge_id: challengeId, code }) });
    lastExtensionChallenge = null;
    if (typeof chrome !== "undefined" && chrome.storage?.local && globalThis.location?.protocol === "chrome-extension:") {
        await chrome.storage.local.set({ accessToken: session.access_token, expiresAt: session.expires_at });
        await chrome.storage.local.remove(["loginChallengeId"]);
    }
    return { authenticated: true, login_channel: "email", expires_at: session.expires_at };
}
export function getSession() {
    return requestJson("/api/v1/extension/auth/session").then((session) => ({
        authenticated: true, login_channel: "email", expires_at: session.expires_at ?? "",
    }));
}
export async function logout() {
    try {
        if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage && globalThis.location?.protocol === "chrome-extension:") {
            await chrome.runtime.sendMessage({ type: "DISCONNECT" });
        }
        else {
            await requestJson("/api/v1/extension/auth/logout", { method: "POST" });
        }
    }
    finally {
        if (typeof chrome !== "undefined" && chrome.storage?.local) {
            await chrome.storage.local.remove(["accessToken", "captureToken", "expiresAt", "user", "tenant", "deviceId", "pairingId", "pairingVerifier", "loginChallengeId"]);
        }
    }
}
export function createTelegramLinkToken() {
    const input = { target_channel: "telegram" };
    return requestJson("/api/v1/link-tokens", {
        method: "POST",
        body: JSON.stringify(input),
    });
}
export function consumeLinkToken(token) {
    const input = { token };
    return requestJson("/api/v1/link-tokens/consume", {
        method: "POST",
        body: JSON.stringify(input),
    });
}
export function approveBrowserCompanionPairing(pairingId) {
    return requestJson(`/api/v1/browser-companion/pairings/${encodeURIComponent(pairingId)}:approve`, { method: "POST" });
}
export function listBrowserCompanionDevices() {
    return requestJson("/api/v1/browser-companion/devices");
}
export function revokeBrowserCompanionDevice(deviceId) {
    return requestJson(`/api/v1/browser-companion/devices/${encodeURIComponent(deviceId)}`, { method: "DELETE" });
}
export function getCapabilities() {
    return requestJson("/api/v1/capabilities");
}
export function listConversations(cursor) {
    const params = new URLSearchParams({ limit: "30" });
    if (cursor)
        params.set("cursor", cursor);
    return requestJson(`/api/v1/conversations?${params.toString()}`);
}
export function getConversationTurns(threadId) {
    return requestJson(`/api/v1/conversations/${encodeURIComponent(threadId)}/turns`);
}
export function deleteConversation(threadId) {
    return requestJson(`/api/v1/conversations/${encodeURIComponent(threadId)}`, {
        method: "DELETE",
    });
}
export function sendConversationMessage(conversationId, input) {
    return requestJson(`/api/v1/conversations/${encodeURIComponent(conversationId)}/messages`, {
        method: "POST",
        body: JSON.stringify(input),
    });
}
function streamErrorPayload(response) {
    return response.json().catch(() => ({
        code: "request_failed",
        message: "请求无法完成",
    }));
}
const STREAM_EVENT_TYPES = new Set([
    "started",
    "activity",
    "step_started",
    "step_completed",
    "plan_updated",
    "section_started",
    "text_delta",
    "section_completed",
    "section_aborted",
    "completed",
    "error",
    "cancelled",
]);
const STREAM_STEP_CODES = new Set([
    "updating_plan",
    "searching_library",
    "reading_context",
    "checking_source",
    "reviewing_library",
    "checking_item",
    "handling_save",
    "managing_library",
    "working",
]);
const STREAM_STEP_OUTCOMES = new Set(["completed", "failed", "skipped"]);
const STREAM_ACTIVITY_VALUES = new Set([
    "preparing",
    "retrieving",
    "planning_answer",
    "composing",
    "completed",
    "failed",
    "cancelled",
]);
const STREAM_EVENT_KEYS = new Set([
    "type",
    "request_id",
    "message_id",
    "sequence",
    "activity",
    "step_id",
    "step_code",
    "step_outcome",
    "result_count",
    "plan",
    "text",
    "response",
    "error_code",
    "message",
    "section_id",
    "status",
    "citation_ids",
    "citations",
    "reason",
]);
function isPlanItem(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value))
        return false;
    const item = value;
    return Object.keys(value).every((key) => ["id", "title", "status"].includes(key))
        && typeof item.id === "string"
        && /^[A-Za-z0-9][A-Za-z0-9_-]{0,31}$/.test(item.id)
        && typeof item.title === "string"
        && item.title.trim().length > 0
        && item.title.length <= 120
        && typeof item.status === "string"
        && ["pending", "in_progress", "completed", "blocked"].includes(item.status);
}
function isConversationResponse(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value))
        return false;
    const response = value;
    return (typeof response.status === "string"
        && ["ok", "not_found", "failed"].includes(response.status)
        && typeof response.text === "string"
        && Array.isArray(response.citations)
        && Array.isArray(response.action_results)
        && (response.thread_id === undefined
            || response.thread_id === null
            || typeof response.thread_id === "string")
        && (response.error_code === undefined
            || response.error_code === null
            || typeof response.error_code === "string"));
}
function isStreamEvent(value) {
    if (typeof value !== "object" || value === null)
        return false;
    const event = value;
    return (Object.keys(value).every((key) => STREAM_EVENT_KEYS.has(key))
        && typeof event.request_id === "string"
        && event.request_id.length > 0
        && event.request_id.length <= 64
        && typeof event.message_id === "string"
        && event.message_id.length > 0
        && event.message_id.length <= 128
        && typeof event.sequence === "number"
        && Number.isInteger(event.sequence)
        && event.sequence >= 1
        && typeof event.type === "string"
        && STREAM_EVENT_TYPES.has(event.type)
        && (event.activity === undefined
            || event.activity === null
            || (typeof event.activity === "string" && STREAM_ACTIVITY_VALUES.has(event.activity)))
        && (event.step_id === undefined
            || event.step_id === null
            || (typeof event.step_id === "string" && event.step_id.length > 0 && event.step_id.length <= 64))
        && (event.step_code === undefined
            || event.step_code === null
            || (typeof event.step_code === "string" && STREAM_STEP_CODES.has(event.step_code)))
        && (event.step_outcome === undefined
            || event.step_outcome === null
            || (typeof event.step_outcome === "string" && STREAM_STEP_OUTCOMES.has(event.step_outcome)))
        && (event.result_count === undefined
            || event.result_count === null
            || (typeof event.result_count === "number"
                && Number.isInteger(event.result_count)
                && event.result_count >= 0
                && event.result_count <= 10_000))
        && (event.plan === undefined
            || event.plan === null
            || (Array.isArray(event.plan) && event.plan.length <= 6 && event.plan.every(isPlanItem)))
        && (event.text === undefined || event.text === null || typeof event.text === "string")
        && (event.message === undefined || event.message === null || typeof event.message === "string")
        && (event.section_id === undefined
            || event.section_id === null
            || (typeof event.section_id === "string" && event.section_id.length > 0 && event.section_id.length <= 64))
        && (event.status === undefined
            || event.status === null
            || event.status === "grounded"
            || event.status === "unsupported")
        && (event.citation_ids === undefined
            || (Array.isArray(event.citation_ids)
                && event.citation_ids.every((id) => typeof id === "number" && Number.isInteger(id) && id > 0)))
        && (event.citations === undefined
            || (Array.isArray(event.citations)
                && event.citations.every((citation) => isConversationCitation(citation))))
        && (event.reason === undefined
            || event.reason === null
            || ["provider_failure", "timeout", "cancelled"].includes(event.reason))
        && (event.response === undefined || event.response === null || isConversationResponse(event.response)));
}
function isConversationCitation(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value))
        return false;
    const citation = value;
    return typeof citation.title === "string"
        && typeof citation.excerpt === "string"
        && typeof citation.url === "string"
        && (citation.start_sec === undefined || citation.start_sec === null || typeof citation.start_sec === "number");
}
function isAbortError(error) {
    return typeof error === "object"
        && error !== null
        && error.name === "AbortError";
}
function parseSseRecord(record) {
    const data = [];
    for (const line of record.replace(/\r/g, "").split("\n")) {
        if (!line || line.startsWith(":"))
            continue;
        const separator = line.indexOf(":");
        const field = separator === -1 ? line : line.slice(0, separator);
        const value = separator === -1 ? "" : line.slice(separator + 1).replace(/^ /, "");
        if (field === "data")
            data.push(value);
    }
    if (!data.length)
        return null;
    return JSON.parse(data.join("\n"));
}
async function openConversationStream(path, body, signal) {
    const headers = new Headers({
        Accept: "text/event-stream",
        "Content-Type": "application/json",
    });
    const csrf = cookie("__Host-kb_csrf");
    if (csrf)
        headers.set("X-CSRF-Token", csrf);
    let streamUrl = path;
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
        const state = await chrome.storage.local.get(["apiOrigin", "accessToken"]);
        streamUrl = `${typeof state.apiOrigin === "string" ? state.apiOrigin : "https://stashseek.deequoique.tech"}${path}`;
        if (typeof state.accessToken === "string")
            headers.set("Authorization", `Bearer ${state.accessToken}`);
    }
    let response;
    try {
        response = await fetch(streamUrl, {
            method: "POST",
            headers,
            body: JSON.stringify(body),
            credentials: "same-origin",
            signal,
        });
    }
    catch (error) {
        if (isAbortError(error)) {
            throw new ConversationStreamError("cancelled", "请求已取消");
        }
        throw error;
    }
    if (!response.ok) {
        const payload = await streamErrorPayload(response);
        if (response.status === 401 && payload.code === "session_invalid") {
            unauthorizedHandler?.();
        }
        throw new ApiError(response.status, payload.code, payload.message);
    }
    return response;
}
/**
 * Consume the browser SSE contract with strict correlation/sequence checks.
 * Repeated sequence numbers are idempotently ignored; a missing or future
 * sequence fails closed so a partial answer is never silently misassembled.
 * Shared by the library conversation stream and the side-panel page Q&A
 * stream so the lifecycle validation lives in exactly one place.
 */
async function consumeConversationStream(response, messageId, onEvent) {
    if (!response.body)
        throw new ConversationStreamError("stream_unavailable", "流式连接不可用");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let requestId = null;
    let lastSequence = 0;
    let completed = null;
    let terminal = false;
    let started = false;
    let openSectionId = null;
    let sectionLifecycleSeen = false;
    let sectionAborted = false;
    let openStepId = null;
    let openStepCode = null;
    const stepIds = new Set();
    const sectionIds = new Set();
    const citationIds = new Set();
    const sectionStatuses = new Map();
    let readerDone = false;
    const acceptRecord = (record) => {
        const raw = parseSseRecord(record);
        if (raw === null)
            return;
        if (terminal) {
            throw new ConversationStreamError("stream_protocol_error", "流式终态后出现了额外事件");
        }
        if (!isStreamEvent(raw))
            throw new ConversationStreamError("stream_protocol_error", "流式响应格式无效");
        if (requestId === null)
            requestId = raw.request_id;
        if (raw.request_id !== requestId)
            throw new ConversationStreamError("stream_protocol_error", "流式响应标识不一致");
        if (raw.message_id !== messageId)
            throw new ConversationStreamError("stream_protocol_error", "流式消息标识不一致");
        if (raw.sequence <= lastSequence)
            return;
        if (raw.sequence !== lastSequence + 1)
            throw new ConversationStreamError("stream_protocol_error", "流式响应顺序无效");
        if (!started) {
            if (raw.type !== "started" || raw.sequence !== 1) {
                throw new ConversationStreamError("stream_protocol_error", "流式响应缺少开始事件");
            }
            started = true;
        }
        else if (raw.type === "started") {
            throw new ConversationStreamError("stream_protocol_error", "流式响应重复开始");
        }
        if (raw.type === "text_delta" && typeof raw.text !== "string") {
            throw new ConversationStreamError("stream_protocol_error", "流式文本增量无效");
        }
        const sectionId = raw.section_id ?? null;
        const ids = raw.citation_ids ?? [];
        const sources = raw.citations ?? [];
        const hasStepPayload = raw.step_id !== undefined && raw.step_id !== null
            || raw.step_code !== undefined && raw.step_code !== null
            || raw.step_outcome !== undefined && raw.step_outcome !== null
            || raw.result_count !== undefined && raw.result_count !== null;
        if (raw.type === "step_started") {
            if (!raw.step_id
                || !raw.step_code
                || openStepId !== null
                || openSectionId !== null
                || stepIds.has(raw.step_id)
                || raw.step_outcome !== undefined && raw.step_outcome !== null
                || raw.result_count !== undefined && raw.result_count !== null
                || raw.plan !== undefined && raw.plan !== null) {
                throw new ConversationStreamError("stream_protocol_error", "流式步骤开始事件无效");
            }
            openStepId = raw.step_id;
            openStepCode = raw.step_code;
            stepIds.add(raw.step_id);
        }
        else if (raw.type === "step_completed") {
            if (!raw.step_id
                || !raw.step_code
                || !raw.step_outcome
                || raw.step_id !== openStepId
                || raw.step_code !== openStepCode
                || raw.plan !== undefined && raw.plan !== null) {
                throw new ConversationStreamError("stream_protocol_error", "流式步骤完成事件无效");
            }
            openStepId = null;
            openStepCode = null;
        }
        else if (raw.type === "plan_updated") {
            if (!Array.isArray(raw.plan) || hasStepPayload || openStepId !== null || openSectionId !== null) {
                throw new ConversationStreamError("stream_protocol_error", "流式计划事件无效");
            }
            const planIds = raw.plan.map((item) => item.id);
            if (new Set(planIds).size !== planIds.length) {
                throw new ConversationStreamError("stream_protocol_error", "流式计划包含重复步骤");
            }
        }
        else if (hasStepPayload || raw.plan !== undefined && raw.plan !== null) {
            throw new ConversationStreamError("stream_protocol_error", "流式事件携带了越界步骤数据");
        }
        else if (raw.type === "section_started") {
            if (!sectionId || !raw.status || openStepId !== null || openSectionId !== null || sectionIds.has(sectionId)) {
                throw new ConversationStreamError("stream_protocol_error", "流式分段开始事件无效");
            }
            if (raw.status === "grounded" && ids.length === 0) {
                throw new ConversationStreamError("stream_protocol_error", "流式分段缺少来源");
            }
            if (raw.status === "unsupported" && ids.length > 0) {
                throw new ConversationStreamError("stream_protocol_error", "证据不足分段不得携带来源");
            }
            if (new Set(ids).size !== ids.length || sources.length !== ids.length) {
                throw new ConversationStreamError("stream_protocol_error", "流式分段来源无效");
            }
            if (ids.some((id) => citationIds.has(id))) {
                throw new ConversationStreamError("stream_protocol_error", "流式分段重复来源");
            }
            sectionLifecycleSeen = true;
            openSectionId = sectionId;
            sectionIds.add(sectionId);
            sectionStatuses.set(sectionId, raw.status);
            ids.forEach((id) => citationIds.add(id));
        }
        else if (raw.type === "text_delta") {
            if (sectionLifecycleSeen) {
                if (!sectionId || sectionId !== openSectionId) {
                    throw new ConversationStreamError("stream_protocol_error", "流式文本分段标识无效");
                }
            }
            else if (sectionId !== null) {
                throw new ConversationStreamError("stream_protocol_error", "流式文本缺少分段开始事件");
            }
        }
        else if (raw.type === "section_completed") {
            if (!sectionLifecycleSeen
                || !sectionId
                || sectionId !== openSectionId
                || raw.status === undefined
                || raw.status === null
                || raw.status !== sectionStatuses.get(sectionId)) {
                throw new ConversationStreamError("stream_protocol_error", "流式分段完成事件无效");
            }
            openSectionId = null;
        }
        else if (raw.type === "section_aborted") {
            if (!sectionLifecycleSeen
                || !sectionId
                || sectionId !== openSectionId
                || !raw.reason) {
                throw new ConversationStreamError("stream_protocol_error", "流式分段中断事件无效");
            }
            openSectionId = null;
            sectionAborted = true;
        }
        else if (raw.type === "completed" || raw.type === "error" || raw.type === "cancelled") {
            if (openStepId !== null || openSectionId !== null) {
                throw new ConversationStreamError("stream_protocol_error", "流式响应仍有未完成步骤");
            }
            if (raw.type === "completed" && sectionAborted) {
                throw new ConversationStreamError("stream_protocol_error", "中断的流式响应不得成功完成");
            }
        }
        lastSequence = raw.sequence;
        if (raw.type === "completed") {
            const completedResponse = raw.response;
            if (!isConversationResponse(completedResponse)) {
                throw new ConversationStreamError("stream_protocol_error", "流式响应缺少最终答案");
            }
            completed = completedResponse;
            terminal = true;
        }
        else if (raw.type === "error" || raw.type === "cancelled") {
            terminal = true;
            onEvent?.(raw);
            throw new ConversationStreamError(raw.error_code ?? (raw.type === "cancelled" ? "cancelled" : "request_failed"), raw.message ?? (raw.type === "cancelled" ? "请求已取消" : "请求无法完成"), raw.response ?? undefined);
        }
        onEvent?.(raw);
    };
    try {
        while (!terminal) {
            const { done, value } = await reader.read();
            if (done) {
                readerDone = true;
                break;
            }
            buffer += decoder.decode(value, { stream: true });
            let boundary = buffer.search(/\r?\n\r?\n/);
            while (boundary >= 0) {
                const match = buffer.match(/\r?\n\r?\n/);
                if (!match || match.index === undefined)
                    break;
                acceptRecord(buffer.slice(0, match.index));
                buffer = buffer.slice(match.index + match[0].length);
                boundary = buffer.search(/\r?\n\r?\n/);
            }
        }
        buffer += decoder.decode();
        if (buffer.trim())
            acceptRecord(buffer);
    }
    catch (error) {
        if (isAbortError(error)) {
            throw new ConversationStreamError("cancelled", "请求已取消");
        }
        throw error;
    }
    finally {
        if (!readerDone) {
            await reader.cancel().catch(() => undefined);
        }
        reader.releaseLock();
    }
    if (!completed)
        throw new ConversationStreamError("stream_protocol_error", "流式响应未正常结束");
    return completed;
}
/** Streams one library conversation message over SSE. */
export async function streamConversationMessage(conversationId, input, onEvent, signal) {
    let response;
    try {
        response = await openConversationStream(`/api/v1/conversations/${encodeURIComponent(conversationId)}/messages/stream`, input, signal);
    }
    catch (error) {
        if (error instanceof ApiError
            && (error.code === "streaming_disabled" || error.status === 404 || error.status === 406 || error.status === 415)) {
            throw new StreamingUnavailableError(error.message);
        }
        throw error;
    }
    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().includes("text/event-stream")) {
        // An older compatible server may answer this negotiation path with the
        // ordinary projection. It is safe to accept because no second submission
        // is made and the JSON route remains the canonical fallback.
        const projection = await response.json();
        if (!isConversationResponse(projection)) {
            throw new ConversationStreamError("stream_protocol_error", "流式响应格式无效");
        }
        return projection;
    }
    return consumeConversationStream(response, input.message_id, onEvent);
}
/**
 * Streams one question about the page the user is looking at. Nothing is
 * ingested server-side. Resolves with the final projection; a server `error`
 * event or a protocol violation rejects with `ConversationStreamError`, an
 * HTTP failure (401, 413, 422, 429, ...) with `ApiError`.
 */
export async function streamPageQuestion(conversationId, body, handlers = {}, signal) {
    const response = await openConversationStream(`/api/v1/page-qa/conversations/${encodeURIComponent(conversationId)}/messages/stream`, body, signal);
    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().includes("text/event-stream")) {
        await response.body?.cancel().catch(() => undefined);
        throw new ConversationStreamError("stream_protocol_error", "流式响应格式无效");
    }
    return consumeConversationStream(response, body.message_id, (event) => {
        handlers.onEvent?.(event);
        if (event.type === "text_delta" && event.text)
            handlers.onTextDelta?.(event.text);
    });
}
export function resetConversation(conversationId) {
    return requestJson(`/api/v1/conversations/${encodeURIComponent(conversationId)}/reset`, {
        method: "POST",
    });
}
export function listLibraryItems(query) {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([key, value]) => {
        if (value !== undefined && value !== "" && value !== false)
            params.set(key, String(value));
    });
    const suffix = params.size ? `?${params.toString()}` : "";
    return requestJson(`/api/v1/library/items${suffix}`);
}
export function getLibraryItem(publicId) {
    return requestJson(`/api/v1/library/items/${encodeURIComponent(publicId)}`);
}
export function getTranscript(publicId, cursor) {
    const params = new URLSearchParams({ limit: "50" });
    if (cursor)
        params.set("cursor", cursor);
    return requestJson(`/api/v1/library/items/${encodeURIComponent(publicId)}/transcript?${params.toString()}`);
}
export function updateWhySaved(publicId, whySaved) {
    return requestJson(`/api/v1/library/items/${encodeURIComponent(publicId)}`, {
        method: "PATCH",
        body: JSON.stringify({ why_saved: whySaved }),
    });
}
export function archiveItem(publicId) {
    return requestJson(`/api/v1/library/items/${encodeURIComponent(publicId)}:archive`, { method: "POST" });
}
export function restoreItem(publicId) {
    return requestJson(`/api/v1/library/items/${encodeURIComponent(publicId)}:restore`, { method: "POST" });
}
export function retryItem(publicId) {
    return requestJson(`/api/v1/library/items/${encodeURIComponent(publicId)}:retry`, {
        method: "POST",
        headers: { "Idempotency-Key": crypto.randomUUID() },
    });
}
export function submitVideoBatch(input) {
    return requestJson("/api/v1/library/items:batch", {
        method: "POST",
        headers: { "Idempotency-Key": crypto.randomUUID() },
        body: JSON.stringify(input),
    });
}
