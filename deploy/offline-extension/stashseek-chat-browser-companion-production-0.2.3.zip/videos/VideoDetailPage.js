import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation, useParams } from "react-router";
import { ApiError, archiveItem, getLibraryItem, getTranscript, restoreItem, retryItem, updateWhySaved, } from "../api/client";
import { TITLE_SEARCH_ROUTE } from "../ingest/ingestCopy";
import { LibraryErrorState, LibraryLoadingState } from "../library/LibraryStates";
import { RouteLink, useRouteNavigate } from "../app/RouteTransition";
import { VideoDetailView } from "./VideoDetailView";
export function VideoDetailPage() {
    const { id = "" } = useParams();
    const location = useLocation();
    const queryClient = useQueryClient();
    const navigate = useRouteNavigate();
    const item = useQuery({
        queryKey: ["library-item", id],
        queryFn: () => getLibraryItem(id),
        enabled: Boolean(id),
        refetchInterval: (state) => {
            const lifecycle = state.state.data?.lifecycle;
            return lifecycle === "queued" || lifecycle === "processing" ? 4_000 : false;
        },
    });
    const transcript = useInfiniteQuery({
        queryKey: ["transcript", id],
        queryFn: ({ pageParam }) => getTranscript(id, pageParam),
        initialPageParam: null,
        getNextPageParam: (lastPage) => lastPage.next_cursor ?? undefined,
        enabled: item.data?.lifecycle === "ready",
        // The transcript is read from object storage after the library item has
        // already reached `ready`. A short object-store/network hiccup should not
        // strand the detail page in the error state; deterministic contract
        // failures (invalid data, a stale cursor, or an unavailable transcript)
        // still stop after this small bounded retry budget.
        retry: (failureCount, error) => error instanceof ApiError &&
            error.code === "transcript_unavailable" &&
            failureCount < 2,
        retryDelay: (attemptIndex) => Math.min(1_000 * 2 ** attemptIndex, 3_000),
    });
    const action = useMutation({
        mutationFn: async (input) => {
            if (input.type === "archive")
                return archiveItem(id);
            if (input.type === "restore")
                return restoreItem(id);
            if (input.type === "retry")
                return retryItem(id);
            return updateWhySaved(id, input.value ?? null);
        },
        onSuccess: (nextItem) => {
            queryClient.setQueryData(["library-item", id], nextItem);
            void queryClient.invalidateQueries({ queryKey: ["library"] });
        },
    });
    return (_jsxs(_Fragment, { children: [_jsx(RouteLink, { className: "back-link", to: "/library", children: "\u2190 \u8FD4\u56DE\u8D44\u6599\u5E93" }), item.isPending ? _jsx(LibraryLoadingState, { label: "\u6B63\u5728\u52A0\u8F7D\u89C6\u9891\u8BE6\u60C5" }) : null, item.isError ? (_jsx(LibraryErrorState, { onRetry: () => void item.refetch(), title: "\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u89C6\u9891\u8BE6\u60C5", description: "\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u65B0\u52A0\u8F7D\u3002" })) : null, item.data ? (_jsx(VideoDetailView, { item: item.data, initiallyEditSavedContext: location.hash === "#saved-context", transcriptPages: transcript.data?.pages ?? [], transcriptPending: transcript.isFetchingNextPage, transcriptInitialPending: transcript.isPending && item.data.lifecycle === "ready", transcriptError: transcript.isError, actionPending: action.isPending, actionError: action.isError, actionQuotaExceeded: action.error instanceof ApiError && action.error.status === 429, onLoadMore: () => void transcript.fetchNextPage(), onRetryTranscript: () => void transcript.refetch(), onArchive: () => action.mutate({ type: "archive" }), onRestore: () => action.mutate({ type: "restore" }), onRetry: () => action.mutate({ type: "retry" }), onSearchTitles: () => navigate(TITLE_SEARCH_ROUTE), onUpdateWhySaved: async (value) => {
                    await action.mutateAsync({ type: "why", value });
                } })) : null] }));
}
