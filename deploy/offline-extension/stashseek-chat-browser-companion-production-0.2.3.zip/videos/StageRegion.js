import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { isKnownStageKey, STAGE_LABEL, STAGE_PLACEHOLDER } from "../ingest/ingestCopy";
import { BODY_KEY } from "../ingest/ingestModel";
/**
 * The region of one stage that follows the body on the detail page. The body is already searchable
 * by then, so a stage that failed only shows its placeholder; it never marks the item unusable.
 */
export function StageRegion({ stage, children }) {
    const titleId = useId();
    if (!isKnownStageKey(stage.key) || stage.key === BODY_KEY)
        return null;
    const waiting = stage.status === "pending" || stage.status === "running";
    const content = waiting
        ? _jsx("p", { className: "muted", "aria-live": "polite", children: "\u6574\u7406\u4E2D\u2026" })
        : stage.status === "done" && children ? children : _jsx("p", { className: "description-copy", children: STAGE_PLACEHOLDER[stage.key] });
    return (_jsxs("section", { className: "detail-section stage-region", "aria-labelledby": titleId, "data-stage": stage.key, "data-status": stage.status, children: [_jsx("p", { className: "eyebrow", children: "AI \u6574\u7406" }), _jsx("h2", { id: titleId, children: STAGE_LABEL[stage.key] }), content] }));
}
