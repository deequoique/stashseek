import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext } from "react";
import Markdown from "react-markdown";
import { CitationChip, remarkCitationChips } from "./citationChips";
const NO_CITATIONS = [];
const CitationsContext = createContext({ citations: NO_CITATIONS, hidden: false });
const remarkPlugins = [remarkCitationChips];
/** The raw marker number the remark plugin attached, or null for an ordinary link. */
function citationMarker(props) {
    const raw = props["data-cite"];
    return typeof raw === "string" || typeof raw === "number" ? String(raw) : null;
}
function MarkdownLink({ marker, children }) {
    const { citations, hidden } = useContext(CitationsContext);
    // Model-authored links stay inert text; only a server-numbered marker that
    // resolves to a real citation becomes a link.
    if (marker === null)
        return _jsx("span", { children: children });
    const ordinal = Number(marker);
    const citation = Number.isInteger(ordinal) && ordinal >= 1 ? citations[ordinal - 1] : undefined;
    return citation
        ? _jsx(CitationChip, { ordinal: ordinal, citation: citation, hidden: hidden })
        : _jsx("span", { children: `[^${marker}]` });
}
// Module-level and stable on purpose: an inline `components` object gives
// react-markdown a new component type per render, which would remount every
// chip on each streamed delta and drop keyboard focus or an open tooltip.
const components = {
    a: ({ children, ...props }) => _jsx(MarkdownLink, { marker: citationMarker(props), children: children }),
    img: ({ alt }) => _jsx("span", { children: alt ?? "" }),
};
export function MarkdownAnswer({ children, citations = NO_CITATIONS, citesHidden = false }) {
    return (_jsx(CitationsContext.Provider, { value: { citations, hidden: citesHidden }, children: _jsx("div", { className: "chat-markdown", children: _jsx(Markdown, { remarkPlugins: remarkPlugins, components: components, children: children }) }) }));
}
