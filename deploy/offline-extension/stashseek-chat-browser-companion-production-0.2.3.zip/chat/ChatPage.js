import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { flushSync } from "react-dom";
import { ConversationStreamError, deleteConversation, resetConversation, sendConversationMessage, StreamingUnavailableError, } from "../api/client";
import { ApiError } from "../api/client";
import { RouteLink } from "../app/RouteTransition";
import { ExecutionTimeline, executionStepCopy, } from "./ExecutionTimeline";
import { assistantTextWithoutSourceList } from "./answerText";
import { MarkdownAnswer } from "./MarkdownAnswer";
import { CitationToggle, UnreferencedChips } from "./citationChips";
import { capabilitiesQueryOptions, conversationHistoryQueryOptions, conversationTurnsQueryOptions } from "./conversationQueries";
function sendErrorMessage(error) {
    if (error instanceof ApiError && error.status === 504) {
        return "回答生成超时，请重新发送。";
    }
    return "请求未能完成。请检查网络后重新发送。";
}
const PENDING_CITE_KEY = "pending";
function displayTime(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "" : date.toLocaleDateString("zh-CN", {
        month: "short", day: "numeric",
    });
}
function markdownPreviewText(text) {
    return text
        .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
        .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
        .replace(/^\s{0,3}(?:#{1,6}\s+|>\s?|[-+*]\s+|\d+[.)]\s+)/gm, "")
        .replace(/\*\*([^*]+)\*\*/g, "$1")
        .replace(/__([^_]+)__/g, "$1")
        .replace(/~~([^~]+)~~/g, "$1")
        .replace(/`([^`]+)`/g, "$1")
        .replace(/\s*\[(?:S|\^)\d+\]/g, "")
        .replace(/\s+/g, " ")
        .trim();
}
export function durablePendingTurnIndex(transcript, question, answer, baselineTurnCount) {
    if (!question)
        return null;
    const turns = transcript?.turns ?? [];
    for (let index = baselineTurnCount; index < turns.length; index += 1) {
        const turn = turns[index];
        if (!turn)
            continue;
        if (turn.user_text === question
            && (turn.assistant_text === answer
                || (answer.length > 0
                    && turn.assistant_text.startsWith(`${answer}\n\n来源：\n`))))
            return index;
    }
    return null;
}
const fallbackQuestions = [
    "这个观点在哪个视频的什么位置？",
    "这些视频对这个问题有哪些直接依据？",
    "请列出相关片段和可跳转的时间点。",
];
const ACTIVITY_COPY = {
    preparing: "正在准备回答…",
    retrieving: "正在检索资料库…",
    planning_answer: "正在规划回答依据…",
    composing: "正在整理答案…",
    completed: "回答已完成",
    failed: "这次检索未能完成",
    cancelled: "请求已取消",
};
function activityCopy(event) {
    return event.activity ? (ACTIVITY_COPY[event.activity] ?? "正在处理…") : "正在处理…";
}
export function ChatPage({ loadCapabilities, fetchHistory, fetchTurns, reset = resetConversation, send = sendConversationMessage, sendStream, deleteThread = deleteConversation, createId = () => crypto.randomUUID(), }) {
    const queryClient = useQueryClient();
    const [selectedThreadId, setSelectedThreadId] = useState(null);
    const [selectedConversationId, setSelectedConversationId] = useState(null);
    const [draft, setDraft] = useState("");
    const [pendingQuestion, setPendingQuestion] = useState(null);
    const [pendingActivity, setPendingActivity] = useState("正在准备回答…");
    const [pendingAnswer, setPendingAnswer] = useState("");
    const [pendingCitations, setPendingCitations] = useState([]);
    const [pendingSections, setPendingSections] = useState([]);
    const [pendingExecutionSteps, setPendingExecutionSteps] = useState([]);
    const [pendingPlan, setPendingPlan] = useState([]);
    const [pendingSyncError, setPendingSyncError] = useState(false);
    const [pendingStatus, setPendingStatus] = useState("streaming");
    const [openMenuThreadId, setOpenMenuThreadId] = useState(null);
    const [confirmingThreadId, setConfirmingThreadId] = useState(null);
    const [positionedTurn, setPositionedTurn] = useState(null);
    const [historyOpenIntent, setHistoryOpenIntent] = useState(null);
    // Answers whose inline citation chips the reader collapsed, keyed per turn.
    const [hiddenCiteKeys, setHiddenCiteKeys] = useState(() => new Set());
    const attemptedEmptyBootstrap = useRef(false);
    const pendingQuestionRef = useRef(null);
    const pendingAnswerRef = useRef("");
    const pendingThreadIdRef = useRef(null);
    const pendingBaselineTurnCountRef = useRef(0);
    const menuRef = useRef(null);
    const transcriptRef = useRef(null);
    const questionRef = useRef(null);
    const keepQuestionAlignedRef = useRef(false);
    const scrollPositionRef = useRef({ transcript: 0, page: 0 });
    const capabilities = useQuery(capabilitiesQueryOptions(loadCapabilities));
    const chatEnabled = capabilities.data?.chat === true;
    const history = useQuery({
        ...conversationHistoryQueryOptions(fetchHistory),
        enabled: chatEnabled,
    });
    const transcript = useQuery({
        ...conversationTurnsQueryOptions(selectedThreadId, fetchTurns),
        enabled: chatEnabled && selectedThreadId !== null,
    });
    const newConversation = useMutation({
        mutationFn: async () => {
            const conversationId = createId();
            const response = await reset(conversationId);
            if (!response.thread_id)
                throw new Error("服务器未返回新会话。");
            return { conversationId, response };
        },
        onSuccess: ({ conversationId, response }) => {
            setSelectedThreadId(response.thread_id);
            // A reset response has the public thread ID but not the browser
            // conversation ID. Keep the ID generated for this request so an empty
            // history can accept a question before the sidebar refresh completes.
            setSelectedConversationId(conversationId);
            queryClient.setQueryData(["conversation", response.thread_id], {
                thread_id: response.thread_id,
                conversation_id: conversationId,
                turns: [],
            });
            queryClient.setQueryData(["conversations"], (current) => {
                if (!current)
                    return current;
                const item = {
                    thread_id: response.thread_id,
                    conversation_id: conversationId,
                    title: "新的检索",
                    preview: "",
                    updated_at: new Date().toISOString(),
                };
                return {
                    ...current,
                    items: [item, ...(current.items ?? []).filter((entry) => entry.thread_id !== item.thread_id)],
                };
            });
            // The sidebar is eventually canonical; its latency must not keep the
            // reset mutation pending or disable the composer.
            void queryClient.invalidateQueries({ queryKey: ["conversations"] });
        },
    });
    const sendMessage = useMutation({
        mutationFn: async ({ conversationId, text }) => {
            const input = { message_id: createId(), text };
            if (!sendStream)
                return send(conversationId, input);
            try {
                return await sendStream(conversationId, input, (event) => {
                    // A fetch reader can deliver multiple complete SSE records in one
                    // microtask. Flush each public event at the boundary so activity
                    // and the first safe delta are paintable before the terminal
                    // response, instead of being collapsed into one React batch.
                    flushSync(() => {
                        if (event.type === "started" || event.type === "activity") {
                            setPendingActivity(activityCopy(event));
                        }
                        else if (event.type === "step_started" && event.step_id && event.step_code) {
                            const step = {
                                stepId: event.step_id,
                                code: event.step_code,
                                outcome: "running",
                            };
                            setPendingExecutionSteps((current) => [...current, step]);
                            setPendingActivity(executionStepCopy(step));
                        }
                        else if (event.type === "step_completed"
                            && event.step_id
                            && event.step_code
                            && event.step_outcome) {
                            const completed = {
                                stepId: event.step_id,
                                code: event.step_code,
                                outcome: event.step_outcome,
                                ...(event.result_count === null || event.result_count === undefined
                                    ? {}
                                    : { resultCount: event.result_count }),
                            };
                            setPendingExecutionSteps((current) => current.map((step) => (step.stepId === completed.stepId ? completed : step)));
                            setPendingActivity(executionStepCopy(completed));
                        }
                        else if (event.type === "plan_updated" && event.plan) {
                            setPendingPlan(event.plan);
                        }
                        else if (event.type === "section_started" && event.section_id) {
                            setPendingSections((current) => [
                                ...current.filter((section) => section.sectionId !== event.section_id),
                                {
                                    sectionId: event.section_id,
                                    status: event.status ?? "grounded",
                                    text: "",
                                    citations: event.citations ?? [],
                                    phase: "streaming",
                                },
                            ]);
                            setPendingActivity(event.status === "unsupported" ? "正在标记证据不足部分…" : "正在整理答案…");
                        }
                        else if (event.type === "text_delta") {
                            setPendingActivity("正在整理答案…");
                            if (event.text && event.section_id) {
                                setPendingSections((current) => current.map((section) => (section.sectionId === event.section_id
                                    ? { ...section, text: section.text + event.text }
                                    : section)));
                            }
                            else if (event.text) {
                                setPendingAnswer((current) => current + event.text);
                            }
                        }
                        else if (event.type === "section_completed" && event.section_id) {
                            setPendingSections((current) => current.map((section) => (section.sectionId === event.section_id
                                ? { ...section, phase: "completed" }
                                : section)));
                        }
                        else if (event.type === "section_aborted" && event.section_id) {
                            setPendingSections((current) => current.filter((section) => section.sectionId !== event.section_id));
                        }
                        else if (event.type === "completed") {
                            setPendingActivity("回答已完成");
                            setPendingSections([]);
                            if (event.response) {
                                setPendingAnswer(event.response.text);
                                pendingAnswerRef.current = event.response.text;
                                setPendingCitations(event.response.citations ?? []);
                            }
                        }
                        else if (event.type === "error" || event.type === "cancelled") {
                            setPendingStatus("failed");
                            setPendingActivity(activityCopy(event));
                            setPendingAnswer(event.response?.text
                                || (event.type === "cancelled" ? "请求已取消。" : "请求未能完成，请稍后重试。"));
                            setPendingSections([]);
                        }
                    });
                });
            }
            catch (error) {
                // A known server without SSE support is the only safe automatic
                // fallback. A broken stream may already have persisted this message,
                // so it remains a visible failed turn instead of being resubmitted.
                if (error instanceof StreamingUnavailableError) {
                    setPendingActivity("正在检索资料库…");
                    setPendingAnswer("");
                    return send(conversationId, input);
                }
                throw error;
            }
        },
        onSuccess: async (response) => {
            setDraft("");
            // Keep the terminal SSE projection mounted until the selected transcript
            // has installed the durable turn. This prevents a blank frame between
            // the stream terminal event and the refetched history.
            setPendingAnswer(response.text);
            pendingAnswerRef.current = response.text;
            setPendingCitations(response.citations ?? []);
            setPendingSyncError(false);
            void queryClient.invalidateQueries({ queryKey: ["conversations"] });
            const pendingThreadId = pendingThreadIdRef.current ?? selectedThreadId;
            if (!pendingThreadId)
                return;
            try {
                await queryClient.refetchQueries({
                    queryKey: ["conversation", pendingThreadId],
                    exact: true,
                    type: "all",
                });
                const latest = queryClient.getQueryData(["conversation", pendingThreadId]);
                const durableIndex = durablePendingTurnIndex(latest, pendingQuestionRef.current, response.text, pendingBaselineTurnCountRef.current);
                if (durableIndex === null) {
                    setPendingSyncError(true);
                    return;
                }
                const durableTurn = latest?.turns?.[durableIndex];
                if (durableTurn)
                    adoptPendingCitationState(`${durableTurn.created_at}:${durableTurn.user_text}`);
                if (durableTurn && pendingThreadId === selectedThreadId) {
                    // Another tab may have appended turns; anchor this exact turn.
                    setPositionedTurn({
                        ...questionPosition(pendingThreadId, durableIndex),
                        turnKey: `${durableTurn.created_at}:${durableTurn.user_text}`,
                    });
                }
                setPendingQuestion(null);
                pendingQuestionRef.current = null;
                setPendingAnswer("");
                pendingAnswerRef.current = "";
                pendingThreadIdRef.current = null;
                setPendingCitations([]);
                setPendingSections([]);
                setPendingExecutionSteps([]);
                setPendingPlan([]);
                setPendingActivity("正在准备回答…");
                setPendingStatus("streaming");
            }
            catch {
                setPendingSyncError(true);
            }
        },
        onError: (error) => {
            if (error instanceof ConversationStreamError) {
                setPendingStatus("failed");
                setPendingSections([]);
                setPendingCitations([]);
                setPendingExecutionSteps((current) => current.map((step) => (step.outcome === "running" ? { ...step, outcome: "failed" } : step)));
                setPendingActivity(error.code === "cancelled"
                    ? "请求已取消"
                    : error.response
                        ? "这次检索未能完成"
                        : "流式连接中断，请重试");
                if (error.response?.text) {
                    setPendingAnswer(error.response.text);
                    pendingAnswerRef.current = error.response.text;
                }
                return;
            }
            setPendingQuestion(null);
            if (pendingThreadIdRef.current === selectedThreadId) {
                keepQuestionAlignedRef.current = false;
                setPositionedTurn(null);
            }
            pendingQuestionRef.current = null;
            setPendingAnswer("");
            pendingAnswerRef.current = "";
            pendingThreadIdRef.current = null;
            setPendingCitations([]);
            setPendingSections([]);
            setPendingExecutionSteps([]);
            setPendingPlan([]);
            setPendingSyncError(false);
            setPendingStatus("failed");
        },
    });
    // The collapse choice made on the streamed answer follows it into history.
    function adoptPendingCitationState(turnKey) {
        setHiddenCiteKeys((current) => {
            if (!current.has(PENDING_CITE_KEY))
                return current;
            const next = new Set(current);
            next.delete(PENDING_CITE_KEY);
            next.add(turnKey);
            return next;
        });
    }
    async function retryPendingSync() {
        const pendingThreadId = pendingThreadIdRef.current;
        if (!pendingThreadId)
            return;
        setPendingSyncError(false);
        try {
            await queryClient.refetchQueries({
                queryKey: ["conversation", pendingThreadId],
                exact: true,
                type: "all",
            });
            const latest = queryClient.getQueryData(["conversation", pendingThreadId]);
            const question = pendingQuestionRef.current;
            const answer = pendingAnswerRef.current;
            const durableIndex = durablePendingTurnIndex(latest, question, answer, pendingBaselineTurnCountRef.current);
            if (durableIndex === null) {
                setPendingSyncError(true);
                return;
            }
            const durableTurn = latest?.turns?.[durableIndex];
            if (durableTurn)
                adoptPendingCitationState(`${durableTurn.created_at}:${durableTurn.user_text}`);
            if (durableTurn && pendingThreadId === selectedThreadId) {
                setPositionedTurn({
                    ...questionPosition(pendingThreadId, durableIndex),
                    turnKey: `${durableTurn.created_at}:${durableTurn.user_text}`,
                });
            }
            pendingQuestionRef.current = null;
            pendingAnswerRef.current = "";
            pendingThreadIdRef.current = null;
            setPendingQuestion(null);
            setPendingAnswer("");
            setPendingCitations([]);
            setPendingSections([]);
            setPendingExecutionSteps([]);
            setPendingPlan([]);
            setPendingActivity("正在准备回答…");
            setPendingStatus("streaming");
        }
        catch {
            setPendingSyncError(true);
        }
    }
    const deleteConversationMutation = useMutation({
        mutationFn: async (threadId) => {
            await deleteThread(threadId);
            return threadId;
        },
        onSuccess: async (deletedThreadId) => {
            queryClient.setQueryData(["conversations"], (current) => {
                if (!current)
                    return current;
                return {
                    ...current,
                    items: (current.items ?? []).filter((item) => item.thread_id !== deletedThreadId),
                };
            });
            setSelectedThreadId(null);
            setSelectedConversationId(null);
            setPendingQuestion(null);
            pendingQuestionRef.current = null;
            setPendingAnswer("");
            pendingAnswerRef.current = "";
            pendingThreadIdRef.current = null;
            setPendingCitations([]);
            setPendingSections([]);
            setPendingActivity("正在准备回答…");
            setPendingExecutionSteps([]);
            setPendingPlan([]);
            setPendingStatus("streaming");
            await queryClient.invalidateQueries({ queryKey: ["conversations"] });
        },
    });
    useEffect(() => {
        // Page threads are read-only; open on the newest library conversation.
        const latest = history.data?.items?.find((item) => item.page_qa !== true);
        if (!chatEnabled || !latest || selectedThreadId || newConversation.isPending)
            return;
        setHistoryOpenIntent({ threadId: latest.thread_id });
        setSelectedThreadId(latest.thread_id);
        setSelectedConversationId(latest.conversation_id);
    }, [chatEnabled, history.data, selectedThreadId, newConversation.isPending]);
    useEffect(() => {
        if (!chatEnabled
            || !history.data
            || (history.data.items ?? []).some((item) => item.page_qa !== true)
            || selectedThreadId
            || newConversation.isPending
            || attemptedEmptyBootstrap.current)
            return;
        attemptedEmptyBootstrap.current = true;
        newConversation.mutate();
    }, [chatEnabled, history.data, newConversation, selectedThreadId]);
    useEffect(() => {
        if (!selectedThreadId || selectedConversationId || !history.data)
            return;
        const item = history.data.items?.find((entry) => entry.thread_id === selectedThreadId);
        if (item)
            setSelectedConversationId(item.conversation_id);
    }, [history.data, selectedConversationId, selectedThreadId]);
    useEffect(() => {
        if (!openMenuThreadId)
            return;
        function closeMenu(event) {
            if (!menuRef.current?.contains(event.target)) {
                setOpenMenuThreadId(null);
                setConfirmingThreadId(null);
            }
        }
        function closeOnEscape(event) {
            if (event.key === "Escape") {
                setOpenMenuThreadId(null);
                setConfirmingThreadId(null);
            }
        }
        document.addEventListener("pointerdown", closeMenu);
        document.addEventListener("keydown", closeOnEscape);
        return () => {
            document.removeEventListener("pointerdown", closeMenu);
            document.removeEventListener("keydown", closeOnEscape);
        };
    }, [openMenuThreadId]);
    function selectConversation(threadId, conversationId) {
        if (pendingQuestion && pendingThreadIdRef.current === threadId) {
            keepQuestionAlignedRef.current = true;
            setPositionedTurn({ ...questionPosition(threadId, pendingBaselineTurnCountRef.current), turnKey: null });
            setHistoryOpenIntent(null);
        }
        else {
            keepQuestionAlignedRef.current = false;
            setPositionedTurn(null);
            setHistoryOpenIntent({ threadId });
        }
        setSelectedThreadId(threadId);
        setSelectedConversationId(conversationId);
    }
    function startNewConversation() {
        if (!chatEnabled)
            return;
        keepQuestionAlignedRef.current = false;
        setPositionedTurn(null);
        setHistoryOpenIntent(null);
        setDraft("");
        setPendingQuestion(null);
        pendingQuestionRef.current = null;
        setPendingAnswer("");
        pendingAnswerRef.current = "";
        pendingThreadIdRef.current = null;
        setPendingCitations([]);
        setPendingSections([]);
        setPendingExecutionSteps([]);
        setPendingPlan([]);
        setPendingSyncError(false);
        setPendingActivity("正在准备回答…");
        setPendingStatus("streaming");
        setSelectedThreadId(null);
        setSelectedConversationId(null);
        newConversation.mutate();
    }
    const touchInput = useState(() => (typeof window !== "undefined"
        && (window.matchMedia?.("(pointer: coarse)").matches === true
            || navigator.maxTouchPoints > 0)))[0];
    const composerRef = useRef(null);
    useEffect(() => {
        const element = composerRef.current;
        if (!element)
            return;
        element.style.height = "auto";
        element.style.height = `${Math.min(element.scrollHeight, 160)}px`;
    }, [draft]);
    const composerDisabled = !selectedConversationId
        || transcript.isPending
        || sendMessage.isPending
        || newConversation.isPending;
    function isPositionedTurn(turnIndex, turn) {
        if (!positionedTurn || positionedTurn.threadId !== selectedThreadId)
            return false;
        if (positionedTurn.turnKey) {
            return positionedTurn.turnKey === `${turn.created_at}:${turn.user_text}`;
        }
        return !visiblePendingQuestion && positionedTurn.index === turnIndex;
    }
    function questionPosition(threadId, index) {
        const transcriptElement = transcriptRef.current;
        const transcriptStyle = transcriptElement ? window.getComputedStyle(transcriptElement) : null;
        const transcriptPadding = (Number.parseFloat(transcriptStyle?.paddingTop ?? "") || 0)
            + (Number.parseFloat(transcriptStyle?.paddingBottom ?? "") || 0);
        return {
            threadId,
            index,
            minHeight: Math.max(0, (transcriptElement?.clientHeight ?? 0) - transcriptPadding),
        };
    }
    function submit(event) {
        event.preventDefault();
        const text = draft.trim();
        if (!text || !selectedConversationId || !selectedThreadId
            || composerDisabled || selectedIsPageThread)
            return;
        setHistoryOpenIntent(null);
        keepQuestionAlignedRef.current = true;
        setPendingQuestion(text);
        pendingQuestionRef.current = text;
        pendingThreadIdRef.current = selectedThreadId;
        pendingBaselineTurnCountRef.current = (queryClient.getQueryData(["conversation", selectedThreadId])?.turns?.length
            ?? 0);
        setPositionedTurn({ ...questionPosition(selectedThreadId, pendingBaselineTurnCountRef.current), turnKey: null });
        setPendingAnswer("");
        pendingAnswerRef.current = "";
        setPendingCitations([]);
        setPendingSections([]);
        setPendingExecutionSteps([]);
        setPendingPlan([]);
        setPendingSyncError(false);
        setPendingActivity("正在准备回答…");
        setPendingStatus("streaming");
        setHiddenCiteKeys((current) => {
            if (!current.has(PENDING_CITE_KEY))
                return current;
            const next = new Set(current);
            next.delete(PENDING_CITE_KEY);
            return next;
        });
        sendMessage.mutate({ conversationId: selectedConversationId, text });
    }
    function toggleCitations(key) {
        setHiddenCiteKeys((current) => {
            const next = new Set(current);
            if (!next.delete(key))
                next.add(key);
            return next;
        });
    }
    function deleteSelectedConversation(threadId) {
        if (deleteConversationMutation.isPending)
            return;
        keepQuestionAlignedRef.current = false;
        setPositionedTurn(null);
        setHistoryOpenIntent(null);
        setOpenMenuThreadId(null);
        setConfirmingThreadId(null);
        deleteConversationMutation.mutate(threadId);
    }
    const turns = transcript.data?.turns ?? [];
    const visiblePendingQuestion = pendingThreadIdRef.current === selectedThreadId ? pendingQuestion : null;
    const historyItems = history.data?.items ?? [];
    // A page-Q&A thread belongs to the video page it was asked on: read-only here.
    const selectedIsPageThread = transcript.data?.page_qa === true
        || historyItems.find((item) => item.thread_id === selectedThreadId)?.page_qa === true;
    // Streamed sections announce disjoint citation lists; the server numbers
    // markers over their concatenation, which the terminal response repeats.
    const pendingAllCitations = pendingSections.length > 0
        ? pendingSections.flatMap((section) => section.citations)
        : pendingCitations;
    const pendingCitesHidden = hiddenCiteKeys.has(PENDING_CITE_KEY);
    const pendingAnswerText = assistantTextWithoutSourceList(pendingAnswer, pendingAllCitations.length > 0);
    const pageThreadLink = turns.flatMap((turn) => turn.citations ?? []).find((citation) => citation.url)?.url;
    const suggestedQuestions = Array.from(new Set([
        ...historyItems
            .filter((item) => item.thread_id !== selectedThreadId && item.title !== "新的检索")
            .map((item) => item.title.trim())
            .filter(Boolean),
        ...fallbackQuestions,
    ])).slice(0, 3);
    const conversationBusy = capabilities.isPending
        || newConversation.isPending
        || sendMessage.isPending
        || (selectedThreadId !== null && transcript.isPending);
    useEffect(() => {
        // The chat layout fills the viewport without relying on CSS :has(), which
        // older engines used by embedded browsers may not support.
        const root = document.documentElement;
        root.classList.add("chat-route");
        document.body.classList.add("chat-route");
        return () => {
            root.classList.remove("chat-route");
            document.body.classList.remove("chat-route");
        };
    }, []);
    useEffect(() => {
        function onPageScroll() {
            const top = Math.max(0, window.scrollY);
            if (Math.abs(top - scrollPositionRef.current.page) > 1)
                keepQuestionAlignedRef.current = false;
            scrollPositionRef.current.page = top;
        }
        window.addEventListener("scroll", onPageScroll, { passive: true });
        return () => window.removeEventListener("scroll", onPageScroll);
    }, []);
    useLayoutEffect(() => {
        if (!historyOpenIntent || historyOpenIntent.threadId !== selectedThreadId || !transcript.isSuccess)
            return;
        setHistoryOpenIntent(null);
        const lastTurnIndex = (transcript.data.turns?.length ?? 0) - 1;
        if (lastTurnIndex < 0)
            return;
        const lastTurn = transcript.data.turns?.[lastTurnIndex];
        keepQuestionAlignedRef.current = true;
        setPositionedTurn({
            ...questionPosition(historyOpenIntent.threadId, lastTurnIndex),
            turnKey: lastTurn ? `${lastTurn.created_at}:${lastTurn.user_text}` : null,
        });
    }, [historyOpenIntent, selectedThreadId, transcript.isSuccess, transcript.data]);
    useLayoutEffect(() => {
        if (!positionedTurn || !keepQuestionAlignedRef.current)
            return;
        // Align on an explicit history open, submission, or durable handoff.
        // Refetches and answer deltas leave the reader's chosen position in place.
        questionRef.current?.scrollIntoView?.({ behavior: "instant", block: "start", inline: "nearest" });
        scrollPositionRef.current = {
            transcript: transcriptRef.current?.scrollTop ?? 0,
            page: Math.max(0, window.scrollY),
        };
    }, [positionedTurn, visiblePendingQuestion]);
    return (_jsxs("section", { className: "chat-page", "aria-labelledby": "chat-title", children: [_jsxs("header", { className: "chat-heading", children: [_jsxs("div", { className: "chat-heading__copy", children: [_jsx(RouteLink, { className: "chat-back-link", to: "/library", children: "\u2190 \u8FD4\u56DE\u8D44\u6599\u5E93" }), _jsx("p", { className: "eyebrow", children: "\u8D44\u6599\u5E93\u68C0\u7D22" }), _jsx("h1", { id: "chat-title", children: "AI \u667A\u80FD\u68C0\u7D22" }), _jsx("p", { children: "\u4ECE\u5DF2\u4FDD\u5B58\u7684\u89C6\u9891\u4E2D\u67E5\u627E\u7B54\u6848\uFF0C\u5E76\u8FD4\u56DE\u53EF\u8DF3\u8F6C\u7684\u539F\u89C6\u9891\u4F9D\u636E\u3002" })] }), _jsxs("div", { className: "chat-scope", "aria-label": "\u68C0\u7D22\u8303\u56F4", children: [_jsxs("span", { children: [_jsx("i", { "aria-hidden": "true" }), "\u5F53\u524D\u8D44\u6599\u5E93"] }), _jsx("strong", { children: "\u4EC5\u4F9D\u636E\u5DF2\u4FDD\u5B58\u89C6\u9891" }), _jsx("small", { children: "\u56DE\u7B54\u9644\u5E26\u539F\u89C6\u9891\u4E0E\u65F6\u95F4\u70B9" })] })] }), _jsxs("div", { className: "chat-layout", children: [_jsx("aside", { className: "chat-sidebar", "aria-label": "\u5386\u53F2\u5BF9\u8BDD", children: _jsxs("div", { id: "chat-history", children: [_jsxs("div", { className: "chat-sidebar__heading", children: [_jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "\u5386\u53F2\u68C0\u7D22" }), _jsx("span", { children: historyItems.length > 0 ? `最近 ${historyItems.length} 段` : "当前账户" })] }), _jsx("button", { className: "chat-new-thread", type: "button", "aria-label": "\u65B0\u5EFA\u68C0\u7D22", disabled: !chatEnabled || newConversation.isPending, onClick: startNewConversation, children: capabilities.isPending || newConversation.isPending ? "…" : "+" })] }), _jsxs("div", { className: "chat-history-scroll", role: "region", "aria-label": "\u5386\u53F2\u68C0\u7D22\u5217\u8868", tabIndex: 0, children: [capabilities.isPending ? _jsx("p", { className: "chat-sidebar__status", "aria-live": "polite", children: "\u6B63\u5728\u786E\u8BA4\u68C0\u7D22\u80FD\u529B\u2026" }) : null, capabilities.isError ? _jsxs("div", { className: "chat-sidebar__status", children: [_jsx("p", { children: "\u65E0\u6CD5\u786E\u8BA4\u68C0\u7D22\u670D\u52A1\u72B6\u6001\u3002" }), _jsx("button", { className: "text-button", type: "button", onClick: () => void capabilities.refetch(), children: "\u91CD\u8BD5" })] }) : null, capabilities.isSuccess && !chatEnabled ? _jsx("p", { className: "chat-sidebar__status", children: "\u5F53\u524D\u90E8\u7F72\u672A\u5F00\u653E AI \u68C0\u7D22\u3002" }) : null, newConversation.isError ? _jsx("p", { className: "chat-error", role: "alert", children: "\u65E0\u6CD5\u65B0\u5EFA\u5BF9\u8BDD\uFF0C\u8BF7\u91CD\u8BD5\u3002" }) : null, deleteConversationMutation.isError ? _jsx("p", { className: "chat-error", role: "alert", children: "\u5220\u9664\u4F1A\u8BDD\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002" }) : null, chatEnabled && history.isPending ? _jsx("p", { className: "chat-sidebar__status", "aria-live": "polite", children: "\u6B63\u5728\u52A0\u8F7D\u5386\u53F2\u5BF9\u8BDD\u2026" }) : null, history.isError ? _jsxs("div", { className: "chat-sidebar__status", children: [_jsx("p", { children: "\u5386\u53F2\u5BF9\u8BDD\u52A0\u8F7D\u5931\u8D25\u3002" }), _jsx("button", { className: "text-button", type: "button", onClick: () => void history.refetch(), children: "\u91CD\u8BD5" })] }) : null, history.isSuccess && historyItems.length === 0 && !newConversation.isPending && !newConversation.isError ? _jsx("p", { className: "chat-sidebar__status", children: "\u6682\u65E0\u5386\u53F2\u5BF9\u8BDD\u3002" }) : null, historyItems.length > 0 ? (_jsx("nav", { "aria-label": "\u9009\u62E9\u5386\u53F2\u5BF9\u8BDD", children: _jsx("ol", { className: "chat-thread-list", children: historyItems.map((item) => (_jsxs("li", { className: `chat-thread-row${item.thread_id === selectedThreadId ? " chat-thread-row--selected" : ""}`, children: [_jsxs("button", { className: `chat-thread-select${item.thread_id === selectedThreadId ? " is-selected" : ""}`, type: "button", "aria-current": item.thread_id === selectedThreadId ? "page" : undefined, onClick: () => selectConversation(item.thread_id, item.conversation_id), children: [_jsxs("strong", { children: [item.title, item.page_qa === true ? _jsx("span", { className: "chat-thread-badge", children: "\u89C6\u9891\u9875" }) : null] }), item.preview ? _jsx("span", { children: markdownPreviewText(item.preview) }) : null, _jsx("time", { dateTime: item.updated_at, children: displayTime(item.updated_at) })] }), _jsxs("div", { className: "chat-thread-menu", ref: openMenuThreadId === item.thread_id ? menuRef : undefined, children: [_jsx("button", { className: "chat-thread-menu__trigger", type: "button", "aria-label": `“${item.title}”的更多操作`, "aria-expanded": openMenuThreadId === item.thread_id, onClick: () => {
                                                                        const opening = openMenuThreadId !== item.thread_id;
                                                                        setOpenMenuThreadId(opening ? item.thread_id : null);
                                                                        setConfirmingThreadId(null);
                                                                    }, children: "\u2022\u2022\u2022" }), openMenuThreadId === item.thread_id ? (_jsx("div", { className: "chat-thread-menu__panel", children: confirmingThreadId === item.thread_id ? (_jsxs("div", { className: "chat-thread-menu__confirm", role: "alertdialog", "aria-label": "\u786E\u8BA4\u5220\u9664\u4F1A\u8BDD", children: [_jsx("p", { children: "\u5220\u9664\u8FD9\u6BB5\u5BF9\u8BDD\uFF1F" }), _jsxs("div", { children: [_jsx("button", { className: "chat-thread-menu__cancel", type: "button", onClick: () => setConfirmingThreadId(null), children: "\u53D6\u6D88" }), _jsx("button", { className: "chat-thread-menu__delete", type: "button", disabled: deleteConversationMutation.isPending, onClick: () => deleteSelectedConversation(item.thread_id), children: "\u786E\u5B9A\u5220\u9664" })] })] })) : (_jsx("button", { className: "chat-thread-menu__delete", type: "button", disabled: deleteConversationMutation.isPending, onClick: () => setConfirmingThreadId(item.thread_id), children: "\u5220\u9664\u4F1A\u8BDD" })) })) : null] })] }, item.thread_id))) }) })) : null] })] }) }), _jsxs("div", { className: "chat-conversation", "aria-busy": conversationBusy, children: [_jsxs("div", { className: "chat-transcript", role: "region", "aria-label": "\u5BF9\u8BDD\u5185\u5BB9\u6EDA\u52A8\u533A\u57DF", tabIndex: 0, ref: transcriptRef, onScroll: (event) => {
                                    const top = Math.max(0, event.currentTarget.scrollTop);
                                    if (Math.abs(top - scrollPositionRef.current.transcript) > 1)
                                        keepQuestionAlignedRef.current = false;
                                    scrollPositionRef.current.transcript = top;
                                }, children: [capabilities.isPending ? _jsxs("div", { className: "chat-empty-stage chat-empty-stage--loading", "aria-live": "polite", children: [_jsx("span", { className: "chat-search-line", "aria-hidden": "true" }), _jsx("p", { children: "\u6B63\u5728\u786E\u8BA4\u8D44\u6599\u5E93\u68C0\u7D22\u80FD\u529B\u2026" })] }) : null, capabilities.isError ? _jsxs("div", { className: "chat-empty-stage", role: "alert", children: [_jsx("p", { className: "eyebrow", children: "\u68C0\u7D22\u6682\u65F6\u4E0D\u53EF\u7528" }), _jsx("h2", { children: "\u65E0\u6CD5\u786E\u8BA4\u5F53\u524D\u670D\u52A1\u80FD\u529B" }), _jsx("p", { children: "\u8BF7\u91CD\u8BD5\uFF1B\u5DF2\u7ECF\u4FDD\u5B58\u7684\u89C6\u9891\u4E0D\u4F1A\u53D7\u5230\u5F71\u54CD\u3002" })] }) : null, capabilities.isSuccess && !chatEnabled ? _jsxs("div", { className: "chat-empty-stage", role: "status", children: [_jsx("p", { className: "eyebrow", children: "\u5F53\u524D\u90E8\u7F72" }), _jsx("h2", { children: "\u5C1A\u672A\u5F00\u653E AI \u667A\u80FD\u68C0\u7D22" }), _jsx("p", { children: "\u4F60\u4ECD\u53EF\u8FD4\u56DE\u8D44\u6599\u5E93\u9605\u8BFB\u89C6\u9891\u548C\u5B57\u5E55\u3002" })] }) : null, (selectedThreadId && transcript.isPending) || newConversation.isPending ? _jsxs("div", { className: "chat-empty-stage chat-empty-stage--loading", "aria-live": "polite", children: [_jsx("span", { className: "chat-search-line", "aria-hidden": "true" }), _jsx("p", { children: "\u6B63\u5728\u51C6\u5907\u68C0\u7D22\u5DE5\u4F5C\u533A\u2026" })] }) : null, transcript.isError ? _jsxs("div", { className: "chat-empty", role: "alert", children: [_jsx("p", { children: "\u65E0\u6CD5\u52A0\u8F7D\u8FD9\u6BB5\u5BF9\u8BDD\u3002" }), _jsx("button", { className: "text-button", type: "button", onClick: () => void transcript.refetch(), children: "\u91CD\u8BD5" })] }) : null, !selectedThreadId && history.isError ? _jsxs("div", { className: "chat-empty-stage", role: "alert", children: [_jsx("p", { className: "eyebrow", children: "\u68C0\u7D22\u6682\u65F6\u4E0D\u53EF\u7528" }), _jsx("h2", { children: "\u65E0\u6CD5\u8FDE\u63A5\u5230\u8D44\u6599\u5E93\u68C0\u7D22\u670D\u52A1" }), _jsx("p", { children: "\u8BF7\u7A0D\u540E\u91CD\u8BD5\u5386\u53F2\u8BB0\u5F55\uFF0C\u5DF2\u7ECF\u4FDD\u5B58\u7684\u89C6\u9891\u4E0D\u4F1A\u53D7\u5230\u5F71\u54CD\u3002" })] }) : null, chatEnabled && !transcript.isPending && !transcript.isError && selectedThreadId && turns.length === 0 ? (_jsxs("div", { className: "chat-empty-stage", children: [_jsx("p", { className: "eyebrow", children: "\u4ECE\u4E00\u4E2A\u5177\u4F53\u95EE\u9898\u5F00\u59CB" }), _jsx("h2", { children: "\u4F60\u60F3\u4ECE\u8FD9\u4E9B\u89C6\u9891\u91CC\u627E\u56DE\u4EC0\u4E48\uFF1F" }), _jsx("p", { children: "\u95EE\u9898\u8D8A\u5177\u4F53\uFF0C\u8D8A\u5BB9\u6613\u5B9A\u4F4D\u5230\u5BF9\u5E94\u89C6\u9891\u7247\u6BB5\u548C\u65F6\u95F4\u70B9\u3002" }), _jsx("div", { className: "chat-suggestions", "aria-label": "\u793A\u4F8B\u95EE\u9898", children: suggestedQuestions.map((question, index) => (_jsxs("button", { type: "button", onClick: () => setDraft(question), children: [_jsx("span", { children: String(index + 1).padStart(2, "0") }), question] }, question))) })] })) : null, _jsxs("ol", { className: "chat-turns", "aria-label": "\u5BF9\u8BDD\u5185\u5BB9", children: [turns.map((turn, turnIndex) => {
                                                const turnKey = `${turn.created_at}:${turn.user_text}`;
                                                const turnCitations = turn.citations ?? [];
                                                const answerText = assistantTextWithoutSourceList(turn.assistant_text, turnCitations.length > 0);
                                                const citesHidden = hiddenCiteKeys.has(turnKey);
                                                return (_jsxs("li", { className: `chat-turn${isPositionedTurn(turnIndex, turn) ? " chat-turn--current" : ""}`, style: isPositionedTurn(turnIndex, turn) ? { minHeight: positionedTurn?.minHeight } : undefined, children: [_jsxs("article", { className: "chat-message chat-message--user", ref: isPositionedTurn(turnIndex, turn) ? questionRef : undefined, children: [_jsxs("header", { children: [_jsxs("p", { className: "eyebrow", children: ["\u95EE\u9898 ", String(turnIndex + 1).padStart(2, "0")] }), _jsx("time", { dateTime: turn.created_at, children: displayTime(turn.created_at) })] }), _jsx("p", { className: "chat-question-text", children: turn.user_text })] }), _jsxs("article", { className: `chat-message chat-message--assistant chat-message--${turn.status}`, "data-cites-hidden": citesHidden ? "true" : undefined, children: [_jsxs("header", { className: "chat-answer-heading", children: [_jsxs("p", { className: "eyebrow", children: [_jsx("i", { "aria-hidden": "true" }), selectedIsPageThread ? "视频页回答" : "资料库回答"] }), turnCitations.length > 0 ? (_jsx(CitationToggle, { count: turnCitations.length, hidden: citesHidden, onToggle: () => toggleCitations(turnKey) })) : null] }), turn.status === "not_found" ? _jsx("p", { className: "chat-answer-state", children: "\u6CA1\u6709\u5728\u5F53\u524D\u8D44\u6599\u5E93\u4E2D\u627E\u5230\u8DB3\u591F\u4F9D\u636E\u3002" }) : null, turn.status === "failed" ? _jsx("p", { className: "chat-answer-state", children: "\u8FD9\u6B21\u68C0\u7D22\u672A\u80FD\u5B8C\u6210\u3002" }) : null, _jsx(MarkdownAnswer, { citations: turnCitations, citesHidden: citesHidden, children: answerText }), _jsx(UnreferencedChips, { citations: turnCitations, text: answerText, hidden: citesHidden })] })] }, turnKey));
                                            }), visiblePendingQuestion ? (_jsxs("li", { className: `chat-turn${positionedTurn?.threadId === selectedThreadId && !positionedTurn.turnKey ? " chat-turn--current" : ""}`, style: positionedTurn?.threadId === selectedThreadId && !positionedTurn.turnKey ? { minHeight: positionedTurn.minHeight } : undefined, children: [_jsxs("article", { className: "chat-message chat-message--user", ref: questionRef, children: [_jsx("p", { className: "eyebrow", children: "\u4F60\u7684\u95EE\u9898" }), _jsx("p", { children: pendingQuestion })] }), _jsxs("article", { className: `chat-message chat-message--assistant chat-message--${pendingStatus}`, "data-cites-hidden": pendingCitesHidden ? "true" : undefined, children: [pendingAllCitations.length > 0 ? (_jsxs("header", { className: "chat-answer-heading", children: [_jsx("p", { className: "eyebrow", children: "\u8D44\u6599\u5E93\u52A9\u624B" }), _jsx(CitationToggle, { count: pendingAllCitations.length, hidden: pendingCitesHidden, onToggle: () => toggleCitations(PENDING_CITE_KEY) })] })) : _jsx("p", { className: "eyebrow", children: "\u8D44\u6599\u5E93\u52A9\u624B" }), _jsx("p", { "aria-live": "polite", role: pendingStatus === "failed" ? "alert" : "status", children: pendingActivity }), _jsx(ExecutionTimeline, { steps: pendingExecutionSteps, plan: pendingPlan, answerStarted: pendingSections.length > 0 || Boolean(pendingAnswer) }), pendingSections.map((section) => (_jsx("section", { className: "chat-pending-section", "aria-label": section.status === "unsupported" ? "证据不足部分" : "正在生成回答部分", children: _jsx(MarkdownAnswer, { citations: pendingAllCitations, citesHidden: pendingCitesHidden, children: section.text }) }, section.sectionId))), pendingAnswer ? _jsx(MarkdownAnswer, { citations: pendingAllCitations, citesHidden: pendingCitesHidden, children: pendingAnswerText }) : null, pendingAnswer ? _jsx(UnreferencedChips, { citations: pendingAllCitations, text: pendingAnswerText, hidden: pendingCitesHidden }) : null] })] })) : null] }), pendingSyncError ? (_jsxs("p", { className: "chat-error", role: "alert", children: ["\u56DE\u7B54\u5DF2\u751F\u6210\uFF0C\u4F46\u5BF9\u8BDD\u8BB0\u5F55\u540C\u6B65\u8F83\u6162\uFF0C\u5F53\u524D\u7B54\u6848\u4ECD\u4F1A\u4FDD\u7559\u3002", _jsx("button", { className: "text-button", type: "button", onClick: () => void retryPendingSync(), children: "\u91CD\u8BD5\u540C\u6B65" })] })) : null, sendMessage.isError ? _jsx("p", { className: "chat-error", role: "alert", children: sendErrorMessage(sendMessage.error) }) : null] }), selectedIsPageThread ? (_jsxs("p", { className: "chat-readonly-note", role: "note", children: ["\u8FD9\u662F\u89C6\u9891\u9875\u95EE\u7B54\u8BB0\u5F55\uFF0C\u56DE\u5230\u89C6\u9891\u9875\u53EF\u4EE5\u7EE7\u7EED\u63D0\u95EE\u3002", pageThreadLink ? _jsxs(_Fragment, { children: [" ", _jsx("a", { href: pageThreadLink, target: "_blank", rel: "noreferrer", children: "\u6253\u5F00\u8FD9\u4E2A\u89C6\u9891 \u2197" })] }) : null] })) : (_jsxs("form", { className: "chat-compose", "aria-label": "\u5411\u8D44\u6599\u5E93\u63D0\u95EE", onSubmit: submit, children: [_jsx("label", { className: "sr-only", htmlFor: "chat-question", children: "\u5411\u8D44\u6599\u5E93\u63D0\u95EE" }), _jsxs("div", { className: "chat-compose__field", children: [_jsx("textarea", { id: "chat-question", "aria-describedby": "chat-question-hint", value: draft, disabled: composerDisabled, onChange: (event) => setDraft(event.target.value), ref: composerRef, onKeyDown: (event) => {
                                                    if (touchInput || event.key !== "Enter" || event.shiftKey
                                                        || event.nativeEvent.isComposing || event.nativeEvent.keyCode === 229)
                                                        return;
                                                    event.preventDefault();
                                                    if (!event.repeat)
                                                        event.currentTarget.form?.requestSubmit();
                                                }, placeholder: "\u5411\u8D44\u6599\u5E93\u63D0\u95EE\u2026", rows: 2 }), _jsxs("div", { className: "chat-compose__footer", children: [_jsx("span", { id: "chat-question-hint", children: touchInput ? "回车换行，点击「发送」提交 · 回答附原文依据" : "Enter 发送，Shift+Enter 换行 · 回答附原文依据" }), _jsx("button", { className: "button button--primary", type: "submit", disabled: !draft.trim() || composerDisabled, children: sendMessage.isPending ? "正在检索…" : "发送问题 →" })] })] })] }))] })] })] }));
}
