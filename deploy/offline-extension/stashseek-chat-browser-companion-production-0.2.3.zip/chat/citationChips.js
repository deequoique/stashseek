import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId } from "react";
/**
 * Inline citation chips.
 *
 * The server rewrites each in-text citation marker into `[^n]`, where `n` is
 * the 1-based position of the citation in the answer's public `citations`
 * list. `remarkCitationChips` turns those markers into marked links and
 * `MarkdownAnswer` renders them as `CitationChip`. Browsers never see internal
 * segment IDs, and a `[^n]` that does not resolve to a citation stays text.
 */
const EXCERPT_CHARS = 120;
const MARKER = /\[\^(\d+)\]/g;
const CODE_SPAN = /```[\s\S]*?```|`[^`\n]*`/g;
// Never rewrite markers inside code or inside a model-authored link label.
const SKIPPED_NODE_TYPES = new Set(["code", "inlineCode", "link", "linkReference"]);
function startTime(value) {
    if (value === null || value === undefined)
        return null;
    const minutes = Math.floor(value / 60);
    const seconds = Math.floor(value % 60).toString().padStart(2, "0");
    return `${minutes}:${seconds}`;
}
function citationPosition(citation) {
    return startTime(citation.start_sec) ?? "标题与简介";
}
function excerptPreview(excerpt) {
    const chars = Array.from(excerpt.replace(/\s+/g, " ").trim());
    return chars.length > EXCERPT_CHARS ? `${chars.slice(0, EXCERPT_CHARS).join("")}…` : chars.join("");
}
function splitMarkers(value) {
    const parts = [];
    let cursor = 0;
    for (const match of value.matchAll(MARKER)) {
        const index = match.index ?? 0;
        if (index > cursor)
            parts.push({ type: "text", value: value.slice(cursor, index) });
        const ordinal = match[1];
        parts.push({
            type: "link",
            url: `#cite-${ordinal}`,
            data: { hProperties: { "data-cite": ordinal } },
            children: [{ type: "text", value: ordinal }],
        });
        cursor = index + match[0].length;
    }
    if (cursor === 0)
        return null;
    if (cursor < value.length)
        parts.push({ type: "text", value: value.slice(cursor) });
    return parts;
}
function rewriteMarkers(node) {
    if (!node.children || SKIPPED_NODE_TYPES.has(node.type))
        return;
    const next = [];
    for (const child of node.children) {
        const replaced = child.type === "text" && typeof child.value === "string"
            ? splitMarkers(child.value)
            : null;
        if (replaced) {
            next.push(...replaced);
        }
        else {
            rewriteMarkers(child);
            next.push(child);
        }
    }
    node.children = next;
}
export function remarkCitationChips() {
    return (tree) => {
        rewriteMarkers(tree);
    };
}
/** Ordinals that the answer text itself references (code spans excluded). */
function referencedOrdinals(text) {
    const found = new Set();
    for (const match of text.replace(CODE_SPAN, "").matchAll(MARKER)) {
        found.add(Number(match[1]));
    }
    return found;
}
export function CitationChip({ ordinal, citation, hidden = false, }) {
    const tipId = useId();
    const position = citationPosition(citation);
    const excerpt = excerptPreview(citation.excerpt);
    return (_jsxs("span", { className: "chat-cite-wrap", children: [_jsxs("a", { className: "chat-cite", href: citation.url, target: "_blank", rel: "noreferrer", "aria-label": `引用 ${ordinal}：《${citation.title}》 ${position}`, "aria-describedby": hidden ? undefined : tipId, "aria-hidden": hidden ? "true" : undefined, tabIndex: hidden ? -1 : undefined, children: [_jsx("span", { className: "chat-cite__mark", "aria-hidden": "true", children: "[" }), ordinal, _jsx("span", { className: "chat-cite__mark", "aria-hidden": "true", children: "]" })] }), _jsxs("span", { role: "tooltip", id: tipId, className: "chat-cite__tip", children: [_jsx("strong", { children: citation.title }), ` · ${position}`, excerpt ? _jsx("span", { className: "chat-cite__excerpt", children: excerpt }) : null] })] }));
}
/** Citations the answer text never marks, so removing the list hides none. */
export function UnreferencedChips({ citations, text, hidden = false, }) {
    const referenced = referencedOrdinals(text);
    const unreferenced = citations
        .map((citation, index) => ({ citation, ordinal: index + 1 }))
        .filter(({ ordinal }) => !referenced.has(ordinal));
    if (!unreferenced.length)
        return null;
    return (_jsxs("p", { className: "chat-cite-more", "aria-hidden": hidden ? "true" : undefined, children: [_jsx("span", { children: "\u53E6\u89C1" }), unreferenced.map(({ citation, ordinal }) => (_jsx(CitationChip, { ordinal: ordinal, citation: citation, hidden: hidden }, ordinal)))] }));
}
export function CitationToggle({ count, hidden, onToggle, }) {
    return (_jsxs("button", { type: "button", className: "chat-cite-toggle", "aria-pressed": !hidden, title: hidden ? "显示引用按钮" : "隐藏引用按钮", onClick: onToggle, children: ["\u5F15\u7528 ", count] }));
}
