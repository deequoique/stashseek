import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { BrandLogo } from "./BrandLogo";
import { BROWSER_COMPANION_STORE_URL, isExtensionContext } from "./browserCompanion";
import { RouteLink } from "./RouteTransition";
export const COMMUNITY_NOTICE_STORAGE_KEY = "stashseek:community-notice:v1:dismissed";
const GITHUB_REPOSITORY_URL = "https://github.com/deequoique/stashseek";
function communityNoticeWasDismissed() {
    try {
        return window.localStorage.getItem(COMMUNITY_NOTICE_STORAGE_KEY) === "true";
    }
    catch {
        return false;
    }
}
export function AppShell({ children, loginChannel, onLogout, logoutPending = false, logoutError }) {
    const loginChannelLabel = {
        telegram: "Telegram", email: "邮箱", wechat: "微信",
        microsoft: "Microsoft", wechat_website: "微信网站授权", qq: "QQ",
    }[loginChannel];
    const accountMenuRef = useRef(null);
    const communityMenuRef = useRef(null);
    const [communityNoticeVisible, setCommunityNoticeVisible] = useState(() => !communityNoticeWasDismissed());
    useEffect(() => {
        function closeTopbarMenus(event) {
            if (!(event.target instanceof Node))
                return;
            for (const menu of [communityMenuRef.current, accountMenuRef.current]) {
                if (menu && !menu.contains(event.target))
                    menu.removeAttribute("open");
            }
        }
        document.addEventListener("pointerdown", closeTopbarMenus);
        return () => document.removeEventListener("pointerdown", closeTopbarMenus);
    }, []);
    function dismissCommunityNotice() {
        setCommunityNoticeVisible(false);
        try {
            window.localStorage.setItem(COMMUNITY_NOTICE_STORAGE_KEY, "true");
        }
        catch {
            // The in-memory dismissal still applies when browser storage is blocked.
        }
    }
    return (_jsxs("div", { className: "app-shell", children: [_jsx("a", { className: "skip-link", href: "#main-content", children: "\u8DF3\u5230\u4E3B\u8981\u5185\u5BB9" }), _jsx("header", { className: "topbar", children: _jsxs("div", { className: "topbar__inner", children: [_jsxs(RouteLink, { className: "wordmark", to: "/library", "aria-label": "\u641C\u85CF\u52A9\u624B\u8D44\u6599\u5E93", children: [_jsx(BrandLogo, { className: "wordmark__sigil" }), _jsx("span", { children: "StashSeek Chat" })] }), _jsxs("div", { className: "topbar__actions", children: [isExtensionContext() ? null : (_jsxs("a", { className: "topbar__install", href: BROWSER_COMPANION_STORE_URL, target: "_blank", rel: "noreferrer", "aria-label": "\u5728 Chrome \u5E94\u7528\u5546\u5E97\u5B89\u88C5\u641C\u85CF\u52A9\u624B\u63D2\u4EF6", title: "\u5728 Chrome \u5E94\u7528\u5546\u5E97\u5B89\u88C5", children: [_jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "M4 7h3a1 1 0 0 0 1 -1v-1a2 2 0 0 1 4 0v1a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h1a2 2 0 0 1 0 4h-1a1 1 0 0 0 -1 1v3a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-1a2 2 0 0 0 -4 0v1a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h1a2 2 0 0 0 0 -4h-1a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1" }) }), _jsx("span", { children: "Chrome \u63D2\u4EF6" })] })), _jsxs("details", { className: "community-menu", ref: communityMenuRef, children: [_jsx("summary", { "aria-label": "\u67E5\u770B\u7528\u6237\u4EA4\u6D41\u7FA4\uFF0CQQ\u7FA4 1107151131", title: "QQ\u7FA4 1107151131", children: _jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "M21.395 15.035a40 40 0 0 0-.803-2.264l-1.079-2.695c.001-.032.014-.562.014-.836C19.526 4.632 17.351 0 12 0S4.474 4.632 4.474 9.241c0 .274.013.804.014.836l-1.08 2.695a39 39 0 0 0-.802 2.264c-1.021 3.283-.69 4.643-.438 4.673.54.065 2.103-2.472 2.103-2.472 0 1.469.756 3.387 2.394 4.771-.612.188-1.363.479-1.845.835-.434.32-.379.646-.301.778.343.578 5.883.369 7.482.189 1.6.18 7.14.389 7.483-.189.078-.132.132-.458-.301-.778-.483-.356-1.233-.646-1.846-.836 1.637-1.384 2.393-3.302 2.393-4.771 0 0 1.563 2.537 2.103 2.472.251-.03.581-1.39-.438-4.673" }) }) }), _jsxs("div", { className: "community-popover", children: [_jsx("p", { className: "eyebrow", children: "\u7528\u6237\u4EA4\u6D41\u7FA4" }), _jsx("strong", { children: "QQ\u7FA4 1107151131" }), _jsx("p", { children: "\u6B22\u8FCE\u4EA4\u6D41\u4F7F\u7528\u4F53\u9A8C\u3001\u53CD\u9988\u95EE\u9898\u3002" })] })] }), _jsx("a", { className: "topbar__external-link", href: GITHUB_REPOSITORY_URL, target: "_blank", rel: "noreferrer", "aria-label": "\u5728 GitHub \u67E5\u770B StashSeek \u6E90\u7801\uFF0C\u6B22\u8FCE\u63D0\u4EA4 Issue \u4E0E PR", title: "GitHub \u00B7 \u6B22\u8FCE\u63D0 Issue / PR", children: _jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "M12 .7a11.5 11.5 0 0 0-3.6 22.4c.6.1.8-.2.8-.5v-2c-3.4.7-4.1-1.4-4.1-1.4-.5-1.4-1.3-1.8-1.3-1.8-1.1-.7.1-.7.1-.7 1.2.1 1.9 1.2 1.9 1.2 1.1 1.9 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.7-.3-5.5-1.4-5.5-6 0-1.3.5-2.4 1.2-3.2-.1-.3-.5-1.5.1-3.2 0 0 1-.3 3.3 1.2a11.3 11.3 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.6 1.7.2 2.9.1 3.2.7.8 1.2 1.9 1.2 3.2 0 4.6-2.8 5.7-5.5 6 .4.4.8 1.1.8 2.2v3.3c0 .3.2.6.8.5A11.5 11.5 0 0 0 12 .7Z" }) }) }), _jsxs("details", { className: "account-menu", ref: accountMenuRef, children: [_jsx("summary", { "aria-label": `打开账户菜单，当前登录方式：${loginChannelLabel}`, children: _jsxs("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: [_jsx("circle", { cx: "12", cy: "8", r: "3.25" }), _jsx("path", { d: "M5.75 19c.7-3.3 2.8-5 6.25-5s5.55 1.7 6.25 5" })] }) }), _jsxs("div", { className: "account-popover", children: [_jsx("p", { className: "eyebrow", children: "\u767B\u5F55\u65B9\u5F0F" }), _jsx("strong", { children: loginChannelLabel }), _jsx(RouteLink, { className: "account-popover__link", to: "/account/link", children: "\u7ED1\u5B9A Telegram" }), _jsx(RouteLink, { className: "account-popover__link", to: "/account/browser-companion", children: "\u6D4F\u89C8\u5668\u4F34\u4FA3" }), _jsx("button", { disabled: logoutPending, onClick: onLogout, children: "\u9000\u51FA\u767B\u5F55" }), logoutError ? _jsx("p", { className: "account-popover__error", role: "alert", children: logoutError }) : null] })] })] })] }) }), communityNoticeVisible ? (_jsx("aside", { className: "community-notice", "aria-label": "StashSeek \u7528\u6237\u4EA4\u6D41\u7FA4\u516C\u544A", children: _jsxs("div", { className: "community-notice__inner", children: [_jsxs("svg", { className: "community-notice__icon", "aria-hidden": "true", viewBox: "0 0 24 24", children: [_jsx("path", { d: "M4.5 5.5h15a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H12l-4.5 3v-3h-3a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z" }), _jsx("path", { d: "M7 10h10M7 13.5h6" })] }), _jsxs("p", { children: ["\u975E\u5E38\u9AD8\u5174\u770B\u5230\u60A8\u5728\u4F7F\u7528\u8FD9\u6B3E\u4EA7\u54C1\u3002StashSeek \u4ECD\u5904\u4E8E\u975E\u5E38\u521D\u671F\u7684\u9636\u6BB5\u3002\u4E3A\u4E86\u66F4\u597D\u5730\u7EF4\u62A4\u548C\u8FED\u4EE3\u8FD9\u6B3E\u4EA7\u54C1\uFF0C\u8BDA\u9080\u60A8\u52A0\u5165\u7528\u6237\u4EA4\u6D41\u7FA4\uFF08QQ\u7FA4\uFF1A", _jsx("strong", { children: "1107151131" }), "\uFF09\u3002\u540C\u65F6\uFF0CStashSeek \u5B8C\u5168\u5F00\u6E90\uFF0C\u4E5F\u6B22\u8FCE\u4EFB\u4F55\u4EBA\u5728 GitHub \u4E0A\u63D0\u4EA4 Issue \u4E0E PR\u3002"] }), _jsx("button", { type: "button", onClick: dismissCommunityNotice, "aria-label": "\u5173\u95ED\u7528\u6237\u4EA4\u6D41\u7FA4\u516C\u544A", children: _jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "m7 7 10 10M17 7 7 17" }) }) })] }) })) : null, _jsx("main", { className: "page-container", id: "main-content", tabIndex: -1, children: children })] }));
}
