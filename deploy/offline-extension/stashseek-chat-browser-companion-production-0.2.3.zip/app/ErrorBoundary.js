import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Component } from "react";
import { useLocation } from "react-router";
/** A stale extension tab keeps the old chunk URLs after a release. */
export function isChunkLoadError(error) {
    const text = error instanceof Error ? `${error.name} ${error.message}` : String(error);
    return /ChunkLoadError|Loading chunk \d+ failed|dynamically imported module|Importing a module script failed|Failed to fetch/i.test(text);
}
export class ErrorBoundary extends Component {
    state = { error: null };
    static getDerivedStateFromError(error) {
        return { error };
    }
    componentDidCatch(error, info) {
        console.error("route_render_failed", error, info.componentStack);
    }
    componentDidUpdate(previous) {
        if (this.state.error && previous.resetKey !== this.props.resetKey) {
            this.setState({ error: null });
        }
    }
    render() {
        if (this.state.error === null)
            return this.props.children;
        const staleChunk = isChunkLoadError(this.state.error);
        return (_jsxs("main", { className: "route-error", role: "alert", children: [_jsx("h1", { children: staleChunk ? "页面版本已更新" : "页面暂时无法显示" }), _jsx("p", { children: staleChunk
                        ? "这个标签页加载的旧版本已经失效，重新加载即可继续。"
                        : "刷新页面后再试一次；如果仍然失败，请稍后回来。" }), _jsx("div", { className: "route-error__actions", children: _jsx("button", { className: "button button--primary", type: "button", onClick: () => window.location.reload(), children: "\u91CD\u65B0\u52A0\u8F7D" }) })] }));
    }
}
/** Reset the boundary when navigation succeeds, so one bad page does not stick. */
export function RouteErrorBoundary({ children }) {
    const location = useLocation();
    return (_jsx(ErrorBoundary, { resetKey: `${location.pathname}${location.search}`, children: children }));
}
