import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo } from "react";
import { useSearchParams } from "react-router";
import { ApiError, approveBrowserCompanionPairing, listBrowserCompanionDevices, revokeBrowserCompanionDevice, } from "../api/client";
import { BROWSER_COMPANION_DOWNLOAD_URL, BROWSER_COMPANION_STORE_URL } from "../app/browserCompanion";
const PAIRING_ID_RE = /^[a-f0-9]{32}$/;
function companionError(error) {
    if (error instanceof ApiError) {
        if (error.code === "extension_pairing_expired")
            return "这次配对已过期，请回到插件重新开始。";
        if (error.code === "extension_pairing_used")
            return "这次配对已经完成，请在插件中继续。";
        if (error.code === "extension_pairing_invalid")
            return "配对请求无效，请从插件重新打开此页面。";
        if (error.code === "extension_device_not_found")
            return "该设备已经断开。";
    }
    return "暂时无法完成操作，请稍后重试。";
}
export function BrowserCompanionPage() {
    const [params] = useSearchParams();
    const pairingId = useMemo(() => params.get("pairing")?.trim() ?? "", [params]);
    const validPairing = PAIRING_ID_RE.test(pairingId);
    const queryClient = useQueryClient();
    const devices = useQuery({
        queryKey: ["browser-companion", "devices"],
        queryFn: listBrowserCompanionDevices,
        refetchInterval: (query) => pairingId && query.state.data?.devices.length === 0 ? 2_000 : false,
    });
    const approve = useMutation({
        mutationFn: () => approveBrowserCompanionPairing(pairingId),
        onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["browser-companion", "devices"] }),
    });
    const revoke = useMutation({
        mutationFn: revokeBrowserCompanionDevice,
        onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["browser-companion", "devices"] }),
    });
    return (_jsxs("section", { className: "account-link-page companion-page", "aria-labelledby": "companion-title", children: [_jsxs("header", { className: "account-link-page__heading", children: [_jsx("p", { className: "eyebrow", children: "Chrome \u63D2\u4EF6" }), _jsx("h1", { id: "companion-title", children: "\u6D4F\u89C8\u5668\u4F34\u4FA3" }), _jsx("p", { children: "\u5728 YouTube \u548C\u54D4\u54E9\u54D4\u54E9\u89C6\u9891\u65C1\u76F4\u63A5\u63D0\u95EE\u3001\u4FDD\u5B58\u5B57\u5E55\u3002\u63D2\u4EF6\u8BFB\u53D6\u4F60\u6D4F\u89C8\u5668\u91CC\u5DF2\u7ECF\u6253\u5F00\u7684\u9875\u9762\uFF0C\u670D\u52A1\u5668\u8BBF\u95EE\u53D7\u9650\u65F6\u540C\u6837\u53EF\u7528\u3002" })] }), pairingId ? (_jsxs("section", { className: "account-link-card companion-pairing", "aria-labelledby": "companion-pair-title", children: [_jsx("p", { className: "step-number", "aria-hidden": "true", children: "01" }), _jsx("h2", { id: "companion-pair-title", children: "\u8FDE\u63A5\u8FD9\u4E2A\u63D2\u4EF6" }), _jsx("p", { children: "\u8FDE\u63A5\u540E\uFF0C\u63D2\u4EF6\u53EA\u80FD\u5411\u4F60\u7684\u8D44\u6599\u5E93\u63D0\u4EA4\u5F53\u524D\u89C6\u9891\u7684\u5B57\u5E55\u548C\u516C\u5F00\u5143\u6570\u636E\uFF0C\u4E0D\u80FD\u8BFB\u53D6\u8D44\u6599\u5E93\u3001\u804A\u5929\u6216\u8D26\u6237\u8BBE\u7F6E\u3002" }), !validPairing ? _jsx("p", { className: "inline-error", role: "alert", children: "\u914D\u5BF9\u94FE\u63A5\u683C\u5F0F\u65E0\u6548\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u91CD\u65B0\u5F00\u59CB\u3002" }) : null, approve.isSuccess ? _jsx("p", { className: "account-link-status", role: "status", children: "\u5DF2\u6279\u51C6\u3002\u8BF7\u56DE\u5230\u63D2\u4EF6\uFF0C\u5B83\u4F1A\u81EA\u52A8\u5B8C\u6210\u8FDE\u63A5\u3002" }) : null, approve.isError ? _jsx("p", { className: "inline-error", role: "alert", children: companionError(approve.error) }) : null, _jsx("button", { className: "button button--primary button--wide", type: "button", disabled: !validPairing || approve.isPending || approve.isSuccess, onClick: () => approve.mutate(), children: approve.isPending ? "正在批准…" : approve.isSuccess ? "已批准" : "允许连接" })] })) : (_jsxs("section", { className: "account-link-card companion-pairing", "aria-labelledby": "companion-install-title", children: [_jsx("p", { className: "step-number", "aria-hidden": "true", children: "01" }), _jsx("h2", { id: "companion-install-title", children: "\u4ECE Chrome \u5E94\u7528\u5546\u5E97\u5B89\u88C5" }), _jsx("p", { children: "\u6DFB\u52A0\u540E\u70B9\u51FB\u5DE5\u5177\u680F\u91CC\u7684\u641C\u85CF\u52A9\u624B\u56FE\u6807\u6253\u5F00\u4FA7\u8FB9\u680F\uFF0C\u7528\u90AE\u7BB1\u9A8C\u8BC1\u7801\u767B\u5F55\u5373\u53EF\u5B8C\u6210\u8FDE\u63A5\u3002\u4F60\u4E5F\u53EF\u4EE5\u968F\u65F6\u5728\u6D4F\u89C8\u5668\u91CC\u505C\u7528\u6216\u5378\u8F7D\u63D2\u4EF6\u3002" }), _jsx("a", { className: "button button--primary button--wide", href: BROWSER_COMPANION_STORE_URL, target: "_blank", rel: "noreferrer", children: "\u524D\u5F80 Chrome \u5E94\u7528\u5546\u5E97" }), _jsxs("p", { className: "companion-offline", children: ["\u65E0\u6CD5\u8BBF\u95EE\u5E94\u7528\u5546\u5E97\uFF1F", _jsx("a", { download: true, href: BROWSER_COMPANION_DOWNLOAD_URL, children: "\u4E0B\u8F7D\u79BB\u7EBF\u5B89\u88C5\u5305" }), "\uFF0C\u5728 chrome://extensions \u5F00\u542F\u5F00\u53D1\u8005\u6A21\u5F0F\u540E\u52A0\u8F7D\u3002"] })] })), _jsxs("section", { className: "account-link-card companion-devices", "aria-labelledby": "companion-devices-title", children: [_jsx("p", { className: "step-number", "aria-hidden": "true", children: "02" }), _jsx("h2", { id: "companion-devices-title", children: "\u5DF2\u8FDE\u63A5\u7684\u63D2\u4EF6" }), devices.isPending ? _jsx("p", { "aria-live": "polite", children: "\u6B63\u5728\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001\u2026" }) : null, devices.isError ? _jsx("p", { className: "inline-error", role: "alert", children: companionError(devices.error) }) : null, devices.data?.devices.length === 0 ? _jsx("p", { children: "\u76EE\u524D\u6CA1\u6709\u5DF2\u8FDE\u63A5\u7684\u63D2\u4EF6\u3002" }) : null, devices.data?.devices.map((device) => (_jsxs("article", { className: "companion-device", children: [_jsxs("div", { children: [_jsx("strong", { children: device.client_label }), _jsxs("p", { children: ["\u7248\u672C ", device.client_version, device.revoked_at ? " · 已断开" : " · 已连接"] })] }), _jsx("button", { className: "button button--quiet", type: "button", disabled: Boolean(device.revoked_at) || revoke.isPending, onClick: () => revoke.mutate(device.device_id), children: device.revoked_at ? "已断开" : "断开连接" })] }, device.device_id))), revoke.isError ? _jsx("p", { className: "inline-error", role: "alert", children: companionError(revoke.error) }) : null] }), _jsx("p", { className: "account-link-warning", role: "note", children: "\u63D2\u4EF6\u4E0D\u4F1A\u4E0A\u4F20\u767B\u5F55 Cookie\u3001\u4F1A\u8BDD\u5BC6\u94A5\u3001\u7B7E\u540D\u89C6\u9891\u5730\u5740\u6216\u97F3\u89C6\u9891\u6587\u4EF6\u3002" })] }));
}
