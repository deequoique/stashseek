import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router";
import { createLoginChallenge, exchangeChallenge, getChallengeStatus, logout, probeLoginSession, requestEmailChallenge, verifyEmailChallenge, } from "../api/client";
import { BrandLogo } from "../app/BrandLogo";
import { BROWSER_COMPANION_DOWNLOAD_URL } from "../app/browserCompanion";
import { useRouteNavigate } from "../app/RouteTransition";
import { capabilitiesQueryOptions } from "../chat/conversationQueries";
import { EmailLoginFlow } from "./EmailLoginFlow";
import { ExternalLoginMethods } from "./ExternalLoginMethods";
// The external-login continuation is a cookie/302 flow anchored on an http(s)
// origin; a chrome-extension:// side panel never receives those SameSite
// cookies, so its entry points stay hidden until a Bearer handoff exists.
const extensionWorkspace = typeof chrome !== "undefined"
    && Boolean(chrome.storage?.local)
    && globalThis.location?.protocol === "chrome-extension:";
function hasAccountLinkSuccess(state) {
    return (typeof state === "object"
        && state !== null
        && "accountLinkSuccess" in state
        && state.accountLinkSuccess === true);
}
export function LoginPage({ loadCapabilities, createChallenge = createLoginChallenge, getStatus = getChallengeStatus, exchangeSession = exchangeChallenge, requestEmailChallenge: sendEmailChallenge = requestEmailChallenge, verifyEmailChallenge: confirmEmailChallenge = verifyEmailChallenge, onAuthenticated, probeSession = probeLoginSession, signOut = logout, onSignedOut, onAnonymous, }) {
    const navigate = useRouteNavigate();
    const location = useLocation();
    const [accountLinkSuccess, setAccountLinkSuccess] = useState(false);
    const [challenge, setChallenge] = useState(null);
    const [email, setEmail] = useState("");
    const [code, setCode] = useState("");
    const [emailStep, setEmailStep] = useState("email");
    const [emailError, setEmailError] = useState(null);
    const mounted = useRef(false);
    const generation = useRef(0);
    useEffect(() => {
        mounted.current = true;
        generation.current += 1;
        return () => { mounted.current = false; generation.current += 1; };
    }, []);
    function current(requestGeneration) { return mounted.current && requestGeneration === generation.current; }
    const capabilities = useQuery(capabilitiesQueryOptions(loadCapabilities));
    const externalProviders = !extensionWorkspace && capabilities.isSuccess
        ? capabilities.data.external_login_providers ?? []
        : [];
    const loginSession = useQuery({
        queryKey: ["login-session-probe"], queryFn: ({ signal }) => probeSession(signal),
        enabled: externalProviders.length > 0, retry: false, gcTime: 0, staleTime: 0,
    });
    const signOutMutation = useMutation({
        mutationFn: signOut, gcTime: 0,
        onMutate: () => generation.current,
        onSuccess: (_response, _variables, requestGeneration) => {
            if (!current(requestGeneration))
                return;
            if (onSignedOut)
                onSignedOut();
            else
                void loginSession.refetch();
        },
    });
    const mutation = useMutation({
        gcTime: 0,
        mutationFn: (channel) => createChallenge(channel),
        onMutate: () => generation.current,
        onSuccess: (value, _variables, requestGeneration) => { if (current(requestGeneration))
            setChallenge(value); },
    });
    const status = useQuery({
        queryKey: ["login-challenge", challenge?.public_id],
        queryFn: () => getStatus(challenge.public_id, challenge.browser_secret),
        enabled: challenge !== null,
        retry: false,
        gcTime: 0,
        refetchInterval: challengePollInterval,
    });
    const exchange = useMutation({
        gcTime: 0,
        mutationFn: () => exchangeSession(challenge.public_id, challenge.browser_secret),
        onMutate: () => generation.current,
        onSuccess: (session, _variables, requestGeneration) => { if (current(requestGeneration))
            activate(session); },
    });
    const emailChallenge = useMutation({
        gcTime: 0,
        mutationFn: (value) => sendEmailChallenge(value),
        onMutate: () => generation.current,
        onSuccess: (_response, _variables, requestGeneration) => {
            if (!current(requestGeneration))
                return;
            setEmailStep("code");
            setCode("");
            setEmailError(null);
        },
    });
    const emailVerify = useMutation({
        gcTime: 0,
        mutationFn: ({ address, value }) => confirmEmailChallenge(address, value),
        onMutate: () => generation.current,
        onSuccess: (session, _variables, requestGeneration) => { if (current(requestGeneration))
            activate(session); },
    });
    useEffect(() => {
        if (mounted.current && externalProviders.length > 0 && loginSession.isSuccess && loginSession.data === null)
            onAnonymous?.();
    }, [externalProviders.length, loginSession.data, loginSession.isSuccess, onAnonymous]);
    useEffect(() => {
        if (!hasAccountLinkSuccess(location.state))
            return;
        setAccountLinkSuccess(true);
        // Consume the one-time notice from history immediately.  It carries no
        // token or account identifier and is never written to browser storage.
        navigate(location.pathname, { replace: true, state: null });
    }, [location.pathname, location.state, navigate]);
    function activate(session) {
        if (!mounted.current)
            return;
        if (onAuthenticated)
            onAuthenticated(session);
        else
            navigate("/library", { replace: true });
    }
    useEffect(() => {
        if (status.data?.status === "approved" && exchange.isIdle)
            exchange.mutate();
    }, [status.data?.status, exchange]);
    const emailEnabled = Boolean(capabilities.data?.web_login_channels.includes("email"));
    const loginFailed = mutation.isError || status.isError || exchange.isError;
    const telegramAvailability = channelAvailability(capabilities, "telegram");
    const wechatAvailability = channelAvailability(capabilities, "wechat");
    const hasLegacyMethods = capabilities.data?.web_login_channels.some((channel) => channel === "telegram" || channel === "wechat");
    const checkingSession = externalProviders.length > 0 && loginSession.isPending;
    const existingSession = externalProviders.length > 0 ? loginSession.data : null;
    function startChannelLogin(channel) {
        if (channelAvailability(capabilities, channel) !== "available" ||
            mutation.isPending || emailChallenge.isPending || emailVerify.isPending)
            return;
        mutation.mutate(channel);
    }
    function restartLogin() {
        generation.current += 1;
        setChallenge(null);
        mutation.reset();
        exchange.reset();
    }
    function resetEmailLogin() {
        generation.current += 1;
        setEmailStep("email");
        setCode("");
        setEmailError(null);
        emailChallenge.reset();
        emailVerify.reset();
    }
    function submitEmail(event) {
        event.preventDefault();
        const value = email.trim();
        if (value.length < 3 || !value.includes("@")) {
            setEmailError("请输入有效的邮箱地址。");
            return;
        }
        setEmailError(null);
        if (!emailChallenge.isPending)
            emailChallenge.mutate(value);
    }
    function submitCode(event) {
        event.preventDefault();
        const value = code.trim();
        if (!/^\d{6}$/.test(value)) {
            setEmailError("请输入 6 位数字验证码。");
            return;
        }
        setEmailError(null);
        if (!emailVerify.isPending) {
            emailVerify.mutate({ address: email.trim(), value });
        }
    }
    const emailFailure = emailError ||
        (emailChallenge.isError || emailVerify.isError
            ? "登录暂时没有完成，请检查输入后重试。"
            : null);
    return (_jsxs("main", { className: "login-page", children: [_jsx("div", { className: "paper-glow", "aria-hidden": "true" }), _jsxs("section", { className: "login-card", "aria-labelledby": "login-title", children: [_jsxs("div", { className: "login-card__topline", children: [_jsxs("a", { className: "wordmark", href: "/", "aria-label": "\u641C\u85CF\u52A9\u624B\u9996\u9875", children: [_jsx(BrandLogo, { className: "wordmark__sigil" }), _jsx("span", { children: "StashSeek Chat" })] }), _jsx("a", { className: "login-companion-link", download: true, href: BROWSER_COMPANION_DOWNLOAD_URL, children: "\u83B7\u53D6\u6D4F\u89C8\u5668\u63D2\u4EF6" })] }), _jsx("p", { className: "eyebrow", children: "\u641C\u85CF\u52A9\u624B \u00B7 \u548C\u6536\u85CF\u5185\u5BB9\u76F4\u63A5\u5BF9\u8BDD" }), _jsx("h1", { id: "login-title", children: "\u767B\u5F55\u641C\u85CF\u52A9\u624B" }), accountLinkSuccess ? (_jsx("p", { className: "login-success-note", role: "status", "aria-live": "polite", children: "Telegram \u5DF2\u7ED1\u5B9A\u3002\u8BF7\u4F7F\u7528\u90AE\u7BB1\u9A8C\u8BC1\u7801\u91CD\u65B0\u767B\u5F55\uFF0C\u8FDB\u5165\u5408\u5E76\u540E\u7684\u79C1\u4EBA\u8D44\u6599\u5E93\u3002" })) : null, existingSession ? (_jsxs("div", { className: "external-session-notice", role: "status", children: [_jsx("p", { children: "\u6B64\u6D4F\u89C8\u5668\u5DF2\u767B\u5F55\u3002\u8BF7\u7EE7\u7EED\u5F53\u524D\u8D44\u6599\u5E93\uFF0C\u6216\u9000\u51FA\u540E\u4F7F\u7528\u5176\u4ED6\u8D26\u53F7\u3002" }), _jsx("button", { className: "button button--primary button--wide", type: "button", onClick: () => activate(existingSession), children: "\u7EE7\u7EED\u5F53\u524D\u8D44\u6599\u5E93" }), _jsx("button", { className: "login-back-button", type: "button", disabled: signOutMutation.isPending, onClick: () => signOutMutation.mutate(), children: "\u9000\u51FA\u540E\u5207\u6362\u8D26\u53F7" }), signOutMutation.isError ? _jsx("p", { role: "alert", children: "\u9000\u51FA\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5\uFF1B\u5F53\u524D\u767B\u5F55\u4ECD\u4FDD\u7559\u3002" }) : null] })) : checkingSession ? _jsx("p", { role: "status", children: "\u6B63\u5728\u786E\u8BA4\u5F53\u524D\u767B\u5F55\u2026" }) : _jsxs(_Fragment, { children: [emailEnabled && !challenge ? (_jsx(EmailLoginFlow, { email: email, code: code, step: emailStep, pendingEmail: emailChallenge.isPending, pendingCode: emailVerify.isPending, error: emailFailure, onEmailChange: (value) => {
                                    setEmail(value);
                                    if (emailError)
                                        setEmailError(null);
                                }, onCodeChange: (value) => {
                                    setCode(value.replace(/\D/g, "").slice(0, 6));
                                    if (emailError)
                                        setEmailError(null);
                                }, onSubmitEmail: submitEmail, onSubmitCode: submitCode, onChangeEmail: resetEmailLogin })) : null, !challenge ? _jsx(ExternalLoginMethods, { providers: externalProviders, disabled: loginSession.isError || emailChallenge.isPending || emailVerify.isPending || mutation.isPending }) : null, loginSession.isError && externalProviders.length > 0 ? _jsxs("p", { role: "alert", children: ["\u65E0\u6CD5\u786E\u8BA4\u5F53\u524D\u767B\u5F55\uFF0C\u8BF7\u91CD\u8BD5\u3002", _jsx("button", { className: "text-button", type: "button", onClick: () => void loginSession.refetch(), children: "\u91CD\u65B0\u68C0\u67E5" })] }) : null, challenge ? (_jsxs("div", { className: "login-flow", children: [_jsxs("div", { className: "challenge-card", "aria-live": "polite", children: [_jsx("span", { className: "step-number", children: "01" }), _jsxs("div", { children: [_jsxs("p", { children: ["\u8BF7\u5728 ", challenge.target_channel === "telegram" ? "Telegram" : "微信", " \u4E2D\u53D1\u9001\u8FD9\u6761\u767B\u5F55\u6307\u4EE4\uFF1A"] }), _jsx("code", { children: challenge.command }), _jsx("p", { className: "muted", children: exchange.isSuccess
                                                            ? "登录已确认，正在打开资料库…"
                                                            : "发送后请留在本页；确认完成会自动进入资料库。这条登录指令会在短时间后失效。" })] })] }), _jsx("button", { className: "login-back-button", type: "button", onClick: restartLogin, children: "\u2190 \u66F4\u6362\u767B\u5F55\u65B9\u5F0F" })] })) : !emailEnabled || hasLegacyMethods ? (_jsxs("div", { className: "login-method-panel", children: [_jsxs("div", { className: "login-method-heading", children: [_jsx("span", { children: "\u767B\u5F55\u65B9\u5F0F" }), _jsx("small", { children: "\u4F7F\u7528\u5DF2\u7ED1\u5B9A\u7684\u804A\u5929\u8D26\u53F7\u7EE7\u7EED" })] }), _jsxs("div", { className: "login-methods", "aria-label": "\u9009\u62E9\u767B\u5F55\u65B9\u5F0F", children: [_jsx(LoginMethodOption, { ariaLabel: emailEnabled || externalProviders.includes("wechat_website") ? "使用微信聊天账号登录" : "使用微信登录", icon: _jsx(WechatBrandIcon, {}), iconClassName: "login-method__icon--wechat", title: emailEnabled || externalProviders.includes("wechat_website") ? "微信聊天账号" : "微信", status: channelStatusLabel(wechatAvailability, mutation.isPending && mutation.variables === "wechat"), statusTone: channelStatusTone(wechatAvailability), disabled: wechatAvailability !== "available" || mutation.isPending || emailChallenge.isPending || emailVerify.isPending, onClick: () => startChannelLogin("wechat") }), _jsx(LoginMethodOption, { ariaLabel: "\u4F7F\u7528 Telegram \u767B\u5F55", icon: _jsx(TelegramBrandIcon, {}), iconClassName: "login-method__icon--telegram", title: "Telegram", status: channelStatusLabel(telegramAvailability, mutation.isPending && mutation.variables === "telegram"), statusTone: channelStatusTone(telegramAvailability), disabled: telegramAvailability !== "available" || mutation.isPending || emailChallenge.isPending || emailVerify.isPending, onClick: () => startChannelLogin("telegram") })] }), capabilities.isError ? (_jsxs("div", { className: "login-capability-error", children: [_jsx("p", { className: "inline-error", role: "alert", children: "\u767B\u5F55\u65B9\u5F0F\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002" }), _jsx("button", { className: "login-retry-button", type: "button", "aria-label": "\u91CD\u8BD5", onClick: () => void capabilities.refetch(), children: "\u91CD\u65B0\u52A0\u8F7D\u767B\u5F55\u65B9\u5F0F" })] })) : null, capabilities.isPending ? (_jsx("p", { className: "login-capability-note", "aria-live": "polite", children: "\u6B63\u5728\u52A0\u8F7D\u767B\u5F55\u65B9\u5F0F\u2026" })) : null] })) : null, loginFailed ? (_jsxs("div", { children: [_jsx("p", { className: "inline-error", role: "alert", children: challenge ? "登录没有完成，请重新获取登录指令。" : "暂时无法开始登录，请重试。" }), challenge ? (_jsx("button", { className: "button button--quiet button--wide", type: "button", onClick: restartLogin, children: "\u91CD\u65B0\u83B7\u53D6" })) : null] })) : null] }), _jsx("p", { className: "privacy-note", children: "\u767B\u5F55\u540E\u53EA\u4F1A\u663E\u793A\u4F60\u81EA\u5DF1\u7684\u8D44\u6599\u5E93\u3002" })] })] }));
}
function LoginMethodOption({ ariaLabel, icon, iconClassName, title, status, statusTone = "muted", disabled = false, onClick, }) {
    return (_jsxs("button", { className: "login-method", type: "button", "aria-label": ariaLabel, disabled: disabled, onClick: onClick, children: [_jsx("span", { className: `login-method__icon${iconClassName ? ` ${iconClassName}` : ""}`, "aria-hidden": "true", children: icon }), _jsx("span", { className: "login-method__copy", children: _jsx("strong", { children: title }) }), _jsx("span", { className: `login-method__status login-method__status--${statusTone}`, children: status })] }));
}
function WechatBrandIcon() {
    return (_jsxs("svg", { "data-testid": "wechat-brand-icon", viewBox: "0 0 32 32", focusable: "false", children: [_jsx("path", { d: "M13.5 5.4C7.3 5.4 2.3 9.6 2.3 14.8c0 2.9 1.6 5.5 4.1 7.2l-1 3.6 4-2c1.3.4 2.7.7 4.1.7h.7a8.8 8.8 0 0 1-.5-2.9c0-5.1 4.7-9.2 10.5-9.4-1.5-3.8-5.7-6.6-10.7-6.6Zm-3.8 7.1a1.5 1.5 1 1 1 0-3 1.5 1.5 0 0 1 0 3Zm7.5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z" }), _jsx("path", { d: "M29.7 21.4c0-4.2-4-7.6-8.8-7.6S12 17.2 12 21.4s4 7.6 8.9 7.6c1.2 0 2.3-.2 3.3-.6l3.2 1.7-.8-2.9a7.3 7.3 0 0 0 3.1-5.8Zm-11.8-1.2a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4Zm6 0a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4Z" })] }));
}
function TelegramBrandIcon() {
    return (_jsx("svg", { "data-testid": "telegram-brand-icon", viewBox: "0 0 24 24", focusable: "false", children: _jsx("path", { d: "M21.7 3.4 18.5 20c-.2 1.2-.9 1.5-1.9.9l-4.9-3.6-2.4 2.3c-.3.3-.5.5-1 .5l.4-5 9.1-8.2c.4-.4-.1-.6-.6-.2L6 13.7l-4.8-1.5c-1.1-.3-1.1-1.1.2-1.6L20.2 3.3c.9-.3 1.7.2 1.5 1.1Z" }) }));
}
function channelAvailability(capabilities, channel) {
    if (capabilities.isPending)
        return "checking";
    if (capabilities.isError || !capabilities.data)
        return "unavailable";
    return capabilities.data.web_login_channels.includes(channel) ? "available" : "disabled";
}
function channelStatusLabel(availability, isStarting) {
    if (isStarting)
        return "正在创建…";
    switch (availability) {
        case "checking":
            return "正在检测";
        case "available":
            return "可以使用";
        case "disabled":
            return "暂不可用";
        case "unavailable":
            return "暂时无法连接";
    }
}
function channelStatusTone(availability) {
    switch (availability) {
        case "available":
            return "ready";
        case "unavailable":
            return "error";
        case "checking":
        case "disabled":
            return "muted";
    }
}
export function challengePollInterval(query) {
    if (query.state.status === "error")
        return false;
    return query.state.data?.status === "pending" ? 1_500 : false;
}
