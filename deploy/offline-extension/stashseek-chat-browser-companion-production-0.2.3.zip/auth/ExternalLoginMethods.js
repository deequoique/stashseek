import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
export const externalProviderLabels = {
    microsoft: "Microsoft",
    wechat_website: "微信网站授权",
    qq: "QQ",
};
export function ExternalLoginMethods({ providers, disabled = false }) {
    const [starting, setStarting] = useState(null);
    const startingRef = useRef(false);
    useEffect(() => {
        function restorePage() {
            startingRef.current = false;
            setStarting(null);
        }
        window.addEventListener("pageshow", restorePage);
        return () => window.removeEventListener("pageshow", restorePage);
    }, []);
    const available = Object.keys(externalProviderLabels)
        .filter((provider) => providers.includes(provider));
    if (!available.length)
        return null;
    return (_jsxs("section", { className: "external-login-methods", "aria-label": "\u5176\u4ED6\u767B\u5F55\u65B9\u5F0F", children: [_jsx("p", { children: "\u9996\u6B21\u767B\u5F55\u9700\u9A8C\u8BC1\u90AE\u7BB1\u5E76\u7ED1\u5B9A\uFF0C\u4E4B\u540E\u53EF\u76F4\u63A5\u8FDB\u5165\u540C\u4E00\u8D44\u6599\u5E93\u3002" }), _jsx("div", { children: available.map((provider) => (_jsx("form", { method: "post", action: `/api/v1/auth/external/${provider}/start`, onSubmit: (event) => {
                        if (disabled || startingRef.current) {
                            event.preventDefault();
                            return;
                        }
                        startingRef.current = true;
                        setStarting(provider);
                    }, children: _jsx("button", { className: "external-login-method", type: "submit", disabled: disabled || starting !== null, children: starting === provider ? "正在跳转…" : `使用 ${externalProviderLabels[provider]} 登录` }) }, provider))) })] }));
}
