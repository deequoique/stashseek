import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useMutation } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ApiError, cancelExternalLogin, getExternalLoginPending, logout, probeLoginSession, requestExternalLoginCode, verifyExternalLogin, } from "../api/client";
import { BrandLogo } from "../app/BrandLogo";
import { useRouteNavigate } from "../app/RouteTransition";
import { externalProviderLabels } from "./ExternalLoginMethods";
function flowError(code) {
    switch (code) {
        case "session_present":
        case "session_changed": return "此浏览器的登录已改变。请继续当前资料库，或退出后重新开始。";
        case "binding_conflict": return "该账号无法绑定到这个邮箱。请使用原有登录方式，或重新开始。";
        case "provider_unavailable": return "此登录方式暂不可用，请使用邮箱登录或稍后重试。";
        case "email_delivery_unavailable": return "验证码暂时无法发送，请稍后重试。";
        case "verification_failed": return "验证码无效或已过期，请重新输入或重新发送。";
        default: return "登录流程未完成或已失效，请重新开始。";
    }
}
export function ExternalLoginPage({ loadPending = getExternalLoginPending, probeSession = probeLoginSession, requestCode = requestExternalLoginCode, verify = verifyExternalLogin, cancel = cancelExternalLogin, signOut = logout, onAuthenticated, onSignedOut, onAnonymous, }) {
    const navigate = useRouteNavigate();
    const [context, setContext] = useState(null);
    const [checking, setChecking] = useState(true);
    const [email, setEmail] = useState("");
    const [code, setCode] = useState("");
    const [step, setStep] = useState("email");
    const [error, setError] = useState(null);
    const [reconciling, setReconciling] = useState(false);
    const mounted = useRef(false);
    const generation = useRef(0);
    const activeRequest = useRef(null);
    const busy = useRef(false);
    const flowVersion = useRef(null);
    function begin() {
        activeRequest.current?.abort();
        const controller = new AbortController();
        activeRequest.current = controller;
        busy.current = true;
        return { generation: ++generation.current, signal: controller.signal };
    }
    function current(request) {
        return mounted.current && generation.current === request.generation && !request.signal.aborted;
    }
    function activate(session) {
        setCode("");
        setEmail("");
        if (onAuthenticated)
            onAuthenticated(session);
        else
            navigate("/library", { replace: true });
    }
    async function refresh(recovering = false, preserveError = false) {
        const request = begin();
        setChecking(true);
        try {
            // Check the flow against the Cookie visible after this Session read.
            // Parallel reads can pair an old completed flow with a newer account
            // using the same provider, whose public Session has no account ID.
            const session = await probeSession(request.signal);
            if (!current(request))
                return;
            const flow = await loadPending(request.signal);
            if (!current(request))
                return;
            if (!session)
                onAnonymous?.();
            if (!current(request))
                return;
            const version = `${flow.provider ?? ""}:${flow.expires_at ?? ""}`;
            if (flowVersion.current !== version) {
                setEmail("");
                setCode("");
                setStep("email");
            }
            flowVersion.current = version;
            setContext({ flow, session });
            setReconciling(false);
            if (flow.status === "completed" && session && flow.provider === session.login_channel && !flow.error_code) {
                activate(session);
            }
            else if (recovering) {
                setCode("");
                setError(flow.status === "email_required" && !session
                    ? "绑定尚未完成。请重新输入验证码后重试。"
                    : flow.status === "completed" && !session
                        ? "绑定已完成，请重新选择该登录方式进入资料库。"
                        : flowError(flow.error_code));
            }
            else if (!preserveError) {
                setError(null);
            }
        }
        catch {
            if (current(request))
                setError("无法确认登录结果，请检查网络后重新检查。");
        }
        finally {
            if (current(request)) {
                setChecking(false);
                busy.current = false;
            }
        }
    }
    useEffect(() => {
        mounted.current = true;
        void refresh();
        function recheck() { if (!busy.current)
            void refresh(); }
        window.addEventListener("focus", recheck);
        window.addEventListener("pageshow", recheck);
        return () => {
            mounted.current = false;
            generation.current += 1;
            activeRequest.current?.abort();
            window.removeEventListener("focus", recheck);
            window.removeEventListener("pageshow", recheck);
        };
        // The injected transport functions define this observer's lifetime.
    }, [loadPending, probeSession]);
    const codeRequest = useMutation({
        gcTime: 0, retry: false,
        mutationFn: ({ address, request }) => requestCode(address, request.signal),
        onSuccess: (_response, { request }) => {
            if (!current(request))
                return;
            setStep("code");
            setCode("");
            setError(null);
        },
        onError: (failure, { request }) => {
            if (!current(request))
                return;
            setError(failure instanceof ApiError ? flowError(failure.code) : "验证码请求未完成，请检查网络后重试。");
            if (failure instanceof ApiError && ["flow_invalid", "session_changed", "provider_unavailable"].includes(failure.code))
                void refresh(false, true);
        },
        onSettled: (_data, _failure, { request }) => { if (current(request))
            busy.current = false; },
    });
    const binding = useMutation({
        gcTime: 0, retry: false,
        mutationFn: ({ input, request }) => verify(input, request.signal),
        onSuccess: (session, { request }) => { if (current(request))
            activate(session); },
        onError: (failure, { request }) => {
            if (!current(request))
                return;
            if (failure instanceof ApiError && failure.code === "verification_failed") {
                setError(flowError(failure.code));
                return;
            }
            // A lost response may follow a committed binding. Never resend blindly.
            setReconciling(true);
            setError("正在核对绑定结果…");
            void refresh(true);
        },
        onSettled: (_data, _failure, { request }) => { if (current(request))
            busy.current = false; },
    });
    const cancellation = useMutation({
        gcTime: 0, retry: false,
        mutationFn: ({ request, switching }) => (switching && context?.flow.status === "expired" ? Promise.resolve() : cancel(request.signal))
            .then(async () => { if (switching && current(request))
            await signOut(); }),
        onSuccess: (_data, { request, switching }) => {
            if (!current(request))
                return;
            setEmail("");
            setCode("");
            if (switching && onSignedOut)
                onSignedOut();
            else
                navigate("/login", { replace: true });
        },
        onError: (_failure, { request }) => { if (current(request)) {
            setError("操作未完成，当前登录仍保留。请重新检查后重试。");
            void refresh(false, true);
        } },
        onSettled: (_data, _failure, { request }) => { if (current(request))
            busy.current = false; },
    });
    function sendCode(event) {
        event.preventDefault();
        if (busy.current)
            return;
        const address = email.trim();
        if (!address.includes("@") || address.length < 3) {
            setError("请输入有效的邮箱地址。");
            return;
        }
        setError(null);
        codeRequest.mutate({ address, request: begin() });
    }
    function submitBinding(event) {
        event.preventDefault();
        if (busy.current || reconciling || context?.session)
            return;
        if (!/^\d{6}$/.test(code.trim())) {
            setError("请输入 6 位数字验证码。");
            return;
        }
        setError(null);
        binding.mutate({ input: { email: email.trim(), code: code.trim(), confirm_binding: true }, request: begin() });
    }
    function cancelFlow(switching = false) {
        if (busy.current)
            return;
        if (!switching && context && ["expired", "cancelled", "failed"].includes(context.flow.status)) {
            navigate("/login", { replace: true });
            return;
        }
        cancellation.mutate({ request: begin(), switching });
    }
    function resendCode() {
        if (busy.current)
            return;
        codeRequest.mutate({ address: email.trim(), request: begin() });
    }
    const pending = checking || codeRequest.isPending || binding.isPending || cancellation.isPending;
    const flow = context?.flow;
    const provider = flow?.provider ? externalProviderLabels[flow.provider] : "所选账号";
    const expired = flow?.expires_at ? Date.parse(flow.expires_at) <= Date.now() : false;
    const canBind = flow?.status === "email_required" && !flow.error_code && !context?.session && !expired;
    const terminal = flow && !["created", "exchanging", "email_required"].includes(flow.status);
    return (_jsx("main", { className: "login-page", children: _jsxs("section", { className: "login-card external-login-card", "aria-labelledby": "external-login-title", "aria-busy": pending, children: [_jsxs("a", { className: "wordmark", href: "/", "aria-label": "\u641C\u85CF\u52A9\u624B\u9996\u9875", children: [_jsx(BrandLogo, { className: "wordmark__sigil" }), _jsx("span", { children: "StashSeek Chat" })] }), _jsxs("h1", { id: "external-login-title", children: ["\u5B8C\u6210", provider, "\u767B\u5F55"] }), checking ? _jsx("p", { role: "status", children: "\u6B63\u5728\u786E\u8BA4\u767B\u5F55\u7ED3\u679C\u2026" }) : null, error ? _jsx("p", { className: "inline-error", role: "alert", children: error }) : null, !checking && !context ? _jsx("button", { className: "button button--primary button--wide", type: "button", onClick: () => void refresh(reconciling), children: "\u91CD\u65B0\u68C0\u67E5" }) : null, context?.session && !checking ? (_jsxs("div", { className: "external-session-notice", children: [_jsx("p", { role: "status", children: flowError(flow?.error_code === "session_changed" ? "session_changed" : "session_present") }), _jsx("button", { className: "button button--primary button--wide", type: "button", onClick: () => activate(context.session), children: "\u7EE7\u7EED\u5F53\u524D\u8D44\u6599\u5E93" }), _jsx("button", { className: "login-back-button", type: "button", disabled: pending, onClick: () => cancelFlow(true), children: "\u9000\u51FA\u540E\u91CD\u65B0\u5F00\u59CB" })] })) : null, canBind && !reconciling && !checking ? (_jsxs(_Fragment, { children: [_jsxs("p", { className: "external-binding-purpose", children: ["\u9A8C\u8BC1\u90AE\u7BB1\u5E76\u5C06", provider, "\u7ED1\u5B9A\u5230\u8BE5\u90AE\u7BB1\u7684\u8D44\u6599\u5E93\u3002\u5DF2\u6709\u6536\u85CF\u548C\u68C0\u7D22\u8BB0\u5F55\u4F1A\u4FDD\u7559\uFF0C\u4E4B\u540E\u53EF\u76F4\u63A5\u4F7F\u7528\u6B64\u767B\u5F55\u65B9\u5F0F\u3002"] }), step === "email" ? (_jsxs("form", { className: "email-login-form", onSubmit: sendCode, noValidate: true, children: [_jsxs("div", { className: "field", children: [_jsx("label", { htmlFor: "external-email", children: "\u8D44\u6599\u5E93\u90AE\u7BB1" }), _jsx("input", { id: "external-email", type: "email", autoComplete: "email", required: true, value: email, disabled: pending, onChange: (event) => setEmail(event.target.value) })] }), _jsx("button", { className: "button button--primary button--wide", type: "submit", disabled: pending, children: "\u83B7\u53D6\u9A8C\u8BC1\u7801" })] })) : (_jsxs("form", { className: "email-login-form", onSubmit: submitBinding, noValidate: true, children: [_jsxs("p", { id: "external-binding-target", className: "email-login-confirmation", children: ["\u5C06", provider, "\u7ED1\u5B9A\u5230 ", _jsx("strong", { children: email.trim() }), " \u7684\u8D44\u6599\u5E93\u3002\u63D0\u4EA4\u5373\u9A8C\u8BC1\u5E76\u7ED1\u5B9A\u3002"] }), _jsxs("div", { className: "field", children: [_jsx("label", { htmlFor: "external-code", children: "6 \u4F4D\u9A8C\u8BC1\u7801" }), _jsx("input", { id: "external-code", type: "text", inputMode: "numeric", autoComplete: "one-time-code", maxLength: 6, "aria-describedby": "external-binding-target", value: code, disabled: pending, onChange: (event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6)) })] }), _jsx("button", { className: "button button--primary button--wide", type: "submit", disabled: pending, children: binding.isPending ? "正在验证并绑定…" : "验证并绑定" }), _jsxs("div", { className: "external-login-actions", children: [_jsx("button", { className: "login-back-button", type: "button", disabled: pending, onClick: () => { setStep("email"); setCode(""); setError(null); codeRequest.reset(); binding.reset(); }, children: "\u66F4\u6362\u90AE\u7BB1" }), _jsx("button", { className: "login-back-button", type: "button", disabled: pending, onClick: resendCode, children: "\u91CD\u65B0\u53D1\u9001\u9A8C\u8BC1\u7801" })] })] }))] })) : null, reconciling && !checking ? _jsx("button", { className: "button button--primary button--wide", type: "button", onClick: () => void refresh(true), children: "\u91CD\u65B0\u68C0\u67E5\u7ED3\u679C" }) : null, !checking && !context?.session && (terminal || expired || (flow?.error_code && !canBind)) ? (_jsx("p", { role: "status", children: flow?.status === "completed" ? "绑定已完成，请重新选择该登录方式进入资料库。" : flowError(flow?.error_code) })) : null, !checking && flow && ["created", "exchanging"].includes(flow.status) ? _jsx("p", { role: "status", children: "\u6388\u6743\u5C1A\u672A\u5B8C\u6210\u3002\u8BF7\u5B8C\u6210\u6388\u6743\u540E\u91CD\u65B0\u68C0\u67E5\uFF0C\u6216\u53D6\u6D88\u5E76\u91CD\u65B0\u5F00\u59CB\u3002" }) : null, flow && !context?.session ? _jsx("button", { className: "login-back-button", type: "button", disabled: pending, onClick: () => cancelFlow(), children: "\u53D6\u6D88\u5E76\u8FD4\u56DE\u767B\u5F55" }) : null, !checking && flow && !canBind ? _jsx("button", { className: "text-button", type: "button", disabled: pending, onClick: () => void refresh(reconciling), children: "\u91CD\u65B0\u68C0\u67E5" }) : null, _jsx("p", { className: "privacy-note", children: "\u90AE\u7BB1\u548C\u9A8C\u8BC1\u7801\u4EC5\u5728\u672C\u9875\u5185\u4F7F\u7528\u3002\u672A\u5B8C\u6210\u9A8C\u8BC1\u4E0E\u7ED1\u5B9A\u524D\u4E0D\u4F1A\u8FDB\u5165\u8D44\u6599\u5E93\u3002" })] }) }));
}
