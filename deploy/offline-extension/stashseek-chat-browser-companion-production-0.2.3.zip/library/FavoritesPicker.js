import { jsxs as _jsxs, jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError, previewBilibiliFavorites, previewBilibiliParts } from "../api/client";
import { PartImportControls, PartRows, PartSelectionToolbar, partsPreviewError } from "./PartsPicker";
import { addLoadedParts, refreshSelectedParts } from "./partSelection";
function favoritesError(error) {
    if (error instanceof ApiError) {
        if (error.code === "bilibili_limit_exceeded")
            return "收藏夹返回的数据超过预览范围，请稍后再试。";
        if (error.status === 429)
            return "预览请求过于频繁，请稍后再试。";
        if (error.code === "bilibili_invalid_favorites_url" || error.code === "bilibili_invalid_url" || error.status === 422)
            return "请输入公开 B 站收藏夹链接（favlist?fid=… 或 medialist/detail/ml…）。";
        if (error.code === "bilibili_favorites_private")
            return "这个收藏夹需要 B 站账号访问；当前只支持公开收藏夹。";
        if (error.code === "bilibili_unavailable")
            return "无法读取这个公开收藏夹，它可能私密、已删除或暂时不可访问。";
    }
    return "收藏夹暂时无法读取，请稍后重新预览。";
}
function ExpandedParts({ video, selected, onChange, onLoaded, onRefresh, disabled, previewParts }) {
    const [page, setPage] = useState(1);
    const mounted = useRef(true);
    const title = video.title ?? video.bvid ?? "未命名视频";
    const parts = useQuery({
        queryKey: ["bilibili-favorites-parts", video.bvid, page],
        queryFn: ({ signal }) => previewParts({ url: video.canonical_url, page }, signal),
        retry: false, gcTime: 0,
    });
    useEffect(() => {
        onLoaded(video.entry_key, parts.data && !parts.isError && !parts.isFetching ? { parent: title, parts: parts.data.parts } : null);
        return () => onLoaded(video.entry_key, null);
    }, [onLoaded, video.entry_key, title, parts.data, parts.isError, parts.isFetching]);
    useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
    async function refreshRefs() {
        const result = await parts.refetch();
        if (!mounted.current || result.isError || !result.data)
            return;
        onRefresh(result.data.parts.map((part) => ({ part, parentTitle: title, allowLegacyOverlap: false })));
    }
    return _jsxs("div", { className: "favorite-parts", "aria-label": `${title}的展开内容`, children: [parts.isFetching ? _jsxs("p", { role: "status", children: ["\u6B63\u5728\u8BFB\u53D6 ", title, " \u7684\u5206 P\u2026"] }) : null, parts.isError ? _jsx("p", { role: "alert", className: "inline-error", children: partsPreviewError(parts.error) }) : null, parts.data && !parts.isError ? _jsxs(_Fragment, { children: [_jsxs("p", { children: [parts.data.total_parts, " \u4E2A\u5206 P \u00B7 \u5206 P \u7B2C ", parts.data.page, " \u9875 / ", Math.max(1, Math.ceil(parts.data.total_parts / 20)), " \u9875"] }), _jsx(PartRows, { parts: parts.data.parts, parentTitle: title, selected: selected, onChange: onChange, disabled: disabled || parts.isFetching }), parts.data.parts.length === 0 ? _jsx("p", { children: "\u6CA1\u6709\u53EF\u663E\u793A\u7684\u5206 P\u3002" }) : null, _jsxs("nav", { className: "pagination", "aria-label": `${title}的分 P 分页`, children: [_jsx("button", { type: "button", className: "button button--quiet", disabled: disabled || parts.isFetching || page <= 1, onClick: () => setPage((value) => value - 1), children: "\u5206 P \u4E0A\u4E00\u9875" }), _jsx("button", { type: "button", className: "button button--quiet", disabled: disabled || parts.isFetching || !parts.data.has_more, onClick: () => setPage((value) => value + 1), children: "\u5206 P \u4E0B\u4E00\u9875" })] })] }) : null, _jsx("button", { type: "button", className: "text-button", disabled: disabled || parts.isFetching, onClick: () => void refreshRefs(), children: "\u5237\u65B0\u8BE5\u89C6\u9891\u5F53\u524D\u9875\u7684\u5206 P \u51ED\u636E" })] });
}
export function FavoritesPicker({ whySaved, destinationError, onSubmitted, onBusy, previewFavorites = previewBilibiliFavorites, previewParts = previewBilibiliParts, submitParts }) {
    const queryClient = useQueryClient();
    const [draft, setDraft] = useState("");
    const [url, setUrl] = useState("");
    const [page, setPage] = useState(1);
    const [revision, setRevision] = useState(0);
    const [selected, setSelected] = useState([]);
    const [opened, setOpened] = useState(new Set());
    const [loaded, setLoaded] = useState(new Map());
    const [locked, setLocked] = useState(false);
    const [selectionError, setSelectionError] = useState(null);
    const confirmation = useRef(null);
    const preview = useQuery({
        queryKey: ["bilibili-favorites-preview", url, page],
        queryFn: ({ signal }) => previewFavorites({ url, page }, signal),
        enabled: Boolean(url), retry: false, gcTime: 0,
    });
    useEffect(() => () => {
        for (const resource of ["bilibili-favorites-preview", "bilibili-favorites-parts"]) {
            void queryClient.cancelQueries({ queryKey: [resource] });
            queryClient.removeQueries({ queryKey: [resource] });
        }
    }, [queryClient]);
    const publishLoaded = useCallback((key, value) => {
        setLoaded((current) => {
            if (current.get(key) === value || (!value && !current.has(key)))
                return current;
            const next = new Map(current);
            if (value)
                next.set(key, value);
            else
                next.delete(key);
            return next;
        });
    }, []);
    function changeSelection(values) { setSelectionError(null); setSelected(values); }
    function changeLock(value) { setLocked(value); onBusy?.(value); }
    function refreshSelected(values) { setSelected((current) => refreshSelectedParts(current, values)); }
    function readFavorites() {
        if (locked || !draft.trim())
            return;
        void queryClient.cancelQueries({ queryKey: ["bilibili-favorites-preview", url] });
        void queryClient.cancelQueries({ queryKey: ["bilibili-favorites-parts"] });
        setSelected([]);
        setOpened(new Set());
        setLoaded(new Map());
        setSelectionError(null);
        setRevision((value) => value + 1);
        setPage(1);
        if (draft.trim() === url && page === 1)
            void preview.refetch();
        else
            setUrl(draft.trim());
    }
    function navigatePage(next) {
        setOpened(new Set());
        setLoaded(new Map());
        setSelectionError(null);
        setPage(next);
    }
    const visibleLoaded = (preview.data?.items ?? []).flatMap((video) => {
        const data = loaded.get(video.entry_key);
        return opened.has(video.entry_key) && data ? data.parts.map((part) => ({ part, parentTitle: data.parent, allowLegacyOverlap: false })) : [];
    });
    const eligibleLoaded = visibleLoaded.filter((value) => value.part.selectable && value.part.part_ref);
    function selectDisplayed() {
        const next = addLoadedParts(selected, eligibleLoaded);
        if (next === null)
            setSelectionError("本页已显示分 P 加入后会超过 10 项，原选择已保留，请减少选择。");
        else
            changeSelection(next);
    }
    return _jsxs("section", { className: "favorites-picker", "aria-label": "\u5BFC\u5165\u516C\u5F00 B \u7AD9\u6536\u85CF\u5939", children: [_jsx(PartSelectionToolbar, { count: selected.length, onConfirm: () => {
                    confirmation.current?.scrollIntoView({ block: "start", behavior: "instant" });
                    confirmation.current?.focus({ preventScroll: true });
                } }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "\u516C\u5F00 B \u7AD9\u6536\u85CF\u5939\u94FE\u63A5" }), _jsx("input", { value: draft, maxLength: 2048, autoComplete: "off", disabled: locked, placeholder: "https://space.bilibili.com/\u2026/favlist?fid=\u2026", onChange: (event) => setDraft(event.target.value) })] }), _jsx("button", { type: "button", className: "button button--quiet", disabled: locked || !draft.trim(), onClick: readFavorites, children: "\u9884\u89C8\u6536\u85CF\u5939\uFF08\u6E05\u7A7A\u539F\u9009\u62E9\uFF09" }), _jsx("p", { className: "field-help", children: "\u4EC5\u652F\u6301\u516C\u5F00\u6536\u85CF\u5939\u3002\u5148\u5C55\u5F00\u89C6\u9891\u518D\u9009\u62E9\u5206 P\uFF1B\u9884\u89C8\u4E0D\u4F1A\u4FDD\u5B58\u6216\u6574\u7406\u89C6\u9891\uFF0C\u53EF\u8BFB\u53D6\u5217\u8868\u4E0D\u4EE3\u8868\u6709\u53EF\u7528\u5B57\u5E55\u3002" }), preview.isFetching ? _jsx("p", { role: "status", children: "\u6B63\u5728\u8BFB\u53D6\u6536\u85CF\u5939\u2026" }) : null, preview.isError ? _jsx("p", { role: "alert", className: "inline-error", children: favoritesError(preview.error) }) : null, preview.data && !preview.isError ? _jsxs(_Fragment, { children: [_jsx("h3", { children: preview.data.title ?? "未命名收藏夹" }), _jsxs("p", { children: ["\u6536\u85CF\u5939\u62A5\u544A ", preview.data.reported_total, " \u4E2A\u6761\u76EE \u00B7 \u5F53\u524D\u7B2C ", preview.data.page, " \u9875\uFF08\u6BCF\u9875\u6700\u591A 20 \u6761\uFF09"] }), _jsx("p", { className: "field-help", children: "\u8FDC\u7AEF\u5217\u8868\u53EF\u80FD\u53D8\u5316\uFF0C\u5DF2\u9009\u5206 P \u4F1A\u8DE8\u9875\u4FDD\u7559\uFF1B\u672A\u5C55\u5F00\u7684\u5206 P \u4E0D\u4F1A\u52A0\u5165\u9009\u62E9\u3002" }), preview.data.capped ? _jsx("p", { role: "status", children: "\u5DF2\u5230\u7B2C 500 \u9875\u9884\u89C8\u4E0A\u9650\uFF0C\u5269\u4F59\u6761\u76EE\u5C1A\u672A\u8BFB\u53D6\u3002" }) : null, preview.data.items.length === 0 ? _jsx("p", { children: "\u8FD9\u4E2A\u516C\u5F00\u6536\u85CF\u5939\u5F53\u524D\u6CA1\u6709\u6761\u76EE\u3002" }) : null, _jsx("ul", { className: "favorite-video-list", "aria-label": "\u6536\u85CF\u5939\u89C6\u9891", children: preview.data.items.map((video) => _jsx("li", { children: video.available && video.bvid && video.canonical_url ? _jsxs("details", { open: opened.has(video.entry_key), onToggle: (event) => {
                                    const open = event.currentTarget.open;
                                    setOpened((current) => { const next = new Set(current); if (open)
                                        next.add(video.entry_key);
                                    else
                                        next.delete(video.entry_key); return next; });
                                }, children: [_jsxs("summary", { children: [video.title ?? video.bvid, " ", _jsxs("small", { children: [video.bvid, " \u00B7 \u5C55\u5F00\u5206 P"] })] }), opened.has(video.entry_key) ? _jsx(ExpandedParts, { video: video, selected: selected, onChange: changeSelection, onLoaded: publishLoaded, onRefresh: refreshSelected, disabled: locked, previewParts: previewParts }, `${revision}:${video.entry_key}`) : null] }) : _jsxs("div", { children: [_jsx("strong", { children: video.title ?? "不可用条目" }), _jsx("p", { className: "field-help", children: "\u8FD9\u4E2A\u6761\u76EE\u5DF2\u5931\u6548\u3001\u4E0D\u662F\u89C6\u9891\u6216\u65E0\u6CD5\u786E\u8BA4\u89C6\u9891\u4FE1\u606F\uFF0C\u4E0D\u80FD\u5BFC\u5165\u3002" })] }) }, video.entry_key)) }), _jsxs("div", { className: "add-mode-options", children: [_jsx("button", { type: "button", className: "button button--quiet", disabled: locked || eligibleLoaded.length === 0, onClick: selectDisplayed, children: "\u9009\u62E9\u672C\u9875\u5DF2\u663E\u793A\u5206 P" }), _jsx("button", { type: "button", className: "button button--quiet", disabled: locked || eligibleLoaded.length === 0, onClick: () => {
                                    const keys = new Set(visibleLoaded.map((value) => value.part.part_key));
                                    changeSelection(selected.filter((value) => !keys.has(value.part.part_key)));
                                }, children: "\u53D6\u6D88\u672C\u9875\u5DF2\u663E\u793A\u5206 P \u9009\u62E9" })] }), _jsxs("nav", { className: "pagination", "aria-label": "\u6536\u85CF\u5939\u5206\u9875", children: [_jsx("button", { type: "button", className: "button button--quiet", disabled: locked || preview.isFetching || preview.data.page <= 1, onClick: () => navigatePage(preview.data.page - 1), children: "\u6536\u85CF\u5939\u4E0A\u4E00\u9875" }), _jsx("button", { type: "button", className: "button button--quiet", disabled: locked || preview.isFetching || !preview.data.has_more || preview.data.capped, onClick: () => navigatePage(preview.data.page + 1), children: "\u6536\u85CF\u5939\u4E0B\u4E00\u9875" })] })] }) : null, selectionError ? _jsx("p", { className: "inline-error", role: "alert", children: selectionError }) : null, _jsx("div", { ref: confirmation, className: "parts-confirmation-target", tabIndex: -1, role: "region", "aria-label": "\u5206 P \u9009\u62E9\u4E0E\u786E\u8BA4", children: _jsx(PartImportControls, { selected: selected, onChange: changeSelection, whySaved: whySaved, showCount: false, destinationError: destinationError, onSubmitted: onSubmitted, onBusy: changeLock, submitParts: submitParts }, revision) })] });
}
