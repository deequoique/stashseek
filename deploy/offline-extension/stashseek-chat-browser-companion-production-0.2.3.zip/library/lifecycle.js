export function shouldPollLibrary(items) {
    return items.some(({ lifecycle }) => lifecycle === "queued" || lifecycle === "processing");
}
const workItemProgress = {
    queued: 20,
    processing: 65,
};
export function isLibraryWorkItem(item) {
    return ["queued", "processing", "needs_action", "failed"].includes(item.lifecycle);
}
export function estimateWorkItemProgress(items) {
    const activeItems = items.filter(({ lifecycle }) => lifecycle === "queued" || lifecycle === "processing");
    if (activeItems.length === 0)
        return 0;
    const total = activeItems.reduce((sum, item) => sum + (workItemProgress[item.lifecycle] ?? 0), 0);
    return Math.round(total / activeItems.length);
}
