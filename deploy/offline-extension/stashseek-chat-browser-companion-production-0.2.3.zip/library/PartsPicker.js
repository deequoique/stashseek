import { jsxs as _jsxs, jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ApiError, previewBilibiliParts, submitBilibiliParts } from "../api/client";
export function partLabel(value) {
    return `${value.parentTitle} · P${value.part.page} ${value.part.title ?? "未命名分 P"}`;
}
export function PartSelectionToolbar({ count, onConfirm }) {
    return _jsxs("div", { className: "part-selection-toolbar", "aria-label": "\u5206 P \u9009\u62E9\u72B6\u6001", children: [_jsxs("p", { className: "parts-selection-count", "aria-live": "polite", children: ["\u5DF2\u9009 ", count, " / 10 \u4E2A\u5206 P"] }), _jsx("button", { type: "button", className: "button button--quiet", disabled: count === 0, onClick: onConfirm, children: "\u67E5\u770B\u9009\u62E9\u4E0E\u786E\u8BA4" })] });
}
/** Shared controlled rows: expanding a video never implicitly selects a part. */
export function PartRows({ parts, parentTitle, selected, onChange, disabled = false }) {
    return _jsx("ol", { className: "part-list", "aria-label": `${parentTitle}的分 P`, children: parts.map((part) => {
            const chosen = selected.find((value) => value.part.part_key === part.part_key);
            const label = partLabel({ part, parentTitle, allowLegacyOverlap: false });
            return _jsxs("li", { children: [_jsxs("label", { className: "part-choice", children: [_jsx("input", { type: "checkbox", checked: Boolean(chosen), disabled: disabled || !part.selectable || !part.part_ref || (!chosen && selected.length >= 10), onChange: () => onChange(chosen
                                    ? selected.filter((value) => value.part.part_key !== part.part_key)
                                    : [...selected, { part: { ...part }, parentTitle, allowLegacyOverlap: false }]) }), _jsxs("span", { children: [label, part.duration_sec != null ? _jsxs("small", { children: [" \u00B7 ", part.duration_sec, " \u79D2"] }) : null] })] }), !part.selectable ? _jsx("p", { className: "field-help", children: "\u8FD9\u4E2A\u5206 P \u6682\u65F6\u65E0\u6CD5\u9009\u62E9\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u6216\u7A0D\u540E\u518D\u8BD5\u3002" }) : null, part.has_unverified_legacy_item ? _jsxs("div", { className: "part-legacy-warning", children: [_jsx("p", { children: "\u8D44\u6599\u5E93\u4E2D\u6709\u8FD9\u4E2A\u89C6\u9891\u7684\u65E7\u8BB0\u5F55\uFF0C\u4F46\u65E0\u6CD5\u786E\u8BA4\u5B83\u5BF9\u5E94\u54EA\u4E2A\u5206 P\u3002\u6B64\u6B21\u4F1A\u53E6\u5B58\u4E00\u6761\u8BB0\u5F55\uFF0C\u65E7\u8BB0\u5F55\u548C\u5386\u53F2\u4FDD\u7559\u3002" }), chosen ? _jsxs("label", { className: "part-choice", children: [_jsx("input", { type: "checkbox", checked: chosen.allowLegacyOverlap, disabled: disabled, onChange: (event) => onChange(selected.map((value) => value.part.part_key === part.part_key
                                            ? { ...value, allowLegacyOverlap: event.target.checked } : value)) }), _jsxs("span", { children: ["\u6211\u4E86\u89E3\u5E76\u540C\u610F\u5C06 ", label, " \u5355\u72EC\u4FDD\u5B58"] })] }) : null] }) : null] }, part.part_key);
        }) });
}
const resultCopy = {
    queued: "已添加，等待整理", already_exists: "资料库中已有这个分 P",
    part_ref_invalid: "选择凭据已失效，请重新预览", part_ref_expired: "预览已过期，请重新预览",
    legacy_identity_unknown: "旧记录身份尚未确认，请重新预览并明确选择",
    quota_exceeded: "当前添加额度不足", queue_unavailable: "整理队列暂不可用，请查看资料库状态",
    create_failed: "添加没有完成，请稍后再试",
};
export function partsPreviewError(error) {
    if (error instanceof ApiError) {
        if (error.code === "bilibili_limit_exceeded")
            return "这个视频超过当前预览范围，无法完整读取分 P。";
        if (error.code === "bilibili_invalid_url" || error.code === "invalid_url" || error.code === "unsupported_url" || error.status === 422)
            return "请输入完整 BV 号或 B 站视频链接，可包含 ?p=2。";
        if (error.status === 429)
            return "预览请求过于频繁，请稍后再试。";
        if (error.code === "source_unavailable" || error.code === "bilibili_unavailable")
            return "无法读取公开分 P 列表，视频可能不可访问。";
    }
    return "分 P 列表暂时无法读取，请稍后重新预览。";
}
export function PartImportControls({ selected, onChange, whySaved, destinationError, onSubmitted, onBusy, showCount = true, submitParts = submitBilibiliParts }) {
    const [attempt, setAttempt] = useState(null);
    const [result, setResult] = useState(null);
    const [uncertain, setUncertain] = useState(false);
    const [busy, setBusy] = useState(false);
    const controller = useRef(null);
    const running = useRef(false);
    const generation = useRef(0);
    const [now, setNow] = useState(Date.now());
    const expiresAt = Math.min(...(attempt?.selection ?? selected).map((value) => value.part.expires_at == null ? Infinity : value.part.expires_at * 1000));
    const expired = expiresAt <= now;
    useEffect(() => {
        if (!Number.isFinite(expiresAt))
            return;
        const timer = window.setTimeout(() => setNow(Date.now()), Math.max(0, expiresAt - Date.now() + 50));
        return () => window.clearTimeout(timer);
    }, [expiresAt]);
    useEffect(() => () => {
        generation.current += 1;
        controller.current?.abort();
    }, []);
    async function submit(frozen) {
        if (running.current || expiresAt <= Date.now() || (!frozen && (selected.length === 0 || selected.length > 10 || destinationError)))
            return;
        if (!frozen && selected.some((value) => !value.part.part_ref || (value.part.has_unverified_legacy_item && !value.allowLegacyOverlap)))
            return;
        const next = frozen ?? {
            key: crypto.randomUUID(), selection: selected.map((value) => ({ ...value, part: { ...value.part } })),
            input: { selections: selected.map((value) => ({ part_ref: value.part.part_ref, allow_legacy_overlap: value.allowLegacyOverlap })), why_saved: whySaved },
        };
        running.current = true;
        const currentGeneration = generation.current;
        const abort = new AbortController();
        controller.current = abort;
        setAttempt(next);
        setBusy(true);
        setUncertain(false);
        onBusy?.(true);
        try {
            const response = await submitParts(next.input, next.key, abort.signal);
            if (generation.current !== currentGeneration || abort.signal.aborted)
                return;
            setResult({ selection: next.selection, response });
            const accepted = new Set(response.results.filter((value) => ["queued", "already_exists"].includes(value.status))
                .map((value) => next.selection[value.input_index]?.part.part_key));
            onChange(selected.filter((value) => !accepted.has(value.part.part_key)));
            setAttempt(null);
            onSubmitted();
        }
        catch {
            if (generation.current !== currentGeneration || abort.signal.aborted)
                return;
            setUncertain(true);
        }
        finally {
            if (generation.current === currentGeneration) {
                running.current = false;
                setBusy(false);
            }
        }
    }
    const locked = busy || uncertain;
    useEffect(() => { onBusy?.(locked); }, [locked, onBusy]);
    return _jsxs("section", { "aria-label": "\u786E\u8BA4\u5DF2\u9009\u5206 P", children: [showCount ? _jsxs("p", { className: "parts-selection-count", "aria-live": "polite", children: ["\u5DF2\u9009 ", selected.length, " / 10 \u4E2A\u5206 P"] }) : null, selected.length > 0 ? _jsx("ol", { className: "parts-selection-summary", "aria-label": "\u5DF2\u9009\u5206 P", children: selected.map((value) => _jsxs("li", { children: [_jsxs("div", { children: [partLabel(value), value.part.has_unverified_legacy_item ? _jsxs("div", { className: "part-legacy-warning", children: [_jsx("p", { children: "\u5DF2\u6709\u65E7 P1 \u8BB0\u5F55\uFF0C\u65E0\u6CD5\u786E\u8BA4\u5BF9\u5E94\u5206 P\uFF1B\u672C\u6B21\u4F1A\u65B0\u589E\u72EC\u7ACB\u5206 P \u8BB0\u5F55\uFF0C\u4FDD\u7559\u65E7\u8BB0\u5F55\u548C\u5386\u53F2\u3002" }), _jsxs("label", { className: "part-choice", children: [_jsx("input", { type: "checkbox", checked: value.allowLegacyOverlap, disabled: locked, onChange: (event) => onChange(selected.map((part) => part.part.part_key === value.part.part_key
                                                        ? { ...part, allowLegacyOverlap: event.target.checked } : part)) }), _jsxs("span", { children: ["\u5DF2\u9009\u9879\u76EE\u786E\u8BA4\uFF1A\u5C06 ", partLabel(value), " \u5355\u72EC\u4FDD\u5B58"] })] })] }) : null] }), _jsx("button", { type: "button", className: "text-button", disabled: locked, onClick: () => onChange(selected.filter((part) => part.part.part_key !== value.part.part_key)), children: "\u8DF3\u8FC7" })] }, value.part.part_key)) }) : null, selected.some((value) => value.part.has_unverified_legacy_item && !value.allowLegacyOverlap)
                ? _jsx("p", { role: "alert", className: "inline-error", children: "\u8BF7\u9010\u9879\u786E\u8BA4\u65E7\u8BB0\u5F55\u91CD\u53E0\u63D0\u793A\uFF0C\u6216\u8DF3\u8FC7\u8FD9\u4E9B\u5206 P\u3002" }) : null, destinationError ? _jsx("p", { role: "alert", className: "inline-error", children: destinationError }) : null, expired ? _jsx("p", { role: "alert", className: "inline-error", children: "\u90E8\u5206\u9009\u62E9\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u660E\u786E\u5237\u65B0\u5BF9\u5E94\u89C6\u9891\u7684\u5206 P \u51ED\u636E\u540E\u518D\u786E\u8BA4\u3002\u82E5\u4E0A\u6B21\u7ED3\u679C\u672A\u77E5\uFF0C\u8BF7\u5148\u67E5\u770B\u8D44\u6599\u5E93\u3002" }) : null, uncertain && attempt ? _jsxs("div", { role: "alert", className: "inline-error", children: [_jsx("p", { children: "\u672A\u80FD\u786E\u8BA4\u672C\u6B21\u7ED3\u679C\u3002\u90E8\u5206\u5206 P \u53EF\u80FD\u5DF2\u4FDD\u5B58\uFF0C\u53EF\u67E5\u770B\u8D44\u6599\u5E93\uFF1B\u91CD\u65B0\u786E\u8BA4\u4F1A\u6CBF\u7528\u672C\u6B21\u76F8\u540C\u9009\u62E9\u548C\u8BF7\u6C42\u3002" }), _jsx("p", { children: "\u53EF\u5173\u95ED\u6B64\u7A97\u53E3\u8FD4\u56DE\u8D44\u6599\u5E93\u6838\u5BF9\uFF1B\u5173\u95ED\u4E0D\u4F1A\u64A4\u9500\u5DF2\u63A5\u6536\u7684\u4EFB\u52A1\u3002" }), _jsx("button", { type: "button", className: "button button--quiet", disabled: busy || expired, onClick: () => void submit(attempt), children: "\u91CD\u65B0\u786E\u8BA4\u672C\u6B21\u7ED3\u679C" })] }) : null, result ? _jsx("ol", { className: "submission-results", "aria-label": "\u5206 P \u6DFB\u52A0\u7ED3\u679C", "aria-live": "polite", children: result.response.results.map((value) => {
                    const selectedPart = result.selection[value.input_index];
                    return _jsxs("li", { children: [_jsx("span", { children: selectedPart ? partLabel(selectedPart) : `第 ${value.input_index + 1} 项` }), _jsx("strong", { children: resultCopy[value.status] ?? "未能确认处理结果，请查看资料库" })] }, value.result_id);
                }) }) : null, _jsx("button", { type: "button", className: "button button--primary button--wide", disabled: locked || expired || selected.length === 0 || selected.length > 10 || Boolean(destinationError) || selected.some((value) => value.part.has_unverified_legacy_item && !value.allowLegacyOverlap), onClick: () => void submit(), children: busy ? "正在添加…" : `添加已选 ${selected.length} 个分 P` }), _jsx("p", { className: "field-help", children: "\u5173\u95ED\u7A97\u53E3\u4F1A\u6E05\u7A7A\u9009\u62E9\uFF1B\u5DF2\u6536\u5230\u7684\u6DFB\u52A0\u4EFB\u52A1\u4F1A\u7EE7\u7EED\u5904\u7406\u3002" })] });
}
export function PartsPicker({ whySaved, destinationError, onSubmitted, onBusy, initialUrl = "", previewParts = previewBilibiliParts, submitParts = submitBilibiliParts }) {
    const queryClient = useQueryClient();
    const [draft, setDraft] = useState(initialUrl);
    const [url, setUrl] = useState("");
    const [page, setPage] = useState();
    const [selected, setSelected] = useState([]);
    const [locked, setLocked] = useState(false);
    const [revision, setRevision] = useState(0);
    const confirmation = useRef(null);
    const preview = useQuery({
        queryKey: ["bilibili-parts-preview", url, page],
        queryFn: ({ signal }) => previewParts({ url, ...(page === undefined ? {} : { page }) }, signal),
        enabled: Boolean(url), retry: false, gcTime: 0,
    });
    useEffect(() => () => {
        void queryClient.cancelQueries({ queryKey: ["bilibili-parts-preview"] });
        queryClient.removeQueries({ queryKey: ["bilibili-parts-preview"] });
    }, [queryClient]);
    function loadPreview() {
        if (locked)
            return;
        setSelected([]);
        setRevision((value) => value + 1);
        setPage(undefined);
        const next = draft.trim();
        if (next === url && page === undefined)
            void preview.refetch();
        else
            setUrl(next);
    }
    function changeLock(value) { setLocked(value); onBusy?.(value); }
    return _jsxs("section", { className: "parts-picker", "aria-label": "\u9009\u62E9 B \u7AD9\u5206 P", children: [_jsx(PartSelectionToolbar, { count: selected.length, onConfirm: () => {
                    confirmation.current?.scrollIntoView({ block: "start", behavior: "instant" });
                    confirmation.current?.focus({ preventScroll: true });
                } }), _jsxs("label", { className: "field", children: [_jsx("span", { children: "B \u7AD9\u89C6\u9891 BV \u53F7\u6216\u94FE\u63A5" }), _jsx("input", { value: draft, maxLength: 2048, autoComplete: "off", disabled: locked, placeholder: "BV1xx411c7mD \u6216\u89C6\u9891\u94FE\u63A5 ?p=2", onChange: (event) => setDraft(event.target.value) })] }), _jsx("button", { type: "button", className: "button button--quiet", disabled: locked || !draft.trim(), onClick: loadPreview, children: "\u9884\u89C8\u5206 P\uFF08\u6E05\u7A7A\u539F\u9009\u62E9\uFF09" }), _jsx("p", { className: "field-help", children: "\u9884\u89C8\u4E0D\u4F1A\u4FDD\u5B58\u89C6\u9891\u3002\u5C55\u5F00\u540E\u52FE\u9009\u9700\u8981\u7684\u5206 P\uFF0C\u6BCF\u4E2A\u5206 P \u72EC\u7ACB\u6574\u7406\uFF1B\u53EF\u8BFB\u53D6\u5217\u8868\u4E0D\u4EE3\u8868\u4E00\u5B9A\u6709\u5B57\u5E55\u3002" }), preview.isFetching ? _jsx("p", { role: "status", children: "\u6B63\u5728\u8BFB\u53D6\u5206 P\u2026" }) : null, preview.isError ? _jsx("p", { role: "alert", className: "inline-error", children: partsPreviewError(preview.error) }) : null, preview.data && !preview.isError ? _jsxs(_Fragment, { children: [_jsx("h3", { children: preview.data.title ?? preview.data.bvid }), _jsxs("p", { children: [preview.data.total_parts, " \u4E2A\u5206 P \u00B7 \u7B2C ", preview.data.page, " \u9875", preview.data.requested_page ? ` · 链接指定 P${preview.data.requested_page}，请勾选确认` : ""] }), _jsx(PartRows, { parts: preview.data.parts, parentTitle: preview.data.title ?? preview.data.bvid, selected: selected, onChange: setSelected, disabled: locked }), preview.data.parts.length === 0 ? _jsx("p", { children: "\u6CA1\u6709\u53EF\u663E\u793A\u7684\u5206 P\u3002" }) : null, _jsxs("nav", { className: "pagination", "aria-label": "\u5206 P \u5206\u9875", children: [_jsx("button", { type: "button", className: "button button--quiet", disabled: locked || preview.isFetching || preview.data.page <= 1, onClick: () => setPage(preview.data.page - 1), children: "\u4E0A\u4E00\u9875" }), _jsx("button", { type: "button", className: "button button--quiet", disabled: locked || preview.isFetching || !preview.data.has_more, onClick: () => setPage(preview.data.page + 1), children: "\u4E0B\u4E00\u9875" })] })] }) : null, _jsx("div", { ref: confirmation, className: "parts-confirmation-target", tabIndex: -1, role: "region", "aria-label": "\u5206 P \u9009\u62E9\u4E0E\u786E\u8BA4", children: _jsx(PartImportControls, { selected: selected, onChange: setSelected, showCount: false, whySaved: whySaved, destinationError: destinationError, onSubmitted: onSubmitted, onBusy: changeLock, submitParts: submitParts }, revision) })] });
}
