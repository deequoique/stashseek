import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { ACTION_LABEL, LOGIN_REQUIRED_EXPLANATION, RETRY_NOT_USEFUL_HINT, reasonStatusLine, UNFINISHED_EXPLANATION, UNFINISHED_TITLE, UNSEARCHABLE_BADGE, UNSEARCHABLE_BADGE_DETAIL, } from "./ingestCopy";
/** The screen of an item whose body is not searchable: why, what still works, and what to do. */
export function IngestUnfinished({ title, platformName, reason, primary = null, onSearchTitles, error = null }) {
    const titleId = useId();
    const loginRequired = reason.category === "login_required";
    return (_jsxs("section", { className: "ingest-unfinished", "aria-labelledby": titleId, children: [_jsx("h2", { id: titleId, children: UNFINISHED_TITLE }), _jsxs("div", { className: "ingest-card", children: [_jsx("p", { className: "ingest-card__title", children: title?.trim() || "视频信息尚未准备好" }), _jsx("p", { className: "ingest-muted", children: platformName ? `${platformName} · 链接已保存` : "链接已保存" })] }), _jsx("p", { className: "ingest-status ingest-status--error", role: "status", children: reasonStatusLine(reason) }), _jsx("p", { className: "ingest-muted", children: loginRequired ? LOGIN_REQUIRED_EXPLANATION : UNFINISHED_EXPLANATION }), !loginRequired && !reason.retry_useful ? _jsx("p", { className: "ingest-muted", children: RETRY_NOT_USEFUL_HINT }) : null, error ? _jsx("p", { className: "inline-error ingest-error", role: "alert", children: error }) : null, primary || onSearchTitles ? (_jsxs("div", { className: "ingest-actions", children: [primary?.kind === "button" ? (_jsx("button", { className: "button button--primary", type: "button", disabled: primary.pending === true, "aria-busy": primary.pending === true, onClick: primary.onClick, children: primary.label })) : null, primary?.kind === "link" ? (_jsx("a", { className: "button button--primary", href: primary.href, target: "_blank", rel: "noreferrer", children: primary.label })) : null, onSearchTitles ? (_jsx("button", { className: "button button--quiet", type: "button", onClick: onSearchTitles, children: ACTION_LABEL.searchTitles })) : null] })) : null] }));
}
/** Marks an item whose body cannot be found by content search; its title and note still can. */
export function UnsearchableBadge({ detailed = false }) {
    return _jsx("span", { className: "ingest-badge", children: detailed ? UNSEARCHABLE_BADGE_DETAIL : UNSEARCHABLE_BADGE });
}
