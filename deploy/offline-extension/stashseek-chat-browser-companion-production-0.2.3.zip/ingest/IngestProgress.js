import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { BODY_DETAIL_LABEL, isKnownStageKey, PROGRESS_EXPLANATION, PROGRESS_TITLE, SAVED_LINK_STEP, SEARCHABLE_STATUS, STAGE_LABEL, STAGE_PLACEHOLDER, } from "./ingestCopy";
import { BODY_KEY, normalizeStages } from "./ingestModel";
const DONE = { glyph: "✓", className: "is-done", spoken: "已完成" };
const PENDING = { glyph: "○", className: "is-pending", spoken: "未开始" };
const MARKS = {
    done: DONE,
    running: { glyph: "◌", className: "is-running", spoken: "进行中" },
    pending: PENDING,
    failed: { glyph: "!", className: "is-failed", spoken: "未完成" },
};
function markOf(status) {
    return (Object.hasOwn(MARKS, status) ? MARKS[status] : undefined) ?? PENDING;
}
/** A waiting or running body stage says what it is doing; every other row uses its stage name. */
function rowText(stage) {
    if (!isKnownStageKey(stage.key))
        return stage.key;
    const label = STAGE_LABEL[stage.key];
    if (stage.key === BODY_KEY) {
        const waiting = stage.status === "pending" || stage.status === "running";
        const detail = waiting && stage.detail && Object.hasOwn(BODY_DETAIL_LABEL, stage.detail) ? BODY_DETAIL_LABEL[stage.detail] : null;
        return detail ?? label;
    }
    return stage.status === "failed" ? `${label} · ${STAGE_PLACEHOLDER[stage.key]}` : label;
}
/** The screen after 「收藏」: the item is saved, and each stage is done, running or not started. */
export function IngestProgress({ stages, searchable, note }) {
    const titleId = useId();
    const shown = normalizeStages(stages);
    const showSearchable = searchable ?? shown.some((stage) => stage.key === BODY_KEY && stage.status === "done");
    const running = shown.findIndex((stage) => stage.status === "running");
    const noteIndex = running >= 0 ? running : shown.findIndex((stage) => stage.status === "pending");
    return (_jsxs("section", { className: "ingest-progress", "aria-labelledby": titleId, children: [_jsx("p", { className: "eyebrow", children: "\u5185\u5BB9\u6574\u7406" }), _jsx("h2", { id: titleId, children: PROGRESS_TITLE }), _jsx("p", { className: "ingest-muted", children: PROGRESS_EXPLANATION }), _jsxs("ol", { className: "ingest-steps", "aria-label": "\u6574\u7406\u6B65\u9AA4", children: [_jsxs("li", { className: `ingest-step ${DONE.className}`, children: [_jsx("span", { className: "ingest-step__mark", "aria-hidden": "true", children: DONE.glyph }), _jsxs("span", { children: [SAVED_LINK_STEP, _jsxs("span", { className: "sr-only", children: ["\uFF0C", DONE.spoken] })] })] }), shown.map((stage, index) => {
                        const mark = markOf(stage.status);
                        return (_jsxs("li", { className: `ingest-step ${mark.className}`, children: [_jsx("span", { className: "ingest-step__mark", "aria-hidden": "true", children: mark.glyph }), _jsxs("span", { children: [rowText(stage), _jsxs("span", { className: "sr-only", children: ["\uFF0C", mark.spoken] }), note && index === noteIndex ? _jsx("span", { className: "ingest-step__note", children: note }) : null] })] }, stage.key));
                    })] }), showSearchable ? _jsx("p", { className: "ingest-status ingest-status--ready", role: "status", children: SEARCHABLE_STATUS }) : null] }));
}
