import { isReasonCategory } from "../ingest/ingestCopy";
import { allStagesSettled, BODY_KEY, isBodySearchable, isUnfinished, reasonOf, visibleStages } from "../ingest/ingestModel";
export const TERMINAL_OUTCOMES = new Set([
    "ready",
    "already_exists",
    "needs_action",
    "failed",
    "archived",
    "submitted",
    "timeout",
    "quota_exceeded",
    "unsupported_url",
    "unsupported_part",
    "submit_failed",
]);
export function newCollectEntry(id, videoKey, now) {
    return {
        kind: "collect",
        id,
        videoKey,
        phase: "reading",
        path: null,
        fallback: null,
        itemPublicId: null,
        startedAt: now,
        durationSec: null,
        segments: null,
        captionless: false,
        existing: false,
        stage: null,
        stageSince: null,
        workingStage: null,
        sawTranscribing: false,
        outcome: null,
        errorCode: null,
        retryable: false,
        stages: [],
        reason: null,
        bodySearchable: false,
        itemTitle: null,
        itemPlatform: null,
        retrying: false,
        retryState: "idle",
    };
}
/** The stages to draw for an entry; a tracked item not yet read is waiting in the queue. */
export function entryStages(entry) {
    return entry.stages.length > 0 ? entry.stages : visibleStages({ lifecycle: "queued" });
}
/** The entry of an unfinished item sent for another run: tracking again from a clean slate. */
export function restartTracking(entry, now) {
    return {
        ...newCollectEntry(entry.id, entry.videoKey, now),
        phase: "tracking",
        path: entry.path,
        fallback: entry.fallback,
        itemPublicId: entry.itemPublicId,
        durationSec: entry.durationSec,
        segments: entry.segments,
        captionless: entry.captionless,
        itemTitle: entry.itemTitle,
        itemPlatform: entry.itemPlatform,
    };
}
/** Ends the entry with an outcome that needs no further polling. */
export function finishEntry(entry, outcome, errorCode = null) {
    return { ...entry, phase: "done", outcome, errorCode: errorCode ?? entry.errorCode, retrying: false };
}
const WORKING_STAGES = new Set(["queued", "fetching", "transcribing", "chunking", "embedding"]);
export function isWorkingStage(stage) {
    return stage !== null && WORKING_STAGES.has(stage);
}
/** The stage of an item from a server that predates the `stage` field. */
function stageFromLifecycle(item, path) {
    if (item.lifecycle === "processing")
        return path === "capture" ? "chunking" : "fetching";
    return item.lifecycle;
}
const SIX_HOURS_MS = 6 * 60 * 60 * 1000;
/**
 * When a stage began. The first stage seen may predate the click (an item that was already being
 * processed), so the server's timestamp is used once, clamped to the past. Later stages begin when
 * the panel sees the change: the server timestamp is the dispatch time, which is older than any
 * stage after the first.
 */
function stageStart(item, first, now) {
    if (!first || !item.stage_updated_at)
        return now;
    const serverTime = Date.parse(item.stage_updated_at);
    return Number.isFinite(serverTime) && serverTime <= now && now - serverTime < SIX_HOURS_MS ? serverTime : now;
}
/**
 * The end of the entry, or null while it is still being followed. For a new collect a ready body is
 * not the end until every stage the server lists has finished; ready items without later stages end
 * at once. An item that was already in the library ends as soon as its body is ready: its later
 * stages may never run (items saved before they existed have no stage rows), so waiting would
 * poll until the cap.
 */
function outcomeFor(item, entry) {
    switch (item.lifecycle) {
        case "ready":
            if (entry.existing)
                return "already_exists";
            return allStagesSettled(item) ? "ready" : null;
        case "needs_action": return "needs_action";
        case "failed": return "failed";
        case "archived": return "archived";
        default: return null;
    }
}
/** Folds one library item read into the entry. */
export function applyItem(entry, item, now) {
    const stages = visibleStages(item);
    const reported = item.stage ?? stageFromLifecycle(item, entry.path);
    // `stage` keeps saying "fetching" while a URL import is transcribed; only the body stage knows.
    const transcribing = stages.some((candidate) => candidate.key === BODY_KEY && candidate.detail === "transcribing");
    const stage = reported === "fetching" && transcribing ? "transcribing" : reported;
    const changed = stage !== entry.stage;
    const next = {
        ...entry,
        retrying: false,
        durationSec: item.duration_sec ?? entry.durationSec,
        retryable: item.available_actions.includes("retry"),
        stages,
        reason: isUnfinished(item) ? reasonOf(item) : null,
        bodySearchable: isBodySearchable(item),
        itemTitle: item.title ?? entry.itemTitle,
        itemPlatform: item.platform || entry.itemPlatform,
        stage,
        stageSince: changed ? stageStart(item, entry.stage === null, now) : entry.stageSince,
    };
    if (isWorkingStage(stage)) {
        next.workingStage = stage;
        if (stage === "transcribing")
            next.sawTranscribing = true;
    }
    const outcome = outcomeFor(item, entry);
    if (outcome) {
        next.phase = "done";
        next.outcome = outcome;
        next.errorCode = item.error_code ?? null;
    }
    return next;
}
/** Changes whenever the panel has something new to show or keep for a reload. */
export function progressSignature(entry) {
    return `${entry.stage}|${entry.stages.map((stage) => `${stage.key}:${stage.status}:${stage.detail ?? ""}`).join(",")}`;
}
export function toStored(entry) {
    const stored = { ...entry };
    delete stored.retrying;
    delete stored.retryState;
    return stored;
}
const PATHS = new Set(["capture", "url"]);
const STAGES = new Set(["queued", "fetching", "transcribing", "chunking", "embedding", "ready", "needs_action", "failed", "archived"]);
const FALLBACKS = new Set(["read_failed", "no_captions", "not_paired", "capture_failed"]);
const STAGE_STATUSES = new Set(["pending", "running", "done", "failed", "skipped"]);
const STAGE_DETAILS = new Set(["queued", "fetching", "transcribing", "indexing"]);
function isStageStatus(value) {
    return STAGE_STATUSES.has(value);
}
function isStageDetail(value) {
    return STAGE_DETAILS.has(value);
}
function parseReason(value) {
    if (typeof value !== "object" || value === null)
        return null;
    const v = value;
    if (typeof v.code !== "string" || typeof v.category !== "string" || typeof v.retry_useful !== "boolean")
        return null;
    return { code: v.code, category: isReasonCategory(v.category) ? v.category : "error", retry_useful: v.retry_useful };
}
/** The stages of a stored entry; entries that are not well formed are left out. */
function parseStages(value) {
    if (!Array.isArray(value))
        return [];
    const items = value;
    const stages = [];
    for (const raw of items) {
        if (typeof raw !== "object" || raw === null)
            continue;
        const v = raw;
        if (typeof v.key !== "string" || !isStageStatus(v.status))
            continue;
        stages.push({ key: v.key, status: v.status, detail: isStageDetail(v.detail) ? v.detail : null, reason: parseReason(v.reason) });
    }
    return stages;
}
/** Restores a persisted entry, or null when the stored value is not a usable in-progress entry. */
export function parseStored(value) {
    if (typeof value !== "object" || value === null)
        return null;
    const v = value;
    const text = (key) => (typeof v[key] === "string" ? v[key] : null);
    const num = (key) => (typeof v[key] === "number" && Number.isFinite(v[key]) ? v[key] : null);
    const id = text("id");
    const videoKey = text("videoKey");
    const itemPublicId = text("itemPublicId");
    const startedAt = num("startedAt");
    if (!id || !videoKey || !itemPublicId || startedAt === null)
        return null;
    // Only an item that was being followed can resume; earlier phases leave nothing to follow.
    if (v.phase !== "tracking" || !PATHS.has(v.path))
        return null;
    const working = text("workingStage");
    return {
        ...newCollectEntry(id, videoKey, startedAt),
        phase: "tracking",
        path: v.path,
        fallback: FALLBACKS.has(v.fallback) ? v.fallback : null,
        itemPublicId,
        durationSec: num("durationSec"),
        segments: num("segments"),
        captionless: v.captionless === true,
        existing: v.existing === true,
        stage: STAGES.has(v.stage) ? v.stage : null,
        stageSince: num("stageSince"),
        workingStage: isWorkingStage(working) ? working : null,
        sawTranscribing: v.sawTranscribing === true,
        retryable: v.retryable === true,
        stages: parseStages(v.stages),
        reason: parseReason(v.reason),
        bodySearchable: v.bodySearchable === true,
        itemTitle: text("itemTitle"),
        itemPlatform: text("itemPlatform"),
    };
}
