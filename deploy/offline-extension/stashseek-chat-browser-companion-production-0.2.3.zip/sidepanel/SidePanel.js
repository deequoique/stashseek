import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback, useEffect, useState } from "react";
import { ApiError } from "../api/client";
import { defaultDeps } from "./deps";
import { errorCode, workerErrorCopy } from "./copy";
import { PageWorkspace } from "./PageWorkspace";
import { PanelLogin } from "./PanelLogin";
import { PrivacyLink } from "./PrivacyLink";
function withTimeout(promise, ms) {
    let timer;
    const timeout = new Promise((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error("request_timeout")), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
function Shell({ children }) {
    return (_jsxs("div", { className: "sp-shell", children: [_jsxs("header", { className: "sp-brand", children: [_jsx("span", { className: "sp-brand__mark", "aria-hidden": "true", children: _jsx("i", {}) }), _jsxs("div", { children: [_jsx("p", { className: "eyebrow", children: "STASHSEEK CHAT" }), _jsx("p", { className: "sp-brand__name", children: "\u641C\u85CF\u52A9\u624B" })] })] }), children] }));
}
/** Side panel root: login and device connection first, then the page view. */
export function SidePanel({ deps = defaultDeps }) {
    const [auth, setAuth] = useState({ phase: "checking" });
    const [paired, setPaired] = useState(false);
    const [pageQa, setPageQa] = useState(false);
    const [transcriptionPlatforms, setTranscriptionPlatforms] = useState([]);
    const [check, setCheck] = useState(0);
    useEffect(() => {
        let live = true;
        setAuth({ phase: "checking" });
        void (async () => {
            try {
                // STATUS first: the worker drops credentials that belong to another build target.
                const status = await deps.worker.status();
                if (!live)
                    return;
                setPaired(status.paired);
                await withTimeout(deps.getSession(), deps.requestTimeoutMs);
                const capabilities = await withTimeout(deps.getCapabilities(), deps.requestTimeoutMs);
                if (!live)
                    return;
                setPageQa(capabilities.page_qa === true);
                setTranscriptionPlatforms(capabilities.transcription_platforms ?? []);
                setAuth({ phase: "ready" });
            }
            catch (error) {
                if (!live)
                    return;
                if (error instanceof ApiError && error.status === 401) {
                    setAuth({ phase: "logged_out" });
                    return;
                }
                const code = error instanceof ApiError || error instanceof TypeError ? "network_unavailable" : errorCode(error);
                setAuth({ phase: "error", message: workerErrorCopy(code) });
            }
        })();
        return () => { live = false; };
    }, [deps, check]);
    const onSessionInvalid = useCallback(() => setAuth({ phase: "logged_out" }), []);
    const onLogout = useCallback(() => {
        void deps.worker.disconnect().catch(() => undefined).then(() => {
            setPaired(false);
            setAuth({ phase: "logged_out" });
        });
    }, [deps]);
    if (auth.phase === "checking") {
        return _jsx(Shell, { children: _jsx("p", { className: "sp-hint", role: "status", children: "\u6B63\u5728\u8FDE\u63A5\u641C\u85CF\u52A9\u624B\u2026" }) });
    }
    if (auth.phase === "error") {
        return (_jsxs(Shell, { children: [_jsx("p", { className: "sp-hint", role: "alert", children: auth.message }), _jsx("button", { className: "button button--quiet", type: "button", onClick: () => setCheck((value) => value + 1), children: "\u91CD\u8BD5" })] }));
    }
    if (auth.phase === "logged_out") {
        return (_jsxs(Shell, { children: [_jsxs("section", { className: "sp-intro", "aria-labelledby": "sp-login-title", children: [_jsx("h1", { id: "sp-login-title", children: "\u767B\u5F55\u641C\u85CF\u52A9\u624B" }), _jsx("p", { children: "\u767B\u5F55\u540E\uFF0C\u53EF\u4EE5\u76F4\u63A5\u5C31\u5F53\u524D\u89C6\u9891\u63D0\u95EE\uFF0C\u4E5F\u53EF\u4EE5\u628A\u5B57\u5E55\u4FDD\u5B58\u5230\u8D44\u6599\u5E93\u3002" })] }), _jsx(PanelLogin, { worker: deps.worker, onDone: () => setCheck((value) => value + 1) }), _jsx("footer", { className: "sp-footer", children: _jsx(PrivacyLink, { deps: deps }) })] }));
    }
    return (_jsx(PageWorkspace, { deps: deps, paired: paired, pageQa: pageQa, transcriptionPlatforms: transcriptionPlatforms, onPairedChange: setPaired, onSessionInvalid: onSessionInvalid, onLogout: onLogout }));
}
