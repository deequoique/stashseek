import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { MarkdownAnswer } from "../chat/MarkdownAnswer";
import { StepTimeline, useAutoCollapse } from "../chat/StepTimeline";
import { IngestProgress } from "../ingest/IngestProgress";
import { IngestUnfinished } from "../ingest/IngestUnfinished";
import { ACTION_LABEL, platformLabel, QUOTA_RETRY_COPY, RETRY_FAILED_COPY, TITLE_SEARCH_ROUTE } from "../ingest/ingestCopy";
import { entryStages } from "./collectModel";
import { formatTimestamp, panelAnswerText } from "./copy";
import { collectBody, collectNote, collectProgress, collectResult, collectSteps, collectSummary, collectWorkspacePath, qaSteps, qaSummary, } from "./steps";
function CitationChips({ citations, onOpen, }) {
    if (!citations.length)
        return null;
    return (_jsx("ol", { className: "sp-citations", "aria-label": "\u56DE\u7B54\u4F9D\u636E", children: citations.map((citation, index) => {
            const time = typeof citation.start_sec === "number" ? formatTimestamp(citation.start_sec) : null;
            return (_jsxs("li", { children: [_jsxs("button", { className: "sp-citation", type: "button", title: time ? `跳转到 ${time}` : "在新标签页打开", onClick: () => onOpen(citation), children: [_jsx("span", { className: "sp-citation__time", children: time ?? "打开" }), _jsx("span", { className: "sp-citation__title", children: citation.title })] }), _jsxs("details", { className: "sp-citation__excerpt", children: [_jsx("summary", { children: "\u5C55\u5F00\u5B57\u5E55\u4F9D\u636E" }), _jsx("p", { children: citation.excerpt })] })] }, `${citation.url}:${citation.start_sec ?? ""}:${index}`));
        }) }));
}
/** Client-side steps above a streamed answer; folds away once the answer starts. */
function TurnSteps({ turn }) {
    const steps = qaSteps(turn);
    const [expanded, setExpanded] = useAutoCollapse(turn.answer !== "" || turn.status !== "streaming");
    return (_jsx(StepTimeline, { className: "sp-timeline", summary: qaSummary(steps), steps: steps, expanded: expanded, onToggle: setExpanded, stepsLabel: "\u56DE\u7B54\u6B65\u9AA4" }));
}
/** Re-renders every `tickMs` while `active`, returning the current time. */
function useClock(now, tickMs, active) {
    const [value, setValue] = useState(now);
    useEffect(() => {
        if (!active)
            return undefined;
        setValue(now());
        const timer = setInterval(() => setValue(now()), tickMs);
        return () => clearInterval(timer);
    }, [active, now, tickMs]);
    return value;
}
/** The main button of the unfinished card, by why the body is not searchable. */
function unfinishedPrimary(entry, { actionable, onRetryCollect, onRecollect }) {
    if (!actionable || !entry.reason)
        return null;
    // The server cannot read login-only subtitles; collecting again from the page can.
    if (entry.reason.category === "login_required")
        return { kind: "button", label: ACTION_LABEL.recollect, onClick: onRecollect };
    if (!entry.retryable)
        return null;
    return { kind: "button", label: ACTION_LABEL.retry, onClick: () => onRetryCollect(entry.id), pending: entry.retryState === "pending" };
}
function retryError(entry) {
    if (entry.retryState === "quota_exceeded")
        return QUOTA_RETRY_COPY;
    return entry.retryState === "failed" ? RETRY_FAILED_COPY : null;
}
/**
 * The 「收藏视频」 action. Reading and submitting show as steps; once the server has the item the
 * block shows its ingest progress, or why it did not finish and what can be done about it.
 */
function CollectBlock({ entry, now, tickMs, willTranscribe, actionable, onOpenWorkspace, onRetryCollect, onRecollect }) {
    const active = entry.phase !== "done";
    const clock = useClock(now, tickMs, active);
    const progress = collectProgress(entry, clock);
    const [expanded, setExpanded] = useState(true);
    const body = collectBody(entry);
    const note = collectNote(entry, willTranscribe);
    const steps = collectSteps(entry, willTranscribe).map((step) => (step.outcome === "running" && progress ? { ...step, detail: _jsx("small", { className: "sp-step-detail", children: progress }) } : step));
    const result = collectResult(entry);
    const workspacePath = collectWorkspacePath(entry);
    return (_jsxs("article", { className: "sp-collect", "aria-busy": active, "aria-label": "\u6536\u85CF\u89C6\u9891", children: [body === "steps" ? (_jsx(StepTimeline, { className: "sp-timeline", summary: collectSummary(entry, steps), steps: steps, expanded: expanded, onToggle: setExpanded, stepsLabel: "\u6536\u85CF\u6B65\u9AA4" })) : (_jsxs(_Fragment, { children: [note ? _jsx("p", { className: "sp-collect__note", children: note }) : null, body === "progress" ? (_jsx(IngestProgress, { stages: entryStages(entry), searchable: entry.bodySearchable, note: progress })) : entry.reason ? (_jsx(IngestUnfinished, { title: entry.itemTitle, platformName: platformLabel(entry.itemPlatform ?? ""), reason: entry.reason, primary: unfinishedPrimary(entry, { actionable, onRetryCollect, onRecollect }), onSearchTitles: () => onOpenWorkspace(TITLE_SEARCH_ROUTE), error: retryError(entry) })) : null] })), result ? _jsx("p", { className: "sp-collect__result", "data-tone": result.tone, role: "status", children: result.text }) : null, workspacePath ? (_jsx("button", { className: "sp-link sp-collect__link", type: "button", onClick: () => onOpenWorkspace(workspacePath), children: "\u5728\u5DE5\u4F5C\u533A\u67E5\u770B" })) : null] }));
}
export function QaThread({ thread, now, clockTickMs, willTranscribe, onOpenCitation, onRetry, onOpenWorkspace, onRetryCollect, onRecollect, }) {
    let latestCollectId = null;
    for (const entry of thread)
        if (entry.kind === "collect")
            latestCollectId = entry.id;
    return (_jsx("ol", { className: "sp-turns", "aria-label": "\u89C6\u9891\u95EE\u7B54", children: thread.map((entry) => {
            if (entry.kind === "collect") {
                return (_jsx("li", { className: "sp-turn sp-turn--action", children: _jsx(CollectBlock, { entry: entry, now: now, tickMs: clockTickMs, willTranscribe: willTranscribe, actionable: entry.id === latestCollectId, onOpenWorkspace: onOpenWorkspace, onRetryCollect: onRetryCollect, onRecollect: onRecollect }) }, entry.id));
            }
            const turn = entry;
            return (_jsxs("li", { className: "sp-turn", children: [_jsx("p", { className: "sp-question", children: turn.question }), _jsxs("article", { className: `sp-answer sp-answer--${turn.status}`, "aria-busy": turn.status === "streaming", children: [_jsx(TurnSteps, { turn: turn }), turn.status === "streaming" && !turn.answer ? _jsx("p", { className: "sr-only", role: "status", children: "\u6B63\u5728\u56DE\u7B54\u2026" }) : null, turn.answer ? _jsx(MarkdownAnswer, { children: panelAnswerText(turn.answer, turn.citations.length > 0) }) : null, turn.status === "failed" || turn.status === "stopped" ? (_jsxs("p", { className: "sp-answer__state", role: turn.status === "failed" ? "alert" : "status", children: [turn.error, turn.status === "failed" ? (_jsxs(_Fragment, { children: [" ", _jsx("button", { className: "sp-link", type: "button", onClick: () => onRetry(turn.id), children: "\u91CD\u8BD5" })] })) : null] })) : null, turn.status === "done" ? _jsx(CitationChips, { citations: turn.citations, onOpen: onOpenCitation }) : null] })] }, turn.id));
        }) }));
}
